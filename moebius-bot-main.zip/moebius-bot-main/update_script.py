﻿#!/usr/bin/env python3
"""
GitHub Webhook Auto-Update Script
GitHub'a push edildiğinde VDS'deki botu otomatik günceller
"""
import os
import subprocess
import shutil
import zipfile
import requests
from flask import Flask, request, jsonify
import threading
import time

app = Flask(__name__)

# Konfigürasyon
GITHUB_TOKEN = "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"
REPO_URL = "https://github.com/Arthu27/Aether-bot"
BOT_DIR = "C:/Users/Administrator/Aether-bot-main"
BACKUP_DIR = "C:/Users/Administrator/Aether-bot-backup"

def update_bot():
    """Botu güncelle"""
    try:
        print("[UPDATE] Güncelleme başlıyor...")
        
        # Mevcut botu durdur (process kill)
        subprocess.run("taskkill /f /im python.exe", shell=True, capture_output=True)
        time.sleep(3)
        
        # Backup oluştur
        if os.path.exists(BOT_DIR):
            if os.path.exists(BACKUP_DIR):
                shutil.rmtree(BACKUP_DIR)
            shutil.copytree(BOT_DIR, BACKUP_DIR)
            print("[UPDATE] Backup oluşturuldu")
        
        # Yeni versiyonu indir
        zip_url = f"{REPO_URL}/archive/refs/heads/main.zip"
        headers = {"Authorization": f"token {GITHUB_TOKEN}"}
        
        response = requests.get(zip_url, headers=headers)
        if response.status_code != 200:
            raise Exception(f"İndirme hatası: {response.status_code}")
        
        # ZIP'i kaydet ve aç
        zip_path = "C:/Users/Administrator/Aether-update.zip"
        with open(zip_path, "wb") as f:
            f.write(response.content)
        
        # Eski klasörü sil
        if os.path.exists(BOT_DIR):
            shutil.rmtree(BOT_DIR)
        
        # ZIP'i aç
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall("C:/Users/Administrator/")
        
        # .env dosyasını geri kopyala
        env_content = """TOKEN=MTQyMTQxODcwMDQ1MTM0ODUyMA.GxBKSZ.XdD5BcKTxfS0yJh5WN9LHTUIiXyFbPumGrRnDk
GROQ_API_KEY=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
MISTRAL_API_KEY=tnYGoQBLy5QYfCLkk48Pxhk7yERvXDrt
MISTRAL_API_KEY_2=Q2v4j4FTcdek6DkPZMPH53t3PLxN6t7K
MISTRAL_API_KEY_3=cEEfVtDrPwkZtPopLlCBX5uGvSZPrDVB
MISTRAL_API_KEY_4=FIWdcnXZu9sNp1hWgGojwVVPaNP5ywDg
MISTRAL_API_KEY_5=Ee2QOEECfMiaoBpamDlBY4MgrEX6viNw
OPENROUTER_API_KEY=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
OWNER_ID=987430047889637426"""
        
        with open(f"{BOT_DIR}/.env", "w", encoding="utf-8") as f:
            f.write(env_content)
        
        # Cleanup
        os.remove(zip_path)
        
        print("[UPDATE] Dosyalar güncellendi")
        
        # Botu yeniden başlat
        time.sleep(2)
        subprocess.Popen(["python", "main.py"], cwd=BOT_DIR, shell=True)
        print("[UPDATE] Bot yeniden başlatıldı")
        
        return True
        
    except Exception as e:
        print(f"[UPDATE] Hata: {e}")
        # Backup'tan geri yükle
        if os.path.exists(BACKUP_DIR):
            if os.path.exists(BOT_DIR):
                shutil.rmtree(BOT_DIR)
            shutil.copytree(BACKUP_DIR, BOT_DIR)
            subprocess.Popen(["python", "main.py"], cwd=BOT_DIR, shell=True)
            print("[UPDATE] Backup'tan geri yüklendi")
        return False

@app.route('/webhook', methods=['POST'])
def github_webhook():
    """GitHub webhook endpoint"""
    try:
        # GitHub signature doğrulama (basit)
        if request.headers.get('X-GitHub-Event') == 'push':
            payload = request.get_json()
            
            # main branch'e push kontrolü
            if payload.get('ref') == 'refs/heads/main':
                print("[WEBHOOK] Push algılandı, güncelleme başlatılıyor...")
                
                # Güncellemeyi ayrı thread'de çalıştır
                threading.Thread(target=update_bot, daemon=True).start()
                
                return jsonify({"status": "success", "message": "Update started"}), 200
            else:
                return jsonify({"status": "ignored", "message": "Not main branch"}), 200
        else:
            return jsonify({"status": "ignored", "message": "Not a push event"}), 200
            
    except Exception as e:
        print(f"[WEBHOOK] Hata: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/status')
def status():
    """Durum kontrolü"""
    return jsonify({
        "status": "running",
        "bot_running": os.path.exists(f"{BOT_DIR}/main.py")
    })

@app.route('/manual-update', methods=['POST'])
def manual_update():
    """Manuel güncelleme"""
    threading.Thread(target=update_bot, daemon=True).start()
    return jsonify({"status": "success", "message": "Manual update started"})

if __name__ == '__main__':
    print("[WEBHOOK] GitHub Auto-Update servisi başlatılıyor...")
    print("[WEBHOOK] Webhook URL: http://localhost:5002/webhook")
    print("[WEBHOOK] Manuel güncelleme: http://localhost:5002/manual-update")
    app.run(host='0.0.0.0', port=5002, debug=False)