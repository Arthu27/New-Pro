﻿#!/usr/bin/env python3
"""
Temiz bot başlatma scripti - Eski process'leri temizler ve yeni bot başlatır
"""
import subprocess
import time
import os
import sys

def kill_existing_processes():
    """Mevcut bot process'lerini sonlandır"""
    print("[CLEANUP] Mevcut bot process'leri sonlandırılıyor...")
    
    try:
        # Python main.py process'lerini sonlandır
        subprocess.run('taskkill /f /im python.exe', shell=True, capture_output=True)
        
        # Cloudflared process'lerini sonlandır  
        subprocess.run('taskkill /f /im cloudflared.exe', shell=True, capture_output=True)
        
        # WMIC ile spesifik komut satırı olan process'leri sonlandır
        subprocess.run('wmic process where "commandline like \'%main.py%\'" delete', shell=True, capture_output=True)
        
        print("[CLEANUP] Process'ler sonlandırıldı")
        
    except Exception as e:
        print(f"[ERROR] Process sonlandırma hatası: {e}")

def wait_for_cleanup():
    """Process'lerin tamamen kapanmasını bekle"""
    print("[WAIT] Process'lerin kapanması bekleniyor...")
    time.sleep(5)

def start_bot():
    """Bot'u başlat"""
    print("[START] Bot başlatılıyor...")
    
    try:
        # Bot'u yeni console'da başlat
        subprocess.Popen(
            "python main.py",
            shell=True,
            creationflags=subprocess.CREATE_NEW_CONSOLE
        )
        print("[OK] Bot başlatıldı!")
        
    except Exception as e:
        print(f"[ERROR] Bot başlatma hatası: {e}")

def main():
    print("=" * 50)
    print("Aether Bot - Temiz Başlatma")
    print("=" * 50)
    
    # 1. Mevcut process'leri sonlandır
    kill_existing_processes()
    
    # 2. Temizlik için bekle
    wait_for_cleanup()
    
    # 3. Bot'u başlat
    start_bot()
    
    print("[INFO] İşlem tamamlandı!")

if __name__ == "__main__":
    main()