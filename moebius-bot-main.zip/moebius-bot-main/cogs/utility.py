import discord
from discord.ext import commands
from discord import app_commands

class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="avatar", description="Kullanıcının avatarını gösterir")
    async def avatar(self, interaction: discord.Interaction, user: discord.Member = None):
        user = user or interaction.user
        e = discord.Embed(title=f"🖼️ {user.display_name} — Avatar", color=0xdc143c, timestamp=discord.utils.utcnow())
        e.set_image(url=user.display_avatar.url)
        e.set_footer(text=f"İsteyen: {interaction.user.name}", icon_url=interaction.user.display_avatar.url)
        await interaction.response.send_message(embed=e)

    @app_commands.command(name="join", description="Botu ses kanalına çağırır")
    async def join(self, interaction: discord.Interaction, kanal: discord.VoiceChannel = None):
        if kanal is None:
            if interaction.user.voice:
                kanal = interaction.user.voice.channel
            else:
                await interaction.response.send_message("❌ Bir ses kanalında değilsin!", ephemeral=True)
                return
        if interaction.guild.voice_client:
            await interaction.guild.voice_client.move_to(kanal)
        else:
            await kanal.connect()
        e = discord.Embed(title="🔊 SES KANALI", color=0x2ecc71, timestamp=discord.utils.utcnow())
        e.add_field(name="📢 Kanal", value=f"**{kanal.name}**", inline=True)
        e.set_footer(text=f"İsteyen: {interaction.user.name}", icon_url=interaction.user.display_avatar.url)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @app_commands.command(name="leave", description="Botu ses kanalından çıkarır")
    async def leave(self, interaction: discord.Interaction):
        if interaction.guild.voice_client:
            await interaction.guild.voice_client.disconnect()
            e = discord.Embed(title="🔇 SES KANALINDEN AYRILDI", color=0xe74c3c, timestamp=discord.utils.utcnow())
            e.set_footer(text=f"İsteyen: {interaction.user.name}", icon_url=interaction.user.display_avatar.url)
            await interaction.response.send_message(embed=e, ephemeral=True)
        else:
            await interaction.response.send_message("❌ Bot zaten ses kanalında değil!", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Utility(bot), guilds=[discord.Object(id=1421244140359909513), discord.Object(id=1107038411895881788)])
