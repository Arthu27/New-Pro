﻿"""
Aether Bot — Merkezi Embed & GIF Yardımcı Modülü
Tüm cog'lar bu modülden import eder.
"""
import discord
import random
from datetime import datetime, timezone

# ── GIF Havuzları — Gerçek tematik GIF'ler ───────────────────────────────────

GIFS = {
    "ban": [
        "https://media.tenor.com/x8v1oNUOmg4AAAAC/ban-hammer.gif",
        "https://media.tenor.com/deECPGRKlmYAAAAC/ban-banned.gif",
        "https://media.tenor.com/NkEMgMUMR6EAAAAC/banned-hammer.gif",
        "https://media.tenor.com/Ug1IQKM5LXUAAAAC/ban-hammer-ban.gif",
    ],
    "kick": [
        "https://media.tenor.com/OtNpHMFHMhsAAAAC/kick-out.gif",
        "https://media.tenor.com/jTGCHqHKOGkAAAAC/kicked-out.gif",
        "https://media.tenor.com/Ug1IQKM5LXUAAAAC/ban-hammer-ban.gif",
    ],
    "mute": [
        "https://media.tenor.com/zjaHBJMFMIsAAAAC/shh-quiet.gif",
        "https://media.tenor.com/Ug1IQKM5LXUAAAAC/ban-hammer-ban.gif",
        "https://media.tenor.com/deECPGRKlmYAAAAC/ban-banned.gif",
    ],
    "unmute": [
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
        "https://media.tenor.com/OtNpHMFHMhsAAAAC/kick-out.gif",
    ],
    "warn": [
        "https://media.tenor.com/xTMoHBqFkFkAAAAC/warning-caution.gif",
        "https://media.tenor.com/deECPGRKlmYAAAAC/ban-banned.gif",
        "https://media.tenor.com/NkEMgMUMR6EAAAAC/banned-hammer.gif",
    ],
    "timeout": [
        "https://media.tenor.com/zjaHBJMFMIsAAAAC/shh-quiet.gif",
        "https://media.tenor.com/xTMoHBqFkFkAAAAC/warning-caution.gif",
    ],
    "untimeout": [
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
    ],
    "unban": [
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
        "https://media.tenor.com/OtNpHMFHMhsAAAAC/kick-out.gif",
    ],
    "ticket_open": [
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
        "https://media.tenor.com/OtNpHMFHMhsAAAAC/kick-out.gif",
        "https://media.tenor.com/deECPGRKlmYAAAAC/ban-banned.gif",
    ],
    "ticket_close": [
        "https://media.tenor.com/x8v1oNUOmg4AAAAC/ban-hammer.gif",
        "https://media.tenor.com/NkEMgMUMR6EAAAAC/banned-hammer.gif",
    ],
    "ticket_panel": [
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
        "https://media.tenor.com/OtNpHMFHMhsAAAAC/kick-out.gif",
    ],
    "giveaway_win": [
        "https://media.tenor.com/ZBDpMFBMFpkAAAAC/celebration-party.gif",
        "https://media.tenor.com/Ug1IQKM5LXUAAAAC/ban-hammer-ban.gif",
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
    ],
    "giveaway_start": [
        "https://media.tenor.com/ZBDpMFBMFpkAAAAC/celebration-party.gif",
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
    ],
    "apply_approved": [
        "https://media.tenor.com/ZBDpMFBMFpkAAAAC/celebration-party.gif",
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
    ],
    "apply_rejected": [
        "https://media.tenor.com/x8v1oNUOmg4AAAAC/ban-hammer.gif",
        "https://media.tenor.com/deECPGRKlmYAAAAC/ban-banned.gif",
    ],
    "verify": [
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
        "https://media.tenor.com/ZBDpMFBMFpkAAAAC/celebration-party.gif",
    ],
    "economy_win": [
        "https://media.tenor.com/ZBDpMFBMFpkAAAAC/celebration-party.gif",
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
    ],
    "economy_lose": [
        "https://media.tenor.com/x8v1oNUOmg4AAAAC/ban-hammer.gif",
        "https://media.tenor.com/deECPGRKlmYAAAAC/ban-banned.gif",
    ],
    "economy_daily": [
        "https://media.tenor.com/ZBDpMFBMFpkAAAAC/celebration-party.gif",
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
    ],
    "badge": [
        "https://media.tenor.com/ZBDpMFBMFpkAAAAC/celebration-party.gif",
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
    ],
    "welcome": [
        "https://media.tenor.com/ZBDpMFBMFpkAAAAC/celebration-party.gif",
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
    ],
    "error": [
        "https://media.tenor.com/x8v1oNUOmg4AAAAC/ban-hammer.gif",
        "https://media.tenor.com/deECPGRKlmYAAAAC/ban-banned.gif",
    ],
    "success": [
        "https://media.tenor.com/ZBDpMFBMFpkAAAAC/celebration-party.gif",
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
    ],
    "duty_start": [
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
        "https://media.tenor.com/xTMoHBqFkFkAAAAC/warning-caution.gif",
    ],
    "duty_end": [
        "https://media.tenor.com/ZBDpMFBMFpkAAAAC/celebration-party.gif",
        "https://media.tenor.com/3Ky6UNqMFpkAAAAC/talking-speak.gif",
    ],
}


def gif(category: str) -> str:
    """Kategoriden rastgele bir GIF URL'si döndürür."""
    pool = GIFS.get(category, GIFS["success"])
    return random.choice(pool)


def now_ts() -> int:
    return int(datetime.now(timezone.utc).timestamp())


def Aether_footer(guild: discord.Guild = None, extra: str = "") -> dict:
    text = f"Aether{' • ' + extra if extra else ''}"
    icon = guild.icon.url if guild and guild.icon else None
    return {"text": text, "icon_url": icon}


# ── Dekoratif yardımcılar ─────────────────────────────────────────────────────

def _divider() -> str:
    return "╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌"


def _action_header(action: str) -> str:
    """Aksiyon için dekoratif başlık satırı döndürür."""
    headers = {
        "ban":       "🔨  SUNUCUDAN KALICI UZAKLAŞTIRMA",
        "kick":      "👢  SUNUCUDAN ATILMA",
        "timeout":   "🔇  GEÇİCİ SUSTURMA",
        "untimeout": "🔊  SUSTURMA KALDIRILDI",
        "warn":      "⚠️  UYARI ALINDI",
        "unban":     "🔓  BAN KALDIRILDI",
    }
    return headers.get(action, "📋  BİLDİRİM")


# ── Moderasyon DM Embed ───────────────────────────────────────────────────────

def mod_dm_embed(
    action: str,
    guild: discord.Guild,
    moderator: discord.Member,
    reason: str = None,
    extra_fields: list = None,
    gif_key: str = None,
) -> discord.Embed:
    """
    Moderasyon DM embed'i — zengin, detaylı, GIF'li.
    action: "ban" | "kick" | "timeout" | "untimeout" | "warn" | "unban"
    """
    configs = {
        "ban": {
            "title": "🔨  Sunucudan Banlandınız",
            "color": 0xE74C3C,
            "badge": "🚫 KALICI BAN",
            "desc": (
                "**{guild.name}** sunucusundan **kalıcı olarak** uzaklaştırıldınız.\n\n"
                "> Bu kararın hatalı olduğunu düşünüyorsanız\n"
                "> sunucu yönetimiyle iletişime geçebilirsiniz."
            ),
            "tip": "💡 Bir daha bu sunucuya davet linki olmadan giremezsiniz.",
        },
        "kick": {
            "title": "👢  Sunucudan Atıldınız",
            "color": 0xE67E22,
            "badge": "⚡ KICK",
            "desc": (
                "**{guild.name}** sunucusundan atıldınız.\n\n"
                "> Davet linki ile tekrar katılabilirsiniz.\n"
                "> Lütfen sunucu kurallarına dikkat edin."
            ),
            "tip": "💡 Tekrar katılmak için geçerli bir davet linki kullanın.",
        },
        "timeout": {
            "title": "🔇  Geçici Olarak Susturuldunuz",
            "color": 0xF39C12,
            "badge": "⏳ TIMEOUT",
            "desc": (
                "**{guild.name}** sunucusunda belirtilen süre boyunca\n"
                "mesaj gönderme yetkiniz **geçici olarak kısıtlandı**.\n\n"
                "> Süre dolduğunda otomatik olarak açılacaktır."
            ),
            "tip": "💡 Süre boyunca kanalları okuyabilir, mesaj gönderemezsiniz.",
        },
        "untimeout": {
            "title": "🔊  Susturmanız Kaldırıldı",
            "color": 0x2ECC71,
            "badge": "✅ SERBEST",
            "desc": (
                "**{guild.name}** sunucusundaki susturmanız **kaldırıldı**.\n\n"
                "> Artık tekrar mesaj gönderebilirsiniz.\n"
                "> Lütfen kurallara uymaya devam edin. 👋"
            ),
            "tip": "💡 Kuralları ihlal etmemeye özen gösterin.",
        },
        "warn": {
            "title": "⚠️  Uyarı Aldınız",
            "color": 0xFF6B6B,
            "badge": "⚠️ UYARI",
            "desc": (
                "**{guild.name}** sunucusunda sunucu kurallarını ihlal ettiğiniz\n"
                "için resmi bir **uyarı** aldınız.\n\n"
                "> Uyarılar biriktiğinde daha ağır yaptırımlar uygulanabilir.\n"
                "> Lütfen kurallara uymaya özen gösterin."
            ),
            "tip": "💡 Kuralları okumak için #kurallar kanalını ziyaret edin.",
        },
        "unban": {
            "title": "🔓  Banınız Kaldırıldı",
            "color": 0x2ECC71,
            "badge": "✅ BAN KALDIRILDI",
            "desc": (
                "**{guild.name}** sunucusundaki banınız **kaldırıldı**.\n\n"
                "> Artık sunucuya tekrar katılabilirsiniz.\n"
                "> Lütfen bu fırsatı iyi değerlendirin. 🤝"
            ),
            "tip": "💡 Sunucuya katılmak için davet linki almanız gerekebilir.",
        },
    }
    cfg = configs.get(action, configs["warn"])

    e = discord.Embed(
        title=cfg["title"],
        color=cfg["color"],
        timestamp=datetime.now(timezone.utc),
    )

    # Ana açıklama
    desc = cfg['desc'].format(guild=guild)
    e.description = (
        f"```ansi\n\u001b[1;31m{cfg['badge']}\u001b[0m\n```\n"
        f"{_divider()}\n\n"
        f"{desc}\n\n"
        f"{_divider()}"
    )

    e.set_thumbnail(url=guild.icon.url if guild.icon else None)

    # Temel alanlar
    e.add_field(
        name="🏰 Sunucu",
        value=f"```{guild.name}```",
        inline=True
    )
    e.add_field(
        name="👮 Moderatör",
        value=f"```{moderator.display_name}```",
        inline=True
    )
    e.add_field(
        name="🕐 Tarih & Saat",
        value=f"<t:{now_ts()}:F>",
        inline=False
    )
    e.add_field(
        name="📝 Uygulanan Sebep",
        value=f"```{reason or 'Belirtilmedi'}```",
        inline=False
    )

    # Ekstra alanlar (timeout süresi vb.)
    if extra_fields:
        for name, value, inline in extra_fields:
            e.add_field(name=name, value=value, inline=inline)

    # İpucu
    e.add_field(
        name="ℹ️ Bilgi",
        value=f"*{cfg['tip']}*",
        inline=False
    )

    e.set_image(url=gif(gif_key or action))
    e.set_footer(
        text=f"Aether Moderasyon • {guild.name}",
        icon_url=guild.icon.url if guild.icon else None
    )
    return e


# ── Mod-log Embed ─────────────────────────────────────────────────────────────

def mod_log_embed(
    action: str,
    title: str,
    color: int,
    user: discord.Member,
    moderator: discord.Member,
    guild: discord.Guild,
    reason: str = None,
    case_id: int = None,
    extra_fields: list = None,
) -> discord.Embed:
    """Mod-log kanalı için standart, zengin embed."""
    action_emojis = {
        "ban": "🔨", "kick": "👢", "timeout": "🔇",
        "untimeout": "🔊", "warn": "⚠️", "unban": "🔓",
    }
    emoji = action_emojis.get(action, "📋")

    e = discord.Embed(title=f"{emoji} {title}", color=color, timestamp=datetime.now(timezone.utc))
    e.set_thumbnail(url=user.display_avatar.url)
    e.set_author(
        name=f"{moderator.display_name} işlem uyguladı",
        icon_url=moderator.display_avatar.url
    )

    e.add_field(
        name="👤 Hedef Kullanıcı",
        value=f"{user.mention}\n`{user.name}` • `{user.id}`",
        inline=True
    )
    e.add_field(
        name="👮 Moderatör",
        value=f"{moderator.mention}\n`{moderator.name}`",
        inline=True
    )
    if case_id:
        e.add_field(name="🆔 Case ID", value=f"```#{case_id}```", inline=True)

    e.add_field(
        name="📝 Sebep",
        value=f"```{reason or 'Belirtilmedi'}```",
        inline=False
    )
    e.add_field(
        name="🕐 Zaman",
        value=f"<t:{now_ts()}:F> (<t:{now_ts()}:R>)",
        inline=False
    )

    if extra_fields:
        for name, value, inline in extra_fields:
            e.add_field(name=name, value=value, inline=inline)

    e.set_footer(
        text=f"Aether Moderasyon • {guild.name}",
        icon_url=guild.icon.url if guild.icon else None
    )
    return e


# ── Genel Embed Fabrikaları ───────────────────────────────────────────────────

def success_embed(
    title: str,
    description: str,
    guild: discord.Guild = None,
    gif_key: str = None,
    fields: list = None,
) -> discord.Embed:
    e = discord.Embed(
        title=f"✅  {title}",
        description=description,
        color=0x2ECC71,
        timestamp=datetime.now(timezone.utc)
    )
    if gif_key:
        e.set_image(url=gif(gif_key))
    if fields:
        for name, value, inline in fields:
            e.add_field(name=name, value=value, inline=inline)
    if guild:
        e.set_footer(
            text=f"Aether • {guild.name}",
            icon_url=guild.icon.url if guild.icon else None
        )
    return e


def error_embed(description: str, title: str = "Hata") -> discord.Embed:
    return discord.Embed(
        title=f"❌  {title}",
        description=f"```{description}```",
        color=0xE74C3C,
        timestamp=datetime.now(timezone.utc),
    )


def info_embed(title: str, description: str, guild: discord.Guild = None) -> discord.Embed:
    e = discord.Embed(
        title=f"ℹ️  {title}",
        description=description,
        color=0x3498DB,
        timestamp=datetime.now(timezone.utc)
    )
    if guild:
        e.set_footer(
            text=f"Aether • {guild.name}",
            icon_url=guild.icon.url if guild.icon else None
        )
    return e


def warning_embed(title: str, description: str) -> discord.Embed:
    return discord.Embed(
        title=f"⚠️  {title}",
        description=description,
        color=0xF39C12,
        timestamp=datetime.now(timezone.utc),
    )
