﻿import discord
from discord import app_commands
from discord.ext import commands

PERM_ICON = {"all": "🟢", "mod": "🟡", "admin": "🔴", "owner": "⚙️"}
PERM_LABEL = {"all": "Herkes", "mod": "Moderatör", "admin": "Admin", "owner": "Owner"}

CATEGORIES = [
    {"id": "home", "emoji": "🏠", "title": "Ana Menü", "color": 0x7B68EE, "commands": []},
    {"id": "mod", "emoji": "🛡️", "title": "Moderasyon", "color": 0xFF4757, "commands": [
        ("/moderate ban", "Kalıcı yasakla", "/moderate ban @user sebep", "admin"),
        ("/moderate kick", "Sunucudan at", "/moderate kick @user sebep", "admin"),
        ("/moderate timeout", "Geçici sustur", "/moderate timeout @user 10m", "admin"),
        ("/moderate untimeout", "Susturmayı kaldır", "/moderate untimeout @user", "admin"),
        ("/moderate unban", "Banı kaldır", "/moderate unban user_id", "admin"),
        ("/utility temizle", "Toplu mesaj sil", "/utility temizle 50", "admin"),
        ("/utility lock", "Kanalı kilitle", "/utility lock", "mod"),
        ("/utility unlock", "Kanal kilidini kaldır", "/utility unlock", "mod"),
        ("/utility userinfo", "Kullanıcı bilgisi", "/utility userinfo @user", "mod"),
        ("/role", "Rol ver / al", "/role @user @rol", "admin"),
        ("/history", "Mod geçmişi", "/history @user", "mod"),
        ("/case", "Case detayı", "/case 42", "mod"),
        ("/note", "Gizli not ekle", "/note @user not", "mod"),
        ("/notes", "Notları göster", "/notes @user", "mod"),
        ("/watchlist", "İzleme listesi", "/watchlist @user sebep", "mod"),
        ("/watchlist-show", "İzleme listesini göster", "/watchlist-show", "mod"),
        ("/banlist", "Banlı kullanıcılar", "/banlist", "admin"),
        ("/massrole", "Toplu rol işlemi", "/massrole @rol ver", "admin"),
        ("/massban", "Toplu ban", "/massban id1 id2 id3", "admin"),
    ]},
    {"id": "warn", "emoji": "⚠️", "title": "Uyarı Sistemi", "color": 0xFFA502, "commands": [
        ("/warn", "Uyarı ver", "/warn @user sebep", "mod"),
        ("/warnings", "Uyarıları listele", "/warnings @user", "mod"),
        ("/clearwarns", "Tüm uyarıları temizle", "/clearwarns @user", "admin"),
    ]},
    {"id": "music", "emoji": "🎵", "title": "Müzik", "color": 0x2ED573, "commands": [
        ("/çal", "Müzik çal", "/çal lofi hip hop", "all"),
        ("/dur", "Duraklat / devam", "/dur", "all"),
        ("/atla", "Şarkıyı atla", "/atla", "all"),
        ("/kuyruk", "Kuyruğu göster", "/kuyruk", "all"),
        ("/ses", "Ses seviyesi 0-100", "/ses 80", "all"),
        ("/temizle-kuyruk", "Kuyruğu temizle", "/temizle-kuyruk", "all"),
        ("/ayrıl", "Ses kanalından çık", "/ayrıl", "all"),
        ("/join", "Ses kanalına katıl", "/join", "all"),
    ]},
    {"id": "fun", "emoji": "🎮", "title": "Eğlence & Oyun", "color": 0xFF6B81, "commands": [
        ("/yazitura", "Yazı tura at", "/yazitura", "all"),
        ("/zar-at", "Zar at 1-5 adet", "/zar-at 2", "all"),
        ("/taş-kağıt-makas", "Taş kağıt makas", "/taş-kağıt-makas", "all"),
        ("/oyun-baslat", "Sayı tahmin oyunu", "/oyun-baslat", "all"),
        ("/oyun-tahmin", "Tahmin et", "/oyun-tahmin 42", "all"),
        ("/sihirli-top", "Sihirli 8 top", "/sihirli-top soru", "all"),
        ("/oyun-rastgele-uye", "Rastgele üye seç", "/oyun-rastgele-uye", "all"),
        ("/eglen", "Eğlence komutları", "/eglen zar", "all"),
        ("/anket-hızlı", "Hızlı anket", "/anket-hızlı soru", "all"),
    ]},
    {"id": "eco", "emoji": "💰", "title": "Ekonomi & Özellikler", "color": 0xFFD700, "commands": [
        ("/ekonomi", "Bakiye, günlük, transfer", "/ekonomi bakiye", "all"),
        ("/oyunlar", "Kumar, slot, soygun", "/oyunlar kumar 100", "all"),
        ("/magaza", "Mağazayı görüntüle", "/magaza", "all"),
        ("/satın-al", "Ürün satın al", "/satın-al ürün", "all"),
        ("/dogumgunu", "Doğum gününü kaydet", "/dogumgunu 15 3", "all"),
        ("/dogumgunleri", "Yaklaşan doğum günleri", "/dogumgunleri", "all"),
        ("/afk", "AFK moduna gir", "/afk sebep", "all"),
        ("/duty-panel", "Görev panelini gönder", "/duty-panel", "admin"),
        ("/duty-add", "Manuel ilerleme ekle", "/duty-add @user 10", "mod"),
        ("/duty-stats", "Görev puan tablosu", "/duty-stats", "mod"),
        ("/ticket_panel", "Ticket panelini gönder", "/ticket_panel", "admin"),
        ("/staff-basvuru", "Yetkili başvurusu", "/staff-basvuru", "all"),
    ]},
    {"id": "leaderboard", "emoji": "🏆", "title": "Liderlik & Rapor", "color": 0xF1C40F, "commands": [
        ("!sıralama", "Genel liderlik tablosu", "!sıralama", "all"),
        ("!sıralama mesaj", "Mesaj sıralaması", "!sıralama mesaj", "all"),
        ("!sıralama ses", "Ses süresi sıralaması", "!sıralama ses", "all"),
        ("!sıralama davet", "Davet sıralaması", "!sıralama davet", "all"),
        ("/profilim", "Kendi istatistiklerin", "/profilim", "all"),
        ("/davetlerim", "Davet istatistiklerin", "/davetlerim", "all"),
        ("/davet-sıralama", "Top davetçiler", "/davet-sıralama", "all"),
        ("!haftalik-rapor", "Haftalık toplantı raporu", "!haftalik-rapor", "mod"),
        ("!toplanti-baslat", "Toplantı başlat, sayaç sıfırla", "!toplanti-baslat", "admin"),
        ("!toplanti-sayac", "Son toplantıdan kaç gün", "!toplanti-sayac", "all"),
        ("!rapor-ayarla", "Otomatik rapor ayarla", "!rapor-ayarla #kanal 0 9", "admin"),
        ("!rapor-rol-ekle", "Rapora rol ekle", "!rapor-rol-ekle @Rol", "admin"),
        ("!mod-istatistik", "Moderatör istatistikleri", "!mod-istatistik @kişi", "mod"),
    ]},
    {"id": "events", "emoji": "📅", "title": "Etkinlik Sistemi", "color": 0x5865F2, "commands": [
        ("/etkinlik-oluştur", "Yeni etkinlik oluştur", "/etkinlik-oluştur başlık", "admin"),
        ("/etkinlikler", "Aktif etkinlikleri listele", "/etkinlikler", "all"),
        ("/etkinlik-iptal", "Etkinliği iptal et", "/etkinlik-iptal id", "admin"),
    ]},
    {"id": "util", "emoji": "🔧", "title": "Yardımcı Araçlar", "color": 0x5352ED, "commands": [
        ("/modstats", "Moderatör istatistikleri", "/modstats", "mod"),
        ("/activemods", "En aktif moderatörler", "/activemods", "mod"),
        ("/sağlık", "Sunucu sağlık skoru", "/sağlık", "all"),
        ("/kanal-istatistik", "Kanal mesaj istatistiği", "/kanal-istatistik", "all"),
        ("/verify-setup", "Doğrulama sistemini kur", "/verify-setup", "admin"),
        ("/botinfo", "Bot bilgileri", "/botinfo", "all"),
        ("/uptime", "Bot çalışma süresi", "/uptime", "all"),
        ("/avatar", "Avatar göster", "/avatar @user", "all"),
        ("/serverinfo", "Sunucu bilgisi", "/serverinfo", "all"),
        ("/archive", "Mesajları arşivle", "/archive 100", "admin"),
        ("/ai-sifirla", "AI sohbet geçmişini sıfırla", "/ai-sifirla", "all"),
        ("/ai-bilgi-ekle", "AI'ya bilgi öğret", "/ai-bilgi-ekle konu bilgi", "admin"),
    ]},
]

TOTAL_PAGES = len(CATEGORIES)
TOTAL_CMDS = sum(len(c["commands"]) for c in CATEGORIES)


def build_embed(page, guild=None):
    cat = CATEGORIES[page]
    PT = {"all": "🟢", "mod": "🟡", "admin": "🔴", "owner": "⚙️"}

    guild_name   = guild.name   if guild else "Aether"
    guild_banner = guild.banner if guild else None
    guild_icon   = guild.icon   if guild else None

    # ── ANA MENÜ ─────────────────────────────────────────────────────────────
    if cat["id"] == "home":
        embed = discord.Embed(color=0x5865F2)
        embed.set_author(
            name=f"{guild_name}  ·  Komut Rehberi",
            icon_url=guild_icon.url if guild_icon else None
        )
        embed.description = (
            f"> 📦 **{TOTAL_CMDS}** komut  ·  **{TOTAL_PAGES - 1}** kategori\n"
            f"> 🔑 `🟢 Herkes`  `🟡 Mod`  `🔴 Admin`  `⚙️ Owner`\n\n"
            f"**Aşağıdan kategori seç ↓**"
        )

        # Sunucu banner'ı varsa image olarak koy
        if guild_banner:
            embed.set_image(url=guild_banner.url)
        elif guild_icon:
            embed.set_thumbnail(url=guild_icon.url)

        CAT_DESC = {
            "mod":         "Ban · Kick · Timeout · History",
            "warn":        "Uyarı ver · Listele · Temizle",
            "music":       "Çal · Kuyruk · Ses ayarı",
            "fun":         "Oyunlar · Anket · Eğlence",
            "eco":         "Ekonomi · Görev · Ticket · AFK",
            "leaderboard": "Sıralama · Rapor · Toplantı",
            "events":      "Etkinlik oluştur · Listele",
            "util":        "İstatistik · Araçlar · AI",
        }

        for c in CATEGORIES[1:]:
            count = len(c['commands'])
            embed.add_field(
                name=f"{c['emoji']}  **{c['title']}**",
                value=f"```{CAT_DESC.get(c['id'], '')}```\n-# {count} komut",
                inline=True
            )

        embed.set_footer(
            text=f"{guild_name}  ·  !yardim  ·  Sayfa 1/{TOTAL_PAGES}",
            icon_url=guild_icon.url if guild_icon else None
        )
        return embed

    # ── KATEGORİ SAYFASI ─────────────────────────────────────────────────────
    cmds = cat["commands"]

    embed = discord.Embed(color=cat["color"])
    embed.set_author(
        name=f"{cat['emoji']}  {cat['title']}  ·  {len(cmds)} komut",
        icon_url=guild_icon.url if guild_icon else None
    )

    # Komutları ikiye böl
    mid = (len(cmds) + 1) // 2
    left_cmds  = cmds[:mid]
    right_cmds = cmds[mid:]

    def fmt(name, desc, usage, perm):
        return (
            f"{PT[perm]} **`{name}`**\n"
            f"╰ {desc}\n"
            f"╰ -# `{usage}`"
        )

    embed.add_field(
        name="",
        value="\n\n".join(fmt(*c) for c in left_cmds),
        inline=True
    )
    if right_cmds:
        embed.add_field(
            name="",
            value="\n\n".join(fmt(*c) for c in right_cmds),
            inline=True
        )

    # İzin özeti
    perm_counts = {}
    for _, _, _, p in cmds:
        perm_counts[p] = perm_counts.get(p, 0) + 1
    summary_parts = []
    for k in ("all", "mod", "admin", "owner"):
        if k in perm_counts:
            summary_parts.append(f"{PT[k]} {PERM_LABEL[k]}: **{perm_counts[k]}**")
    embed.add_field(name="", value="  ·  ".join(summary_parts), inline=False)

    embed.set_footer(
        text=f"{guild_name}  ·  Sayfa {page + 1}/{TOTAL_PAGES}  ·  !yardim",
        icon_url=guild_icon.url if guild_icon else None
    )
    if guild_icon:
        embed.set_thumbnail(url=guild_icon.url)
    return embed


class CategorySelect(discord.ui.Select):
    def __init__(self, current_page):
        options = [
            discord.SelectOption(
                label=f"{c['emoji']} {c['title']}",
                value=str(i),
                description=f"{len(c['commands'])} komut" if c["commands"] else "Ana menü",
                default=(i == current_page),
            )
            for i, c in enumerate(CATEGORIES)
        ]
        super().__init__(placeholder="📂  Kategori seç...", options=options, custom_id="help_cat_select", row=0)

    async def callback(self, interaction):
        page = int(self.values[0])
        view = HelpView(page=page)
        await interaction.response.edit_message(embed=build_embed(page, interaction.guild), view=view)


class HelpView(discord.ui.View):
    def __init__(self, page=0):
        super().__init__(timeout=None)  # Timeout yok — her zaman çalışır
        self.page = page
        self.add_item(CategorySelect(page))
        self._sync()

    def _sync(self):
        self.prev_btn.disabled = (self.page == 0)
        self.next_btn.disabled = (self.page == TOTAL_PAGES - 1)
        self.page_label.label = f"  {self.page + 1} / {TOTAL_PAGES}  "

    @discord.ui.button(label="◀", style=discord.ButtonStyle.secondary, row=1, custom_id="help_prev")
    async def prev_btn(self, interaction, button):
        self.page = max(0, self.page - 1)
        self._sync()
        await interaction.response.edit_message(embed=build_embed(self.page, interaction.guild), view=self)

    @discord.ui.button(label="  1 / 7  ", style=discord.ButtonStyle.primary, disabled=True, row=1, custom_id="help_page")
    async def page_label(self, interaction, button):
        pass

    @discord.ui.button(label="▶", style=discord.ButtonStyle.secondary, row=1, custom_id="help_next")
    async def next_btn(self, interaction, button):
        self.page = min(TOTAL_PAGES - 1, self.page + 1)
        self._sync()
        await interaction.response.edit_message(embed=build_embed(self.page, interaction.guild), view=self)

    @discord.ui.button(label="🏠 Ana Menü", style=discord.ButtonStyle.success, row=1, custom_id="help_home")
    async def home_btn(self, interaction, button):
        self.page = 0
        self._sync()
        await interaction.response.edit_message(embed=build_embed(0, interaction.guild), view=self)

    @discord.ui.button(label="✖ Kapat", style=discord.ButtonStyle.danger, row=1, custom_id="help_close")
    async def close_btn(self, interaction, button):
        await interaction.response.defer()
        await interaction.delete_original_response()


class Help(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="yardim", aliases=["help", "komutlar", "h", "?"])
    async def yardim_prefix(self, ctx):
        try:
            await ctx.message.delete()
        except Exception:
            pass
        await ctx.send(embed=build_embed(0, ctx.guild), view=HelpView(page=0))

    @app_commands.command(name="yardim", description="Tüm bot komutlarını gösterir")
    async def yardim_slash(self, interaction):
        await interaction.response.send_message(embed=build_embed(0, interaction.guild), view=HelpView(page=0), ephemeral=True)


async def setup(bot):
    await bot.add_cog(Help(bot))
    # Persistent view — bot yeniden başlatılınca eski mesajlardaki butonlar çalışır
    bot.add_view(HelpView())
