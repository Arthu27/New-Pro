"""Cog yönetimi - panelden/komuttan cog aç/kapat"""
import discord
from discord.ext import commands
from discord import app_commands
import os

class CogManager(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.group(name='modul', invoke_without_command=True)
    @commands.is_owner()
    async def modul_group(self, ctx):
        """Cog yönetim komutları"""
        loaded = [ext.split('.')[-1] for ext in self.bot.extensions]
        all_cogs = [f[:-3] for f in os.listdir('./cogs') if f.endswith('.py')]
        unloaded = [c for c in all_cogs if c not in loaded]

        embed = discord.Embed(title='⚙️ Modül Yönetimi', color=0x3498DB)
        embed.add_field(
            name=f'✅ Yüklü ({len(loaded)})',
            value='\n'.join(f'`{c}`' for c in sorted(loaded)) or 'Yok',
            inline=True
        )
        embed.add_field(
            name=f'❌ Yüklü Değil ({len(unloaded)})',
            value='\n'.join(f'`{c}`' for c in sorted(unloaded)) or 'Yok',
            inline=True
        )
        await ctx.send(embed=embed)

    @modul_group.command(name='yükle')
    @commands.is_owner()
    async def load_cog(self, ctx, cog_name: str):
        """Cog yükle"""
        try:
            await self.bot.load_extension(f'cogs.{cog_name}')
            await ctx.send(f'✅ `{cog_name}` yüklendi!')
        except Exception as e:
            await ctx.send(f'❌ Hata: `{e}`')

    @modul_group.command(name='kaldır')
    @commands.is_owner()
    async def unload_cog(self, ctx, cog_name: str):
        """Cog kaldır"""
        if cog_name == 'cog_manager':
            await ctx.send('❌ Bu cog kaldırılamaz!')
            return
        try:
            await self.bot.unload_extension(f'cogs.{cog_name}')
            await ctx.send(f'✅ `{cog_name}` kaldırıldı!')
        except Exception as e:
            await ctx.send(f'❌ Hata: `{e}`')

    @modul_group.command(name='yenile')
    @commands.is_owner()
    async def reload_cog(self, ctx, cog_name: str):
        """Cog yenile"""
        try:
            await self.bot.reload_extension(f'cogs.{cog_name}')
            await ctx.send(f'✅ `{cog_name}` yenilendi!')
        except Exception as e:
            await ctx.send(f'❌ Hata: `{e}`')

    @modul_group.command(name='hepsini-yenile')
    @commands.is_owner()
    async def reload_all(self, ctx):
        """Tüm cog'ları yenile"""
        results = []
        for ext in list(self.bot.extensions):
            try:
                await self.bot.reload_extension(ext)
                results.append(f'✅ {ext.split(".")[-1]}')
            except Exception as e:
                results.append(f'❌ {ext.split(".")[-1]}: {e}')
        await ctx.send('\n'.join(results))

async def setup(bot):
    await bot.add_cog(CogManager(bot))