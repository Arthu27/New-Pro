﻿import discord
from discord.ext import commands
import datetime
import json
import os
import time
import threading
import queue
from typing import Dict, Any

AUDIT_FILE = "data/audit_log.json"

CATEGORIES = {
    'mod':      {'label': 'Moderasyon',    'emoji': '🔨', 'color': 0xE74C3C},
    'member':   {'label': 'Üye',           'emoji': '👤', 'color': 0x2ECC71},
    'message':  {'label': 'Mesaj',         'emoji': '💬', 'color': 0x3498DB},
    'role':     {'label': 'Rol',           'emoji': '🎭', 'color': 0x9B59B6},
    'channel':  {'label': 'Kanal',         'emoji': '📺', 'color': 0xF39C12},
    'voice':    {'label': 'Ses',           'emoji': '🔊', 'color': 0x1ABC9C},
    'server':   {'label': 'Sunucu',        'emoji': '🏰', 'color': 0xE67E22},
    'automod':  {'label': 'AutoMod',       'emoji': '🤖', 'color': 0xE74C3C},
    'invite':   {'label': 'Davet',         'emoji': '📨', 'color': 0x95A5A6},
}

DIV = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Mesaj cache — silinmeden önce içeriği sakla (max 10000 mesaj)
_msg_cache: dict = {}  # {message_id: {content, author_id, author_name, channel_id, timestamp}}

# Queue-based audit log system — tek thread yazar, WinError 32 olmaz
_audit_queue: queue.Queue = queue.Queue()
_audit_worker_thread: threading.Thread = None
_audit_lock = threading.Lock()  # sadece worker içinde kullanılır

def _audit_worker():
    """Tek thread dosyaya yazar — race condition yok"""
    while True:
        try:
            event_data = _audit_queue.get(timeout=2.0)
        except queue.Empty:
            continue

        if event_data is None:  # shutdown sinyali
            break

        try:
            _write_audit_event(event_data)
        except Exception as e:
            print(f"[AUDIT-WORKER] Yazma hatası: {e}")
        finally:
            _audit_queue.task_done()

def _write_audit_event(event_data: Dict[str, Any]):
    """Dosyaya güvenli yaz — sadece worker thread çağırır"""
    guild_id = event_data['guild_id']
    category = event_data['category']
    action   = event_data['action']
    details  = event_data['details']

    os.makedirs("data", exist_ok=True)

    # Oku
    data = {}
    if os.path.exists(AUDIT_FILE):
        for _ in range(5):
            try:
                with open(AUDIT_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                break
            except (json.JSONDecodeError, OSError):
                time.sleep(0.1)

    gid = str(guild_id)
    data.setdefault(gid, [])
    data[gid].append({
        'category':  category,
        'action':    action,
        'timestamp': datetime.datetime.utcnow().isoformat(),
        **details
    })
    if len(data[gid]) > 2000:
        data[gid] = data[gid][-2000:]

    # Atomik yaz: önce .tmp, sonra rename
    tmp = AUDIT_FILE + f'.tmp{os.getpid()}'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        # Windows'ta rename hedef varsa hata verir — önce sil
        for _ in range(5):
            try:
                if os.path.exists(AUDIT_FILE):
                    os.replace(tmp, AUDIT_FILE)  # os.replace atomik + hedefi siler
                else:
                    os.rename(tmp, AUDIT_FILE)
                break
            except PermissionError:
                time.sleep(0.2)
    except Exception as e:
        print(f"[AUDIT] Yazma hatası: {e}")
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass

def _ensure_worker():
    """Worker thread yoksa başlat"""
    global _audit_worker_thread
    if _audit_worker_thread is None or not _audit_worker_thread.is_alive():
        _audit_worker_thread = threading.Thread(target=_audit_worker, daemon=True, name="audit-worker")
        _audit_worker_thread.start()

def save_event(guild_id, category, action, details: dict):
    """Event'i queue'ya ekle — worker thread sırayla dosyaya yazar"""
    if action == 'Mesaj Yazıldı':
        return
    _ensure_worker()
    _audit_queue.put({
        'guild_id': guild_id,
        'category': category,
        'action':   action,
        'details':  details,
    })


class Logs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def get_log_channel(self, guild):
        return discord.utils.get(guild.text_channels, name="sunucu-log")

    # ─── ÜYE EVENTLERİ ───────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_member_join(self, member):
        age_days = (discord.utils.utcnow() - member.created_at).days
        save_event(member.guild.id, 'member', 'Üye Katıldı', {
            'user_id': str(member.id),
            'user_name': str(member),
            'avatar': str(member.display_avatar.url),
            'account_age_days': age_days,
        })

        # Welcome mesajı gönder
        try:
            wcfg_path = f'data/welcome_{member.guild.id}.json'
            if os.path.exists(wcfg_path):
                with open(wcfg_path, 'r', encoding='utf-8') as f:
                    wcfg = json.load(f)
                w = wcfg.get('welcome', {})
                if w.get('channel_id'):
                    wch = member.guild.get_channel(int(w['channel_id']))
                    if wch:
                        title = (w.get('title') or 'Hoş Geldin, {user}!').replace('{user}', member.display_name).replace('{server}', member.guild.name).replace('{count}', str(member.guild.member_count)).replace('{mention}', member.mention)
                        msg = (w.get('message') or '{mention} sunucumuza hoş geldi!').replace('{user}', member.display_name).replace('{server}', member.guild.name).replace('{count}', str(member.guild.member_count)).replace('{mention}', member.mention)
                        color = int(w.get('color', '#c8922a').lstrip('#'), 16)
                        e = discord.Embed(title=title, description=msg, color=color)
                        e.set_thumbnail(url=member.display_avatar.url)
                        await wch.send(embed=e)
        except Exception as _e:
            print(f'[WELCOME] Hata: {_e}')

        ch = await self.get_log_channel(member.guild)
        if not ch: return

        age_warn = "⚠️ **Yeni hesap!**" if age_days < 7 else f"✅ {age_days} gün"
        e = discord.Embed(
            title="📥  YENİ ÜYE KATILDI",
            color=0x2ECC71,
            timestamp=datetime.datetime.utcnow()
        )
        e.description = (
            f"```ansi\n\u001b[1;32m✦ SUNUCUYA KATILDI ✦\u001b[0m\n```\n"
            f"{DIV}\n\n"
            f"{member.mention} sunucumuza hoş geldi! 🎉\n\n"
            f"{DIV}"
        )
        e.set_thumbnail(url=member.display_avatar.url)
        e.add_field(name="👤 Kullanıcı", value=f"```{member.name}```", inline=True)
        e.add_field(name="🆔 ID", value=f"```{member.id}```", inline=True)
        e.add_field(name="📅 Hesap Yaşı", value=age_warn, inline=True)
        e.add_field(name="📊 Üye Sayısı", value=f"```{member.guild.member_count} üye```", inline=True)
        e.add_field(name="🕐 Katılma", value=f"<t:{int(datetime.datetime.utcnow().timestamp())}:R>", inline=True)
        e.set_footer(
            text=f"Aether Log Sistemi • {member.guild.name}",
            icon_url=member.guild.icon.url if member.guild.icon else None
        )
        await ch.send(embed=e)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        save_event(member.guild.id, 'member', 'Üye Ayrıldı', {
            'user_id': str(member.id),
            'user_name': str(member),
            'avatar': str(member.display_avatar.url),
            'roles': [r.name for r in member.roles[1:]],
        })

        # Leave mesajı gönder
        try:
            wcfg_path = f'data/welcome_{member.guild.id}.json'
            if os.path.exists(wcfg_path):
                with open(wcfg_path, 'r', encoding='utf-8') as f:
                    wcfg = json.load(f)
                lv = wcfg.get('leave', {})
                if lv.get('channel_id'):
                    lch = member.guild.get_channel(int(lv['channel_id']))
                    if lch:
                        title = (lv.get('title') or 'Güle Güle, {user}!').replace('{user}', member.display_name).replace('{server}', member.guild.name).replace('{count}', str(member.guild.member_count)).replace('{mention}', member.mention)
                        msg = (lv.get('message') or '{user} sunucudan ayrıldı.').replace('{user}', member.display_name).replace('{server}', member.guild.name).replace('{count}', str(member.guild.member_count)).replace('{mention}', member.mention)
                        color = int(lv.get('color', '#e05555').lstrip('#'), 16)
                        e = discord.Embed(title=title, description=msg, color=color)
                        e.set_thumbnail(url=member.display_avatar.url)
                        await lch.send(embed=e)
        except Exception as _e:
            print(f'[LEAVE] Hata: {_e}')

        ch = await self.get_log_channel(member.guild)
        if not ch: return

        roles_str = ", ".join(r.name for r in member.roles[1:]) if member.roles[1:] else "Yok"
        e = discord.Embed(
            title="📤  ÜYE AYRILDI",
            color=0xE74C3C,
            timestamp=datetime.datetime.utcnow()
        )
        e.description = (
            f"```ansi\n\u001b[1;31m✦ SUNUCUDAN AYRILDI ✦\u001b[0m\n```\n"
            f"{DIV}\n\n"
            f"**{member.display_name}** sunucudan ayrıldı. 👋\n\n"
            f"{DIV}"
        )
        e.set_thumbnail(url=member.display_avatar.url)
        e.add_field(name="👤 Kullanıcı", value=f"```{member.name}```", inline=True)
        e.add_field(name="🆔 ID", value=f"```{member.id}```", inline=True)
        e.add_field(name="📊 Üye Sayısı", value=f"```{member.guild.member_count} üye```", inline=True)
        e.add_field(name="🎭 Sahip Olduğu Roller", value=f"```{roles_str[:200]}```", inline=False)
        e.set_footer(
            text=f"Aether Log Sistemi • {member.guild.name}",
            icon_url=member.guild.icon.url if member.guild.icon else None
        )
        await ch.send(embed=e)

    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        save_event(guild.id, 'mod', 'Ban', {
            'user_id': str(user.id),
            'user_name': str(user),
            'avatar': str(user.display_avatar.url),
        })

    @commands.Cog.listener()
    async def on_member_unban(self, guild, user):
        save_event(guild.id, 'mod', 'Ban Kaldırıldı', {
            'user_id': str(user.id),
            'user_name': str(user),
        })

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if before.roles != after.roles:
            added = [r for r in after.roles if r not in before.roles]
            removed = [r for r in before.roles if r not in after.roles]
            if added or removed:
                save_event(before.guild.id, 'role', 'Rol Güncellendi', {
                    'user_id': str(before.id),
                    'user_name': str(before),
                    'added_roles': [r.name for r in added],
                    'removed_roles': [r.name for r in removed],
                })
                ch = await self.get_log_channel(before.guild)
                if ch:
                    e = discord.Embed(
                        title="🎭  ROL DEĞİŞİKLİĞİ",
                        color=0x9B59B6,
                        timestamp=datetime.datetime.utcnow()
                    )
                    e.set_thumbnail(url=before.display_avatar.url)
                    e.add_field(name="👤 Kullanıcı", value=f"{before.mention} `{before.id}`", inline=False)
                    if added:
                        e.add_field(name="➕ Eklenen Roller", value=" ".join(r.mention for r in added), inline=True)
                    if removed:
                        e.add_field(name="➖ Kaldırılan Roller", value=" ".join(r.mention for r in removed), inline=True)
                    e.set_footer(text=f"Aether Log Sistemi • {before.guild.name}", icon_url=before.guild.icon.url if before.guild.icon else None)
                    await ch.send(embed=e)

        # Timeout kontrolü
        before_to = getattr(before, 'timed_out_until', None)
        after_to  = getattr(after,  'timed_out_until', None)
        if before_to != after_to:
            if after_to:
                # Timeout uygulandı
                save_event(before.guild.id, 'mod', 'Timeout', {
                    'user_id':   str(after.id),
                    'user_name': after.display_name,
                    'action':    'timeout',
                    'reason':    'Discord üzerinden uygulandı',
                    'until':     after_to.isoformat() if after_to else '',
                })
                # mod_data.json'a da kaydet
                try:
                    import json as _json, os as _os
                    _os.makedirs('data', exist_ok=True)
                    _f = 'data/mod_data.json'
                    _d = {'cases': {}}
                    if _os.path.exists(_f):
                        with open(_f, 'r', encoding='utf-8') as fp:
                            _d = _json.load(fp)
                    _gid = str(before.guild.id)
                    _d['cases'].setdefault(_gid, [])
                    _d['cases'][_gid].append({
                        'id': len(_d['cases'][_gid]) + 1,
                        'action': 'timeout',
                        'user_id': str(after.id),
                        'mod_id': 'sistem',
                        'reason': 'Discord üzerinden uygulandı',
                        'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat()
                    })
                    with open(_f, 'w', encoding='utf-8') as fp:
                        _json.dump(_d, fp, indent=2, ensure_ascii=False)
                except Exception as _e:
                    print(f'[LOGS] Timeout kayıt hatası: {_e}')
            else:
                # Timeout kaldırıldı
                save_event(before.guild.id, 'mod', 'Timeout Kaldırıldı', {
                    'user_id':   str(after.id),
                    'user_name': after.display_name,
                    'action':    'untimeout',
                })

        if before.nick != after.nick:
            save_event(before.guild.id, 'member', 'Nick Değişti', {
                'user_id': str(before.id),
                'user_name': str(before),
                'old_nick': before.nick or before.name,
                'new_nick': after.nick or after.name,
            })
            ch = await self.get_log_channel(before.guild)
            if ch:
                e = discord.Embed(title="✏️  NİCK DEĞİŞTİ", color=0x3498DB, timestamp=datetime.datetime.utcnow())
                e.set_thumbnail(url=before.display_avatar.url)
                e.add_field(name="👤 Kullanıcı", value=f"{before.mention}", inline=False)
                e.add_field(name="📝 Eski Nick", value=f"```{before.nick or before.name}```", inline=True)
                e.add_field(name="✨ Yeni Nick", value=f"```{after.nick or after.name}```", inline=True)
                e.set_footer(text=f"Aether Log Sistemi • {before.guild.name}", icon_url=before.guild.icon.url if before.guild.icon else None)
                await ch.send(embed=e)

    # ─── MESAJ EVENTLERİ ─────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild: return
        content = message.content[:500] if message.content else '[Ek/Embed]'
        # Cache'e ekle — silinince içeriği okuyabilelim
        _msg_cache[message.id] = {
            'content': message.content or '',
            'author_id': message.author.id,
            'author_name': message.author.display_name,
            'channel_id': message.channel.id,
            'channel_name': message.channel.name,
            'guild_id': message.guild.id,
            'timestamp': message.created_at.isoformat(),
        }
        # Cache'i max 5000 ile sınırla — aşınca en eski yarısını sil
        if len(_msg_cache) > 5000:
            oldest = list(_msg_cache.keys())[:2500]
            for k in oldest:
                del _msg_cache[k]
        save_event(message.guild.id, 'message', 'Mesaj Yazıldı', {
            'user_id': str(message.author.id),
            'user_name': str(message.author),
            'avatar': str(message.author.display_avatar.url),
            'channel': message.channel.name,
            'channel_id': str(message.channel.id),
            'content': content,
            'message_id': str(message.id),
        })

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if message.author.bot or not message.guild: return
        # Cache'den içeriği al (Discord cache'de yoksa bizim cache'den al)
        cached = _msg_cache.pop(message.id, None)
        content = message.content or (cached['content'] if cached else '') or '[İçerik bulunamadı]'
        save_event(message.guild.id, 'message', 'Mesaj Silindi', {
            'user_id': str(message.author.id),
            'user_name': str(message.author),
            'channel': message.channel.name,
            'channel_id': str(message.channel.id),
            'content': content[:500],
        })
        ch = await self.get_log_channel(message.guild)
        if not ch: return
        e = discord.Embed(
            title="🗑️  MESAJ SİLİNDİ",
            color=0xE74C3C,
            timestamp=datetime.datetime.utcnow()
        )
        e.description = (
            f"```ansi\n\u001b[1;31m✦ MESAJ KALDIRILDI ✦\u001b[0m\n```\n"
            f"{DIV}"
        )
        e.set_thumbnail(url=message.author.display_avatar.url)
        e.add_field(name="👤 Gönderen", value=f"{message.author.mention} `{message.author.id}`", inline=True)
        e.add_field(name="📺 Kanal", value=message.channel.mention, inline=True)
        e.add_field(name="💬 Silinen Mesaj", value=f"```{content[:500] or '[Ek/Embed]'}```", inline=False)
        e.set_footer(text=f"Aether Log Sistemi • {message.guild.name}", icon_url=message.guild.icon.url if message.guild.icon else None)
        await ch.send(embed=e)

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        if before.author.bot or before.content == after.content or not before.guild: return
        save_event(before.guild.id, 'message', 'Mesaj Düzenlendi', {
            'user_id': str(before.author.id),
            'user_name': str(before.author),
            'channel': before.channel.name,
            'channel_id': str(before.channel.id),
            'before': before.content[:300],
            'after': after.content[:300],
        })
        ch = await self.get_log_channel(before.guild)
        if not ch: return
        e = discord.Embed(
            title="✏️  MESAJ DÜZENLENDİ",
            color=0x3498DB,
            timestamp=datetime.datetime.utcnow()
        )
        e.set_thumbnail(url=before.author.display_avatar.url)
        e.add_field(name="👤 Kullanıcı", value=f"{before.author.mention} `{before.author.id}`", inline=True)
        e.add_field(name="📺 Kanal", value=before.channel.mention, inline=True)
        e.add_field(name="📝 Mesaja Git", value=f"[Tıkla]({after.jump_url})", inline=True)
        e.add_field(name="🔴 Önceki Mesaj", value=f"```{before.content[:400] or '[Boş]'}```", inline=False)
        e.add_field(name="🟢 Yeni Mesaj", value=f"```{after.content[:400] or '[Boş]'}```", inline=False)
        e.set_footer(text=f"Aether Log Sistemi • {before.guild.name}", icon_url=before.guild.icon.url if before.guild.icon else None)
        await ch.send(embed=e)

    # ─── SES EVENTLERİ ───────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if before.channel == after.channel: return
        if after.channel:
            action = 'Ses Kanalına Girdi'
            detail = {'channel': after.channel.name}
            color = 0x1ABC9C
            icon = "🔊"
            desc = f"**{member.display_name}** ses kanalına bağlandı."
        else:
            action = 'Ses Kanalından Çıktı'
            detail = {'channel': before.channel.name}
            color = 0x95A5A6
            icon = "🔇"
            desc = f"**{member.display_name}** ses kanalından ayrıldı."

        save_event(member.guild.id, 'voice', action, {
            'user_id': str(member.id),
            'user_name': str(member),
            **detail
        })
        ch = await self.get_log_channel(member.guild)
        if not ch: return
        e = discord.Embed(title=f"{icon}  {action.upper()}", color=color, timestamp=datetime.datetime.utcnow())
        e.set_thumbnail(url=member.display_avatar.url)
        e.description = desc
        e.add_field(name="👤 Kullanıcı", value=f"{member.mention}", inline=True)
        e.add_field(name="🔊 Kanal", value=f"```{detail['channel']}```", inline=True)
        e.set_footer(text=f"Aether Log Sistemi • {member.guild.name}", icon_url=member.guild.icon.url if member.guild.icon else None)
        await ch.send(embed=e)

    # ─── KANAL EVENTLERİ ─────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        save_event(channel.guild.id, 'channel', 'Kanal Oluşturuldu', {
            'channel_id': str(channel.id),
            'channel_name': channel.name,
            'channel_type': str(channel.type),
        })
        ch = await self.get_log_channel(channel.guild)
        if not ch: return
        e = discord.Embed(title="📺  KANAL OLUŞTURULDU", color=0x2ECC71, timestamp=datetime.datetime.utcnow())
        e.add_field(name="📌 Kanal", value=f"```{channel.name}```", inline=True)
        e.add_field(name="📂 Tür", value=f"```{str(channel.type)}```", inline=True)
        e.set_footer(text=f"Aether Log Sistemi • {channel.guild.name}", icon_url=channel.guild.icon.url if channel.guild.icon else None)
        await ch.send(embed=e)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        save_event(channel.guild.id, 'channel', 'Kanal Silindi', {
            'channel_id': str(channel.id),
            'channel_name': channel.name,
            'channel_type': str(channel.type),
        })
        ch = await self.get_log_channel(channel.guild)
        if not ch: return
        e = discord.Embed(title="🗑️  KANAL SİLİNDİ", color=0xE74C3C, timestamp=datetime.datetime.utcnow())
        e.add_field(name="📌 Kanal", value=f"```{channel.name}```", inline=True)
        e.add_field(name="📂 Tür", value=f"```{str(channel.type)}```", inline=True)
        e.set_footer(text=f"Aether Log Sistemi • {channel.guild.name}", icon_url=channel.guild.icon.url if channel.guild.icon else None)
        await ch.send(embed=e)

    @commands.Cog.listener()
    async def on_guild_channel_update(self, before, after):
        if before.name != after.name:
            save_event(before.guild.id, 'channel', 'Kanal Adı Değişti', {
                'channel_id': str(before.id),
                'old_name': before.name,
                'new_name': after.name,
            })

    # ─── ROL EVENTLERİ ───────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_guild_role_create(self, role):
        save_event(role.guild.id, 'role', 'Rol Oluşturuldu', {
            'role_id': str(role.id),
            'role_name': role.name,
        })

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        save_event(role.guild.id, 'role', 'Rol Silindi', {
            'role_id': str(role.id),
            'role_name': role.name,
        })

    @commands.Cog.listener()
    async def on_guild_role_update(self, before, after):
        if before.name != after.name:
            save_event(before.guild.id, 'role', 'Rol Adı Değişti', {
                'role_id': str(before.id),
                'old_name': before.name,
                'new_name': after.name,
            })

    # ─── DAVET EVENTLERİ ─────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_invite_create(self, invite):
        save_event(invite.guild.id, 'invite', 'Davet Oluşturuldu', {
            'user_id': str(invite.inviter.id) if invite.inviter else 'Bilinmiyor',
            'user_name': str(invite.inviter) if invite.inviter else 'Bilinmiyor',
            'code': invite.code,
            'channel': invite.channel.name if invite.channel else '?',
            'max_uses': invite.max_uses or '∞',
        })

    @commands.Cog.listener()
    async def on_invite_delete(self, invite):
        save_event(invite.guild.id, 'invite', 'Davet Silindi', {
            'code': invite.code,
            'channel': invite.channel.name if invite.channel else '?',
        })

    # ─── SUNUCU EVENTLERİ ────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_guild_update(self, before, after):
        if before.name != after.name:
            save_event(before.id, 'server', 'Sunucu Adı Değişti', {
                'old_name': before.name,
                'new_name': after.name,
            })

    # ─── DİSCORD DENETİM KAYDI SYNC ─────────────────────────────────

    async def _sync_discord_audit_log(self):
        """Discord'un kendi denetim kaydını çekip hem audit_log.json hem cache'e yaz"""
        seen_file = 'data/audit_seen.json'
        seen = {}
        if os.path.exists(seen_file):
            try:
                with open(seen_file, 'r', encoding='utf-8') as f:
                    seen = json.load(f)
            except: pass

        action_map = {
            discord.AuditLogAction.ban:              ('mod',     'Ban'),
            discord.AuditLogAction.unban:            ('mod',     'Ban Kaldırıldı'),
            discord.AuditLogAction.kick:             ('mod',     'Kick'),
            discord.AuditLogAction.member_update:    ('mod',     'Üye Güncellendi'),
            discord.AuditLogAction.channel_create:   ('channel', 'Kanal Oluşturuldu'),
            discord.AuditLogAction.channel_delete:   ('channel', 'Kanal Silindi'),
            discord.AuditLogAction.channel_update:   ('channel', 'Kanal Güncellendi'),
            discord.AuditLogAction.role_create:      ('role',    'Rol Oluşturuldu'),
            discord.AuditLogAction.role_delete:      ('role',    'Rol Silindi'),
            discord.AuditLogAction.role_update:      ('role',    'Rol Güncellendi'),
            discord.AuditLogAction.member_role_update: ('role',  'Rol Değişikliği'),
            discord.AuditLogAction.invite_create:    ('invite',  'Davet Oluşturuldu'),
            discord.AuditLogAction.invite_delete:    ('invite',  'Davet Silindi'),
            discord.AuditLogAction.message_delete:   ('message', 'Mesaj Silindi'),
            discord.AuditLogAction.message_bulk_delete: ('message', 'Toplu Mesaj Silindi'),
            discord.AuditLogAction.guild_update:     ('server',  'Sunucu Güncellendi'),
            discord.AuditLogAction.webhook_create:   ('server',  'Webhook Oluşturuldu'),
            discord.AuditLogAction.webhook_delete:   ('server',  'Webhook Silindi'),
        }

        # Cache dosyası — panel buradan okur (hızlı)
        cache_file = 'data/discord_audit_cache.json'
        cache = {}
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    cache = json.load(f)
            except: pass

        for guild in self.bot.guilds:
            gid = str(guild.id)
            last_id = seen.get(gid)
            new_entries = []
            try:
                import datetime as _dt2
                # İlk açılışta son 30 günü çek, sonrasında sadece yenileri
                if not last_id:
                    cutoff = _dt2.datetime.utcnow() - _dt2.timedelta(days=7)
                    async for entry in guild.audit_logs(limit=None, oldest_first=False):
                        if entry.created_at.replace(tzinfo=None) < cutoff:
                            break
                        new_entries.append(entry)
                else:
                    async for entry in guild.audit_logs(limit=100, oldest_first=False):
                        if entry.id <= int(last_id):
                            break
                        new_entries.append(entry)
            except discord.Forbidden:
                continue
            except Exception as e:
                print(f'[LOGS] Audit log çekme hatası ({guild.name}): {e}')
                continue

            if not new_entries:
                continue

            seen[gid] = str(new_entries[0].id)

            if gid not in cache:
                cache[gid] = []

            for entry in reversed(new_entries):
                cat, action_name = action_map.get(entry.action, ('server', str(entry.action).split('.')[-1]))
                target = entry.target
                user = entry.user

                # Timeout tespiti
                if entry.action == discord.AuditLogAction.member_update:
                    after = entry.changes.after
                    if hasattr(after, 'timed_out_until'):
                        action_name = 'Timeout' if getattr(after, 'timed_out_until', None) else 'Timeout Kaldırıldı'
                    else:
                        continue  # İlgisiz member_update

                tname = (getattr(target, 'display_name', None) or
                         getattr(target, 'name', None) or
                         str(getattr(target, 'id', '?')))
                mname = (getattr(user, 'display_name', None) or
                         str(getattr(user, 'id', '?'))) if user else '?'

                ev = {
                    'category':    cat,
                    'action':      action_name,
                    'target_name': tname,
                    'target_id':   str(getattr(target, 'id', '?')),
                    'mod_name':    mname,
                    'mod_id':      str(getattr(user, 'id', '?')) if user else '?',
                    'reason':      entry.reason or '',
                    'timestamp':   entry.created_at.isoformat(),
                    'audit_id':    str(entry.id),
                    'source':      'discord_audit',
                }

                # audit_log.json'a da yaz
                save_event(guild.id, cat, action_name, {
                    'target_name': tname,
                    'target_id':   str(getattr(target, 'id', '?')),
                    'mod_name':    mname,
                    'mod_id':      str(getattr(user, 'id', '?')) if user else '?',
                    'reason':      entry.reason or '',
                    'audit_id':    str(entry.id),
                    'source':      'discord_audit',
                })

                cache[gid].append(ev)

            # Cache'i max 1000 kayıtla sınırla
            if len(cache[gid]) > 1000:
                cache[gid] = cache[gid][-1000:]

        # Cache'i kaydet
        try:
            os.makedirs('data', exist_ok=True)
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f'[LOGS] Cache yazma hatası: {e}')

        # Görülen ID'leri kaydet
        try:
            with open(seen_file, 'w', encoding='utf-8') as f:
                json.dump(seen, f)
        except: pass

    @commands.Cog.listener()
    async def on_ready(self):
        """Bot hazır olunca ilk sync yap, sonra her 30 saniyede bir"""
        import asyncio
        await asyncio.sleep(5)
        asyncio.get_event_loop().create_task(self._audit_sync_loop())

    async def _audit_sync_loop(self):
        import asyncio
        fail_count = 0
        while True:
            try:
                await self._sync_discord_audit_log()
                fail_count = 0
                await asyncio.sleep(30)
            except Exception as e:
                fail_count += 1
                wait = min(60 * fail_count, 300)
                print(f'[LOGS] Audit sync hatası ({fail_count}): {e} — {wait}sn bekleniyor')
                await asyncio.sleep(wait)


async def setup(bot):
    await bot.add_cog(Logs(bot))
