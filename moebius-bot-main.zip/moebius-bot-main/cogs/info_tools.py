"""Bilgi ve arac komutlari — prefix komutlari (!uptime, !botinfo, vb.)"""
import discord
from discord.ext import commands
import time
import re as _re
import base64 as _b64
from datetime import datetime

START_TIME = time.time()

class InfoTools(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="uptime")
    async def uptime(self, ctx):
        elapsed = int(time.time() - START_TIME)
        d, rem = divmod(elapsed, 86400)
        h, rem = divmod(rem, 3600)
        m, s = divmod(rem, 60)
        e = discord.Embed(title="⏱️ UPTIME", color=0xdc143c, timestamp=datetime.utcnow())
        e.add_field(name="🕐 Çalışma Süresi", value=f"```{d}g {h}s {m}d {s}sn```")
        e.set_thumbnail(url=self.bot.user.display_avatar.url)
        await ctx.send(embed=e)

    @commands.command(name="botinfo")
    async def botinfo(self, ctx):
        b = self.bot
        e = discord.Embed(title=f"🤖 {b.user.name}", color=0xdc143c, timestamp=datetime.utcnow())
        e.set_thumbnail(url=b.user.display_avatar.url)
        e.add_field(name="🏠 Sunucu", value=f"```{len(b.guilds)}```", inline=True)
        e.add_field(name="👥 Kullanıcı", value=f"```{sum(g.member_count for g in b.guilds)}```", inline=True)
        e.add_field(name="📡 Ping", value=f"```{round(b.latency*1000)}ms```", inline=True)
        await ctx.send(embed=e)

    @commands.command(name="rolbilgi")
    async def rol_bilgi(self, ctx, *, rol: discord.Role):
        e = discord.Embed(title=f"🎭 ROL: {rol.name}", color=rol.color if rol.color.value else 0xdc143c)
        e.add_field(name="🆔 ID", value=f"```{rol.id}```", inline=True)
        e.add_field(name="👥 Üye", value=f"```{len(rol.members)}```", inline=True)
        e.add_field(name="🎨 Renk", value=f"```{rol.color}```", inline=True)
        e.add_field(name="📅 Oluşturulma", value=f"<t:{int(rol.created_at.timestamp())}:R>", inline=True)
        await ctx.send(embed=e)

    @commands.command(name="kanalbilgi")
    async def kanal_bilgi(self, ctx, kanal: discord.TextChannel = None):
        ch = kanal or ctx.channel
        e = discord.Embed(title=f"📺 KANAL: #{ch.name}", color=0xdc143c)
        e.add_field(name="🆔 ID", value=f"```{ch.id}```", inline=True)
        e.add_field(name="📁 Kategori", value=f"```{ch.category.name if ch.category else 'Yok'}```", inline=True)
        e.add_field(name="📅 Oluşturulma", value=f"<t:{int(ch.created_at.timestamp())}:R>", inline=True)
        if ch.topic:
            e.add_field(name="📝 Konu", value=f"```{ch.topic[:100]}```", inline=False)
        await ctx.send(embed=e)

    @commands.command(name="emojiler")
    async def emoji_listesi(self, ctx):
        emojis = ctx.guild.emojis
        if not emojis:
            await ctx.send("❌ Özel emoji yok!")
            return
        e = discord.Embed(title="😀 EMOJİ LİSTESİ", color=0xdc143c)
        e.description = f"Toplam **{len(emojis)}** emoji\n" + ' '.join(str(em) for em in emojis[:40])
        await ctx.send(embed=e)

    @commands.command(name="davet")
    async def davet_link(self, ctx):
        url = discord.utils.oauth_url(self.bot.user.id, permissions=discord.Permissions(8))
        e = discord.Embed(title="🔗 BOT DAVETİ", color=0xdc143c)
        e.description = f"[**➜ Botu Sunucuna Ekle**]({url})"
        e.set_thumbnail(url=self.bot.user.display_avatar.url)
        await ctx.send(embed=e)

    @commands.command(name="renk")
    async def renk(self, ctx, hex_kod: str):
        hex_kod = hex_kod.lstrip('#')
        try:
            r, g, b = int(hex_kod[0:2], 16), int(hex_kod[2:4], 16), int(hex_kod[4:6], 16)
            color_int = int(hex_kod, 16)
        except (ValueError, IndexError):
            await ctx.send("❌ Geçersiz hex kodu! Örnek: `!renk ff0000`")
            return
        e = discord.Embed(title=f"🎨 #{hex_kod.upper()}", color=color_int)
        e.add_field(name="HEX", value=f"```#{hex_kod.upper()}```", inline=True)
        e.add_field(name="RGB", value=f"```rgb({r}, {g}, {b})```", inline=True)
        await ctx.send(embed=e)

    @commands.command(name="zaman")
    async def zaman(self, ctx):
        ts = int(datetime.utcnow().timestamp())
        e = discord.Embed(title="🕐 ZAMAN", color=0xdc143c)
        e.add_field(name="⏰ Kısa", value=f"<t:{ts}:t>", inline=True)
        e.add_field(name="📅 Uzun", value=f"<t:{ts}:F>", inline=True)
        e.add_field(name="🔄 Göreceli", value=f"<t:{ts}:R>", inline=True)
        await ctx.send(embed=e)

    @commands.command(name="hesap")
    async def hesap(self, ctx, *, islem: str):
        if not _re.match(r'^[\d\s\+\-\*\/\.\(\)]+$', islem):
            await ctx.send("❌ Sadece sayı ve operatörler kullanabilirsin!")
            return
        try:
            sonuc = eval(islem)
            e = discord.Embed(title="🧮 HESAP", color=0xdc143c)
            e.add_field(name="İşlem", value=f"`{islem}`")
            e.add_field(name="Sonuç", value=f"`{sonuc}`")
            await ctx.send(embed=e)
        except Exception:
            await ctx.send("❌ Geçersiz işlem!")

    @commands.command(name="base64")
    async def base64_cmd(self, ctx, islem: str, *, metin: str):
        try:
            if islem == "encode":
                sonuc = _b64.b64encode(metin.encode()).decode()
            else:
                sonuc = _b64.b64decode(metin.encode()).decode()
            e = discord.Embed(title=f"BASE64 {islem.upper()}", color=0xdc143c)
            e.add_field(name="Girdi", value=f"`{metin[:100]}`", inline=False)
            e.add_field(name="Çıktı", value=f"`{sonuc[:200]}`", inline=False)
            await ctx.send(embed=e)
        except Exception:
            await ctx.send("❌ Dönüştürme başarısız!")

    @commands.command(name="banner")
    async def banner(self, ctx):
        g = ctx.guild
        if not g.banner:
            await ctx.send("Bu sunucunun banneri yok!")
            return
        e = discord.Embed(title=f"{g.name} Banner", color=0xdc143c)
        e.set_image(url=g.banner.url)
        await ctx.send(embed=e)

    @commands.command(name="roluyeler")
    async def rol_uyeler(self, ctx, *, rol: discord.Role):
        members = rol.members
        if not members:
            await ctx.send(f"{rol.name} rolünde kimse yok!")
            return
        liste = ', '.join(m.display_name for m in members[:30])
        if len(members) > 30:
            liste += f" (+{len(members)-30} daha)"
        e = discord.Embed(title=f"{rol.name} — {len(members)} üye", color=0xdc143c, description=liste)
        await ctx.send(embed=e)

    @commands.command(name="ilkmesaj")
    async def ilk_mesaj(self, ctx, kanal: discord.TextChannel = None):
        ch = kanal or ctx.channel
        async for msg in ch.history(limit=1, oldest_first=True):
            e = discord.Embed(title="📌 İLK MESAJ", color=0xdc143c,
                description=f"[Mesaja git]({msg.jump_url})\n\n{msg.content[:200] if msg.content else '*(embed)*'}")
            await ctx.send(embed=e)
            return
        await ctx.send("Mesaj bulunamadı!")

    @commands.command(name="duyuru")
    @commands.has_permissions(administrator=True)
    async def duyuru(self, ctx, kanal: discord.TextChannel, baslik: str, *, icerik: str):
        e = discord.Embed(title=baslik, description=icerik, color=0xdc143c)
        e.set_footer(text=f"Duyuran: {ctx.author.display_name}")
        await kanal.send(embed=e)
        await ctx.message.delete()

    @commands.command(name="say")
    @commands.has_permissions(administrator=True)
    async def say(self, ctx, kanal: discord.TextChannel = None, *, mesaj: str):
        ch = kanal or ctx.channel
        await ch.send(mesaj)
        try:
            await ctx.message.delete()
        except Exception:
            pass


async def setup(bot):
    await bot.add_cog(InfoTools(bot))
