﻿import discord
from discord.ext import commands
from discord import app_commands
import json
import os
from datetime import datetime, timezone
from cogs.embed_utils import _divider, now_ts

APPLY_CHANNEL_ID = 1484308081302306846
APPS_FILE = "data/staff_apps.json"

# Onaylanınca verilecek roller (ID listesi)
STAFF_ROLE_IDS = [1384282749338386593, 1434986280399147069]

def load_apps():
    os.makedirs("data", exist_ok=True)
    if os.path.exists(APPS_FILE):
        with open(APPS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_apps(data):
    with open(APPS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


class StaffApplyModal(discord.ui.Modal, title="⚔️ Yetkili Başvuru Formu"):
    yas = discord.ui.TextInput(label="Yaşınız", placeholder="Örn: 18", max_length=3)
    tecrube = discord.ui.TextInput(
        label="Moderasyon Tecrübeniz",
        placeholder="Daha önce hangi sunucularda yetkili oldunuz?",
        style=discord.TextStyle.paragraph, max_length=500
    )
    neden = discord.ui.TextInput(
        label="Neden Yetkili Olmak İstiyorsunuz?",
        placeholder="Motivasyonunuzu açıklayın...",
        style=discord.TextStyle.paragraph, max_length=600
    )
    aktiflik = discord.ui.TextInput(
        label="Günlük Aktiflik (saat)",
        placeholder="Örn: 3-4 saat",
        max_length=50
    )
    ekstra = discord.ui.TextInput(
        label="Eklemek İstedikleriniz",
        placeholder="Kendiniz hakkında ekstra bilgi...",
        style=discord.TextStyle.paragraph,
        required=False, max_length=400
    )

    async def on_submit(self, interaction: discord.Interaction):
        apps = load_apps()
        app_id = str(int(datetime.now(timezone.utc).timestamp()))
        uid = str(interaction.user.id)

        app_data = {
            "app_id": app_id,
            "user_id": uid,
            "user_name": str(interaction.user),
            "display_name": interaction.user.display_name,
            "avatar": str(interaction.user.display_avatar.url),
            "guild_id": str(interaction.guild.id),
            "guild_name": interaction.guild.name,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "status": "pending",
            "answers": {
                "yas": self.yas.value,
                "tecrube": self.tecrube.value,
                "neden": self.neden.value,
                "aktiflik": self.aktiflik.value,
                "ekstra": self.ekstra.value or "—"
            },
            "message_id": None,
            "reviewed_by": None,
            "review_note": None
        }

        apps[app_id] = app_data
        save_apps(apps)

        # Başvuru kanalına gönder
        channel = interaction.guild.get_channel(APPLY_CHANNEL_ID)
        if not channel:
            await interaction.response.send_message("❌ Başvuru kanalı bulunamadı.", ephemeral=True)
            return

        embed = discord.Embed(
            title="📋 YENİ YETKİLİ BAŞVURUSU",
            color=0xDC143C,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_author(
            name=f"{interaction.user.display_name} ({interaction.user})",
            icon_url=interaction.user.display_avatar.url
        )
        embed.set_thumbnail(url=interaction.user.display_avatar.url)

        embed.add_field(name="👤 Kullanıcı", value=f"{interaction.user.mention}\n`{interaction.user.id}`", inline=True)
        embed.add_field(name="🎂 Yaş", value=self.yas.value, inline=True)
        embed.add_field(name="⏰ Günlük Aktiflik", value=self.aktiflik.value, inline=True)
        embed.add_field(name="🏆 Moderasyon Tecrübesi", value=f"```{self.tecrube.value}```", inline=False)
        embed.add_field(name="💬 Neden Yetkili Olmak İstiyor?", value=f"```{self.neden.value}```", inline=False)
        if self.ekstra.value:
            embed.add_field(name="📝 Ekstra Bilgi", value=f"```{self.ekstra.value}```", inline=False)

        embed.set_footer(
            text=f"Başvuru ID: {app_id} • {interaction.guild.name}",
            icon_url=interaction.guild.icon.url if interaction.guild.icon else None
        )

        view = StaffReviewView(app_id)
        msg = await channel.send(embed=embed, view=view)

        # Mesaj ID'sini kaydet
        apps[app_id]["message_id"] = str(msg.id)
        save_apps(apps)

        await interaction.response.send_message(
            "✅ Başvurun alındı! Yetkililer inceleyecek, sonucu DM ile bildirilecek.",
            ephemeral=True
        )


class StaffReviewView(discord.ui.View):
    def __init__(self, app_id: str = None):
        super().__init__(timeout=None)
        self.app_id = app_id

    def get_app_id_from_custom(self, custom_id):
        # custom_id: "approve_APPID" veya "reject_APPID"
        parts = custom_id.split("_", 1)
        return parts[1] if len(parts) == 2 else None

    @discord.ui.button(label="✅ Onayla", style=discord.ButtonStyle.success, custom_id="staff_approve")
    async def approve(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ Yetkin yok.", ephemeral=True)
            return

        # Embed'den app_id bul
        app_id = None
        if interaction.message and interaction.message.embeds:
            footer = interaction.message.embeds[0].footer.text or ""
            for part in footer.split("•"):
                part = part.strip()
                if part.startswith("Başvuru ID:"):
                    app_id = part.replace("Başvuru ID:", "").strip()

        if not app_id:
            await interaction.response.send_message("❌ Başvuru ID bulunamadı.", ephemeral=True)
            return

        apps = load_apps()
        if app_id not in apps:
            await interaction.response.send_message("❌ Başvuru bulunamadı.", ephemeral=True)
            return

        apps[app_id]["status"] = "approved"
        apps[app_id]["reviewed_by"] = str(interaction.user)
        save_apps(apps)

        # Kullanıcıya rol ver
        try:
            member = interaction.guild.get_member(int(apps[app_id]["user_id"]))
            if not member:
                member = await interaction.guild.fetch_member(int(apps[app_id]["user_id"]))
            if member:
                for role_id in STAFF_ROLE_IDS:
                    role = interaction.guild.get_role(role_id)
                    if role:
                        await member.add_roles(role, reason=f'Yetkili başvurusu onaylandı - {interaction.user}')
        except Exception as e:
            print(f'[StaffApply] Rol verme hatası: {e}')

        # Embed güncelle
        embed = interaction.message.embeds[0]
        embed.color = 0x2ECC71
        embed.title = "✅ BAŞVURU ONAYLANDI"
        embed.add_field(name="✅ Onaylayan", value=f"{interaction.user.mention}", inline=True)

        await interaction.message.edit(embed=embed, view=None)

        # Kullanıcıya DM
        try:
            user = await interaction.client.fetch_user(int(apps[app_id]["user_id"]))
            ts = int(datetime.now(timezone.utc).timestamp())
            dm_embed = discord.Embed(
                title="🎉  Yetkili Başvurun Onaylandı!",
                color=0x2ECC71,
                timestamp=datetime.now(timezone.utc)
            )
            dm_embed.description = (
                f"```ansi\n\u001b[1;32m✔ BAŞVURUN ONAYLANDI\u001b[0m\n```\n"
                f"{_divider()}\n\n"
                f"**{interaction.guild.name}** sunucusundaki yetkili başvurun **onaylandı**! 🎊\n\n"
                "> Sunucuya girerek yetkililerle iletişime geçebilirsin.\n"
                "> Aramıza hoş geldin, başarılar dileriz! 💪\n\n"
                f"{_divider()}"
            )
            dm_embed.set_thumbnail(url=interaction.guild.icon.url if interaction.guild.icon else None)
            dm_embed.add_field(name="✅ Durum", value="```Onaylandı```", inline=True)
            dm_embed.add_field(name="👮 İnceleyen", value=f"```{interaction.user.display_name}```", inline=True)
            dm_embed.add_field(name="🕐 Tarih", value=f"<t:{ts}:F>", inline=False)
            dm_embed.add_field(name="💡 Sonraki Adım", value="*Sunucuya girerek yetkili rolünü almak için yönetimle iletişime geç.*", inline=False)
            dm_embed.set_image(url="https://media.tenor.com/ZBDpMFBMFpkAAAAC/celebration-party.gif")
            dm_embed.set_footer(
                text=f"Aether Yetkili • {interaction.guild.name}",
                icon_url=interaction.guild.icon.url if interaction.guild.icon else None
            )
            await user.send(embed=dm_embed)
        except:
            pass

        await interaction.response.send_message("✅ Başvuru onaylandı, kullanıcıya DM gönderildi.", ephemeral=True)

    @discord.ui.button(label="❌ Reddet", style=discord.ButtonStyle.danger, custom_id="staff_reject")
    async def reject(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ Yetkin yok.", ephemeral=True)
            return

        await interaction.response.send_modal(RejectReasonModal(interaction.message))


class RejectReasonModal(discord.ui.Modal, title="❌ Red Sebebi"):
    reason = discord.ui.TextInput(
        label="Red Sebebi",
        placeholder="Başvuruyu neden reddediyorsunuz?",
        style=discord.TextStyle.paragraph,
        max_length=500
    )

    def __init__(self, message: discord.Message):
        super().__init__()
        self.message = message

    async def on_submit(self, interaction: discord.Interaction):
        # app_id bul
        app_id = None
        if self.message.embeds:
            footer = self.message.embeds[0].footer.text or ""
            for part in footer.split("•"):
                part = part.strip()
                if part.startswith("Başvuru ID:"):
                    app_id = part.replace("Başvuru ID:", "").strip()

        apps = load_apps()
        if app_id and app_id in apps:
            apps[app_id]["status"] = "rejected"
            apps[app_id]["reviewed_by"] = str(interaction.user)
            apps[app_id]["review_note"] = self.reason.value
            save_apps(apps)

            # Kullanıcıya DM
            try:
                user = await interaction.client.fetch_user(int(apps[app_id]["user_id"]))
                ts = int(datetime.now(timezone.utc).timestamp())
                dm_embed = discord.Embed(
                    title="❌  Yetkili Başvurun Reddedildi",
                    color=0xE74C3C,
                    timestamp=datetime.now(timezone.utc)
                )
                dm_embed.description = (
                    f"```ansi\n\u001b[1;31m✘ BAŞVURUN REDDEDİLDİ\u001b[0m\n```\n"
                    f"{_divider()}\n\n"
                    f"**{interaction.guild.name}** sunucusundaki yetkili başvurun **reddedildi**.\n\n"
                    "> Daha sonra tekrar başvurabilirsin.\n"
                    "> Kendini geliştirmeye devam et! 💪\n\n"
                    f"{_divider()}"
                )
                dm_embed.set_thumbnail(url=interaction.guild.icon.url if interaction.guild.icon else None)
                dm_embed.add_field(name="❌ Durum", value="```Reddedildi```", inline=True)
                dm_embed.add_field(name="👮 İnceleyen", value=f"```{interaction.user.display_name}```", inline=True)
                dm_embed.add_field(name="📝 Red Sebebi", value=f"```{self.reason.value}```", inline=False)
                dm_embed.add_field(name="🕐 Tarih", value=f"<t:{ts}:F>", inline=False)
                dm_embed.add_field(name="💡 Bilgi", value="*Belirli bir süre sonra tekrar başvurabilirsin.*", inline=False)
                dm_embed.set_image(url="https://media.tenor.com/x8v1oNUOmg4AAAAC/ban-hammer.gif")
                dm_embed.set_footer(
                    text=f"{interaction.guild.name} • Yetkili Sistemi",
                    icon_url=interaction.guild.icon.url if interaction.guild.icon else None
                )
                await user.send(embed=dm_embed)
            except:
                pass

        # Embed güncelle
        embed = self.message.embeds[0]
        embed.color = 0xE74C3C
        embed.title = "❌ BAŞVURU REDDEDİLDİ"
        embed.add_field(name="❌ Reddeden", value=f"{interaction.user.mention}", inline=True)
        embed.add_field(name="📝 Sebep", value=self.reason.value, inline=False)

        await self.message.edit(embed=embed, view=None)
        await interaction.response.send_message("❌ Başvuru reddedildi.", ephemeral=True)


class StaffApply(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        bot.add_view(StaffReviewView())  # Persistent

    @app_commands.command(name="staff-basvuru", description="Yetkili başvuru formunu aç")
    async def staff_apply(self, interaction: discord.Interaction):
        # Zaten bekleyen başvurusu var mı?
        apps = load_apps()
        uid = str(interaction.user.id)
        for app in apps.values():
            if app["user_id"] == uid and app["status"] == "pending":
                await interaction.response.send_message(
                    "⚠️ Zaten bekleyen bir başvurun var! Sonuçlanmasını bekle.",
                    ephemeral=True
                )
                return

        await interaction.response.send_modal(StaffApplyModal())

    @app_commands.command(name="staff-basvurular", description="Tüm başvuruları listele")
    @app_commands.checks.has_permissions(administrator=True)
    async def staff_list(self, interaction: discord.Interaction, durum: str = "pending"):
        apps = load_apps()
        filtered = [a for a in apps.values() if a.get("status") == durum and a.get("guild_id") == str(interaction.guild.id)]

        if not filtered:
            await interaction.response.send_message(f"'{durum}' durumunda başvuru yok.", ephemeral=True)
            return

        embed = discord.Embed(title=f"📋 Başvurular — {durum.upper()}", color=0xDC143C)
        for app in filtered[-10:]:
            embed.add_field(
                name=f"{app['display_name']} ({app['user_name']})",
                value=f"ID: `{app['app_id']}`\nTarih: <t:{int(datetime.fromisoformat(app['timestamp']).timestamp())}:R>",
                inline=False
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(StaffApply(bot), guilds=[discord.Object(id=1421244140359909513), discord.Object(id=1107038411895881788)])
