import discord
from discord.ext import commands
import json
import os

class AutoRoleLevel(commands.Cog):
    """XP seviyesine göre otomatik rol ver"""

    def __init__(self, bot):
        self.bot = bot

    def get_level_roles(self, guild_id):
        f = f'data/level_roles_{guild_id}.json'
        if not os.path.exists(f):
            return {}
        with open(f, 'r', encoding='utf-8') as fp:
            return json.load(fp)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return

        # XP dosyasını oku
        xp_file = f'data/xp_{message.guild.id}.json'
        if not os.path.exists(xp_file):
            return

        with open(xp_file, 'r', encoding='utf-8') as fp:
            xp_data = json.load(fp)

        user_data = xp_data.get(str(message.author.id))
        if not user_data:
            return

        level = user_data.get('level', 0)
        level_roles = self.get_level_roles(message.guild.id)

        if not level_roles:
            return

        member = message.author
        for required_level, role_id in level_roles.items():
            if level >= int(required_level):
                role = message.guild.get_role(int(role_id))
                if role and role not in member.roles:
                    try:
                        await member.add_roles(role, reason=f'Level {required_level} rolü')
                    except:
                        pass

    @commands.command(name='level-rol-ekle')
    @commands.has_permissions(administrator=True)
    async def add_level_role(self, ctx, level: int, role: discord.Role):
        """Belirli bir level için rol ata
        
        Kullanım: !level-rol-ekle 5 @Rol
        """
        f = f'data/level_roles_{ctx.guild.id}.json'
        os.makedirs('data', exist_ok=True)
        data = {}
        if os.path.exists(f):
            with open(f, 'r', encoding='utf-8') as fp:
                data = json.load(fp)

        data[str(level)] = str(role.id)

        with open(f, 'w', encoding='utf-8') as fp:
            json.dump(data, fp, indent=2)

        await ctx.send(f'✅ Level **{level}** için {role.mention} rolü ayarlandı!')

    @commands.command(name='level-rol-sil')
    @commands.has_permissions(administrator=True)
    async def remove_level_role(self, ctx, level: int):
        """Level rolünü kaldır"""
        f = f'data/level_roles_{ctx.guild.id}.json'
        if not os.path.exists(f):
            await ctx.send('❌ Kayıtlı level rolü yok!')
            return

        with open(f, 'r', encoding='utf-8') as fp:
            data = json.load(fp)

        data.pop(str(level), None)

        with open(f, 'w', encoding='utf-8') as fp:
            json.dump(data, fp, indent=2)

        await ctx.send(f'✅ Level **{level}** rolü kaldırıldı!')

    @commands.command(name='level-roller')
    async def list_level_roles(self, ctx):
        """Level rollerini listele"""
        data = self.get_level_roles(ctx.guild.id)
        if not data:
            await ctx.send('❌ Henüz level rolü ayarlanmamış!')
            return

        embed = discord.Embed(title='🏆 Level Rolleri', color=0xFFD700)
        for level, role_id in sorted(data.items(), key=lambda x: int(x[0])):
            role = ctx.guild.get_role(int(role_id))
            embed.add_field(
                name=f'Level {level}',
                value=role.mention if role else f'Silinmiş rol ({role_id})',
                inline=False
            )
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(AutoRoleLevel(bot))
