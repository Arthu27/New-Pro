﻿import time
import requests
import subprocess
import os
import zipfile
import sys

GITHUB_TOKEN = "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"
REPO_API = "https://api.github.com/repos/Arthu27/moebius-bot/commits/main"
ZIP_URL = "https://github.com/Arthu27/moebius-bot/archive/refs/heads/main.zip"

# Script'in bulunduğu dizini otomatik tespit et (VSCode workspace)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BOT_DIR = SCRIPT_DIR  # VSCode workspace'ini kullan
LAST_COMMIT_FILE = os.path.join(BOT_DIR, "last_commit.txt")
BOT_LOG = os.path.join(BOT_DIR, "bot_output.log")

ENV_CONTENT = """TOKEN=MTQyMTQxODcwMDQ1MTM0ODUyMA.GxBKSZ.XdD5BcKTxfS0yJh5WN9LHTUIiXyFbPumGrRnDk
GROQ_API_KEY=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
MISTRAL_API_KEY=tnYGoQBLy5QYfCLkk48Pxhk7yERvXDrt
MISTRAL_API_KEY_2=Q2v4j4FTcdek6DkPZMPH53t3PLxN6t7K
MISTRAL_API_KEY_3=cEEfVtDrPwkZtPopLlCBX5uGvSZPrDVB
MISTRAL_API_KEY_4=FIWdcnXZu9sNp1hWgGojwVVPaNP5ywDg
MISTRAL_API_KEY_5=Ee2QOEECfMiaoBpamDlBY4MgrEX6viNw
OPENROUTER_API_KEY=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
OPENROUTER_KEY_2=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
OPENROUTER_KEY_3=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
OPENROUTER_KEY_4=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
OPENROUTER_KEY_5=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
OPENROUTER_KEY_6=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
OPENROUTER_KEY_7=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
OPENROUTER_KEY_8=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
OPENROUTER_KEY_9=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
OPENROUTER_KEY_10=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
OPENROUTER_KEY_11=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
OPENROUTER_KEY_12=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
OWNER_ID=987430047889637426"""

MY_PID = os.getpid()


def log(msg):
    print(msg, flush=True)


def get_remote_commit():
    """GitHub API'den son commit hash'ini al"""
    try:
        headers = {"Authorization": f"token {GITHUB_TOKEN}"}
        r = requests.get(REPO_API, headers=headers, timeout=10)
        if r.status_code == 200:
            return r.json()["sha"]
    except Exception as e:
        log(f"[AUTO-UPDATE] Commit alma hatasi: {e}")
    return None


def get_local_commit():
    """Local git repo'dan HEAD commit hash'ini al"""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=BOT_DIR, capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return None


def get_last_commit():
    """Geriye dönük uyumluluk için"""
    return get_remote_commit()


def is_bot_running():
    """main.py process'i calisiyor mu kontrol et"""
    try:
        result = subprocess.run(
            'wmic process where "commandline like \'%main.py%\'" get processid',
            shell=True, capture_output=True, text=True
        )
        for line in result.stdout.strip().split('\n'):
            line = line.strip()
            if line.isdigit() and int(line) != MY_PID:
                return True
    except Exception:
        pass
    return False


def kill_bot():
    """Sadece main.py process'lerini oldur"""
    try:
        result = subprocess.run(
            'wmic process where "commandline like \'%main.py%\'" get processid',
            shell=True, capture_output=True, text=True
        )
        for line in result.stdout.strip().split('\n'):
            line = line.strip()
            if line.isdigit():
                pid = int(line)
                if pid != MY_PID:
                    subprocess.run(f'taskkill /f /pid {pid}', shell=True, capture_output=True)
                    log(f"[AUTO-UPDATE] Bot process kapatildi (PID: {pid})")
    except Exception as e:
        log(f"[AUTO-UPDATE] Kill hatasi: {e}")

    subprocess.run('taskkill /f /im cloudflared.exe', shell=True, capture_output=True)
    time.sleep(4)


def start_bot():
    """Botu arka planda baslatir, log dosyasina yazar"""
    try:
        os.makedirs(BOT_DIR, exist_ok=True)
        
        # main.py'nin tam yolunu al
        main_py = os.path.join(BOT_DIR, "main.py")
        if not os.path.exists(main_py):
            log(f"[AUTO-UPDATE] HATA: main.py bulunamadi: {main_py}")
            return False
        
        # data/ klasörünü kontrol et
        data_dir = os.path.join(BOT_DIR, "data")
        os.makedirs(data_dir, exist_ok=True)
        
        # .env dosyasını kontrol et
        env_file = os.path.join(BOT_DIR, ".env")
        if not os.path.exists(env_file):
            log("[AUTO-UPDATE] .env bulunamadi, olusturuluyor...")
            with open(env_file, "w", encoding="utf-8") as f:
                f.write(ENV_CONTENT)
        
        log(f"[AUTO-UPDATE] Bot dizini: {BOT_DIR}")
        log(f"[AUTO-UPDATE] Python: {sys.executable}")
        log(f"[AUTO-UPDATE] main.py: {main_py}")
        
        log_file = open(BOT_LOG, 'w', encoding='utf-8', errors='replace')
        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        proc = subprocess.Popen(
            [sys.executable, main_py],
            cwd=BOT_DIR,
            stdout=log_file,
            stderr=log_file,
            stdin=subprocess.DEVNULL,
            env=env,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP  # Signal izolasyonu
        )
        log(f"[AUTO-UPDATE] Bot baslatildi! PID: {proc.pid} | Log: {BOT_LOG}")
        
        # 3 saniye bekle ve process'in hala çalıştığını kontrol et
        time.sleep(3)
        if proc.poll() is not None:
            log(f"[AUTO-UPDATE] UYARI: Bot hemen kapandi! Exit code: {proc.returncode}")
            log(f"[AUTO-UPDATE] Log dosyasini kontrol et: {BOT_LOG}")
            return False
        
        return True
    except Exception as e:
        log(f"[AUTO-UPDATE] Bot baslatma HATASI: {e}")
        import traceback
        log(traceback.format_exc())
        return False


def git_pull():
    """git pull ile repoyu guncelle"""
    log("[AUTO-UPDATE] git pull yapiliyor...")
    try:
        result = subprocess.run(
            ["git", "pull", "origin", "main"],
            cwd=BOT_DIR,
            capture_output=True,
            text=True,
            timeout=60
        )
        log(f"[AUTO-UPDATE] git pull stdout: {result.stdout.strip()}")
        if result.returncode != 0:
            log(f"[AUTO-UPDATE] git pull stderr: {result.stderr.strip()}")
            # Conflict varsa force reset yap
            log("[AUTO-UPDATE] Conflict algilandi, force reset yapiliyor...")
            subprocess.run(["git", "fetch", "origin"], cwd=BOT_DIR, capture_output=True, timeout=30)
            subprocess.run(["git", "reset", "--hard", "origin/main"], cwd=BOT_DIR, capture_output=True, timeout=30)
            log("[AUTO-UPDATE] Force reset tamamlandi")
        else:
            log("[AUTO-UPDATE] Dosyalar guncellendi")

        # .env yoksa olustur
        env_path = os.path.join(BOT_DIR, ".env")
        if not os.path.exists(env_path):
            with open(env_path, "w", encoding="utf-8") as f:
                f.write(ENV_CONTENT)
            log("[AUTO-UPDATE] .env olusturuldu")

    except Exception as e:
        raise Exception(f"git pull hatasi: {e}")


def download_and_extract():
    """GitHub'dan ZIP indir ve BOT_DIR'e ac (fallback)"""
    log("[AUTO-UPDATE] Dosyalar indiriliyor...")
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    r = requests.get(ZIP_URL, headers=headers, timeout=60)
    if r.status_code != 200:
        raise Exception(f"Indirme hatasi HTTP {r.status_code}")

    zip_path = os.path.join(BOT_DIR, "aether-update.zip")
    with open(zip_path, "wb") as f:
        f.write(r.content)
    log(f"[AUTO-UPDATE] ZIP indirildi ({len(r.content)//1024} KB)")

    with zipfile.ZipFile(zip_path, 'r') as zf:
        for member in zf.infolist():
            target = member.filename.replace("moebius-bot-main/", "", 1).replace("aether-bot-main/", "", 1)
            if not target:
                continue
            target_path = os.path.join(BOT_DIR, target)
            if target.startswith("data/"):
                continue
            if member.is_dir():
                os.makedirs(target_path, exist_ok=True)
            else:
                os.makedirs(os.path.dirname(target_path), exist_ok=True)
                try:
                    with zf.open(member) as src, open(target_path, 'wb') as dst:
                        dst.write(src.read())
                except Exception as e:
                    log(f"[AUTO-UPDATE] Dosya yazma hatasi ({target}): {e}")

    os.remove(zip_path)
    log("[AUTO-UPDATE] Dosyalar guncellendi (ZIP)")

    env_path = os.path.join(BOT_DIR, ".env")
    if not os.path.exists(env_path):
        with open(env_path, "w", encoding="utf-8") as f:
            f.write(ENV_CONTENT)
        log("[AUTO-UPDATE] .env olusturuldu")


def update_bot():
    log("[AUTO-UPDATE] === GUNCELLEME BASLADI ===")
    try:
        kill_bot()
        # Önce git pull dene, git repo değilse ZIP fallback
        git_dir = os.path.join(BOT_DIR, ".git")
        if os.path.isdir(git_dir):
            git_pull()
        else:
            log("[AUTO-UPDATE] .git bulunamadi, ZIP ile guncelleniyor...")
            download_and_extract()
        time.sleep(2)
        start_bot()
        log("[AUTO-UPDATE] === GUNCELLEME TAMAMLANDI ===")
    except Exception as e:
        log(f"[AUTO-UPDATE] Guncelleme hatasi: {e}")
        log("[AUTO-UPDATE] Hata oldu, bot yeniden baslatiliyor...")
        start_bot()


def main():
    log(f"[AUTO-UPDATE] Baslatildi (PID: {MY_PID})")
    log(f"[AUTO-UPDATE] Script dizini: {SCRIPT_DIR}")
    log(f"[AUTO-UPDATE] Bot dizini: {BOT_DIR}")
    log(f"[AUTO-UPDATE] Python: {sys.executable}")
    
    # Gerekli dosyaları kontrol et
    main_py = os.path.join(BOT_DIR, "main.py")
    if not os.path.exists(main_py):
        log(f"[AUTO-UPDATE] KRITIK HATA: main.py bulunamadi: {main_py}")
        log("[AUTO-UPDATE] Lutfen script'i bot dizininde calistirin!")
        return
    
    log("[AUTO-UPDATE] GitHub polling baslatildi (5 saniye)...")

    # Ilk kontrolde bot calismiyorsa hemen baslatir
    if not is_bot_running():
        log("[AUTO-UPDATE] Bot calismıyor, baslatiliyor...")
        if not start_bot():
            log("[AUTO-UPDATE] Bot baslatma basarisiz! Log dosyasini kontrol edin:")
            log(f"[AUTO-UPDATE] {BOT_LOG}")
            return
        time.sleep(5)

    while True:
        try:
            # git fetch yap, remote'daki son hash'i al
            subprocess.run(["git", "fetch", "origin"], cwd=BOT_DIR, capture_output=True, timeout=30)
            
            # Remote HEAD hash'ini al
            result = subprocess.run(
                ["git", "rev-parse", "origin/main"],
                cwd=BOT_DIR, capture_output=True, text=True, timeout=10
            )
            remote_hash = result.stdout.strip() if result.returncode == 0 else None

            if remote_hash:
                local_hash = get_local_commit() or ""
                if remote_hash != local_hash:
                    log(f"[AUTO-UPDATE] Yeni commit algilandi: {remote_hash[:8]} (local: {local_hash[:8]})")
                    update_bot()

            # Bot calismiyor mu kontrol et
            if not is_bot_running():
                log("[AUTO-UPDATE] Bot durdu! Yeniden baslatiliyor...")
                if not start_bot():
                    log("[AUTO-UPDATE] Bot yeniden baslatma basarisiz!")
                time.sleep(10)

            time.sleep(30)

        except KeyboardInterrupt:
            log("[AUTO-UPDATE] Kullanici tarafindan durduruldu")
            break
        except Exception as e:
            log(f"[AUTO-UPDATE] Ana dongu hatasi: {e}")
            import traceback
            log(traceback.format_exc())
            time.sleep(10)


if __name__ == "__main__":
    main()
