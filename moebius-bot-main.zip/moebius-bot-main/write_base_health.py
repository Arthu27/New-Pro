with open('web/templates/base.html', 'r', encoding='utf-8') as f:
    content = f.read()

# MOD menüsüne ekle — analytics'ten sonra
content = content.replace(
    '''        <a href="/analytics" {% if request.path == '/analytics' %}class="active"{% endif %}><i class="fas fa-chart-bar"></i> Analitik</a>
        <a href="/mod-history" {% if request.path == '/mod-history' %}class="active"{% endif %}><i class="fas fa-history"></i> Mod Gecmisi</a>
        <a href="/polls" {% if request.path == '/polls' %}class="active"{% endif %}><i class="fas fa-poll"></i> Anketler</a>
        <a href="/member-notes" {% if request.path == '/member-notes' %}class="active"{% endif %}><i class="fas fa-sticky-note"></i> Uye Notlari</a>''',
    '''        <a href="/analytics" {% if request.path == '/analytics' %}class="active"{% endif %}><i class="fas fa-chart-bar"></i> Analitik</a>
        <a href="/server-health" {% if request.path == '/server-health' %}class="active"{% endif %}><i class="fas fa-heartbeat"></i> Sunucu Sagligi</a>
        <a href="/mod-history" {% if request.path == '/mod-history' %}class="active"{% endif %}><i class="fas fa-history"></i> Mod Gecmisi</a>
        <a href="/polls" {% if request.path == '/polls' %}class="active"{% endif %}><i class="fas fa-poll"></i> Anketler</a>
        <a href="/member-notes" {% if request.path == '/member-notes' %}class="active"{% endif %}><i class="fas fa-sticky-note"></i> Uye Notlari</a>''',
    1
)

# ADMIN menüsüne ekle
content = content.replace(
    '''        <a href="/analytics" {% if request.path == '/analytics' %}class="active"{% endif %}><i class="fas fa-chart-bar"></i> Analitik</a>
        <a href="/roles" {% if request.path == '/roles' %}class="active"{% endif %}><i class="fas fa-user-tag"></i> Rol Yonetimi</a>
        <a href="/channels" {% if request.path == '/channels' %}class="active"{% endif %}><i class="fas fa-hashtag"></i> Kanal Yonetimi</a>
        <a href="/mod-history" {% if request.path == '/mod-history' %}class="active"{% endif %}><i class="fas fa-history"></i> Mod Gecmisi</a>
        <a href="/welcome-editor"''',
    '''        <a href="/analytics" {% if request.path == '/analytics' %}class="active"{% endif %}><i class="fas fa-chart-bar"></i> Analitik</a>
        <a href="/server-health" {% if request.path == '/server-health' %}class="active"{% endif %}><i class="fas fa-heartbeat"></i> Sunucu Sagligi</a>
        <a href="/roles" {% if request.path == '/roles' %}class="active"{% endif %}><i class="fas fa-user-tag"></i> Rol Yonetimi</a>
        <a href="/channels" {% if request.path == '/channels' %}class="active"{% endif %}><i class="fas fa-hashtag"></i> Kanal Yonetimi</a>
        <a href="/mod-history" {% if request.path == '/mod-history' %}class="active"{% endif %}><i class="fas fa-history"></i> Mod Gecmisi</a>
        <a href="/welcome-editor"''',
    1
)

# OWNER menüsüne ekle
content = content.replace(
    '''        <a href="/analytics" {% if request.path == '/analytics' %}class="active"{% endif %}><i class="fas fa-chart-bar"></i> Analitik</a>
        <a href="/roles" {% if request.path == '/roles' %}class="active"{% endif %}><i class="fas fa-user-tag"></i> Rol Yonetimi</a>
        <a href="/channels" {% if request.path == '/channels' %}class="active"{% endif %}><i class="fas fa-hashtag"></i> Kanal Yonetimi</a>
        <a href="/mod-history" {% if request.path == '/mod-history' %}class="active"{% endif %}><i class="fas fa-history"></i> Mod Gecmisi</a>
        <a href="/welcome-editor" {% if request.path == '/welcome-editor' %}class="active"{% endif %}><i class="fas fa-door-open"></i> Hosgeldin Mesaj</a>
        <a href="/reaction-roles" {% if request.path == '/reaction-roles' %}class="active"{% endif %}><i class="fas fa-smile"></i> Reaksiyon Roller</a>
        <a href="/giveaway"''',
    '''        <a href="/analytics" {% if request.path == '/analytics' %}class="active"{% endif %}><i class="fas fa-chart-bar"></i> Analitik</a>
        <a href="/server-health" {% if request.path == '/server-health' %}class="active"{% endif %}><i class="fas fa-heartbeat"></i> Sunucu Sagligi</a>
        <a href="/roles" {% if request.path == '/roles' %}class="active"{% endif %}><i class="fas fa-user-tag"></i> Rol Yonetimi</a>
        <a href="/channels" {% if request.path == '/channels' %}class="active"{% endif %}><i class="fas fa-hashtag"></i> Kanal Yonetimi</a>
        <a href="/mod-history" {% if request.path == '/mod-history' %}class="active"{% endif %}><i class="fas fa-history"></i> Mod Gecmisi</a>
        <a href="/welcome-editor" {% if request.path == '/welcome-editor' %}class="active"{% endif %}><i class="fas fa-door-open"></i> Hosgeldin Mesaj</a>
        <a href="/reaction-roles" {% if request.path == '/reaction-roles' %}class="active"{% endif %}><i class="fas fa-smile"></i> Reaksiyon Roller</a>
        <a href="/giveaway"''',
    1
)

with open('web/templates/base.html', 'w', encoding='utf-8') as f:
    f.write(content)

print("OK")
