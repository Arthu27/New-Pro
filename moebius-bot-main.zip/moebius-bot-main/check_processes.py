#!/usr/bin/env python3
"""
Bot process kontrolü - Çoklu instance kontrolü
"""
import subprocess
import sys

def check_bot_processes():
    """Çalışan bot process'lerini kontrol et"""
    try:
        # Python main.py process'lerini bul
        result = subprocess.run(
            'wmic process where "commandline like \'%main.py%\'" get processid,commandline',
            shell=True,
            capture_output=True,
            text=True
        )
        
        lines = result.stdout.strip().split('\n')
        processes = []
        
        for line in lines[1:]:  # İlk satır header
            if line.strip() and 'main.py' in line:
                processes.append(line.strip())
        
        print(f"[INFO] Bulunan bot process sayısı: {len(processes)}")
        
        if len(processes) > 1:
            print("[WARNING] Birden fazla bot process çalışıyor!")
            for i, proc in enumerate(processes, 1):
                print(f"  {i}. {proc}")
            return True
        elif len(processes) == 1:
            print("[OK] Tek bot process çalışıyor")
            print(f"  {processes[0]}")
            return False
        else:
            print("[INFO] Hiç bot process bulunamadı")
            return False
            
    except Exception as e:
        print(f"[ERROR] Process kontrolü hatası: {e}")
        return False

def kill_all_bot_processes():
    """Tüm bot process'lerini sonlandır"""
    try:
        print("[INFO] Tüm bot process'leri sonlandırılıyor...")
        
        # Python process'lerini sonlandır
        subprocess.run('taskkill /f /im python.exe', shell=True, capture_output=True)
        
        # Cloudflared process'lerini sonlandır
        subprocess.run('taskkill /f /im cloudflared.exe', shell=True, capture_output=True)
        
        print("[OK] Process'ler sonlandırıldı")
        
    except Exception as e:
        print(f"[ERROR] Process sonlandırma hatası: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "kill":
        kill_all_bot_processes()
    else:
        check_bot_processes()