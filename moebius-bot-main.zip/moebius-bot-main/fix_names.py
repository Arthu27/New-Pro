﻿import os, re

files = [
    'cogs/embed_utils.py', 'cogs/moderation.py', 'cogs/warnings.py',
    'cogs/ticket.py', 'cogs/staff_apply.py', 'cogs/verification.py',
    'cogs/giveaway.py', 'cogs/fun.py', 'cogs/minigames.py',
    'cogs/economy_cmds.py', 'cogs/invite_tracker.py', 'cogs/automod.py',
    'cogs/logs.py', 'cogs/advanced_mod.py', 'cogs/duty.py',
    'cogs/birthday.py', 'cogs/events.py', 'cogs/stats.py',
    'cogs/health.py', 'cogs/utility.py', 'cogs/info_tools.py',
]

replacements = [
    ('Aether Bot —', 'Aether Bot —'),
    ('Aether Bot', 'Aether'),
    ('**Aether** sunucusundan **kalıcı olarak** uzaklaştırıldınız.', '**{guild.name}** sunucusundan **kalıcı olarak** uzaklaştırıldınız.'),
    ('**Aether** sunucusundan atıldınız.', '**{guild.name}** sunucusundan atıldınız.'),
    ('**Aether** sunucusunda belirtilen süre boyunca', '**{guild.name}** sunucusunda belirtilen süre boyunca'),
    ('**Aether** sunucusundaki susturmanız **kaldırıldı**.', '**{guild.name}** sunucusundaki susturmanız **kaldırıldı**.'),
    ('**Aether** sunucusunda sunucu kurallarını ihlal ettiğiniz', '**{guild.name}** sunucusunda sunucu kurallarını ihlal ettiğiniz'),
    ('**Aether** sunucusundaki banınız **kaldırıldı**.', '**{guild.name}** sunucusundaki banınız **kaldırıldı**.'),
    ('✦ Aether DESTEK SİSTEMİ ✦', '✦ Aether DESTEK SİSTEMİ ✦'),
    ('Aether Ekonomi •', 'Aether Ekonomi •'),
    ('Aether Ekonomi', 'Aether Ekonomi'),
    ('Aether Moderasyon •', 'Aether Moderasyon •'),
    ('Aether Moderasyon', 'Aether Moderasyon'),
    ('Aether Destek Sistemi •', 'Aether Destek •'),
    ('Aether Destek Sistemi', 'Aether Destek'),
    ('Aether Destek •', 'Aether Destek •'),
    ('Aether Destek', 'Aether Destek'),
    ('Aether Yetkili Sistemi •', 'Aether Yetkili •'),
    ('Aether Yetkili Sistemi', 'Aether Yetkili'),
    ('Aether Yetkili', 'Aether Yetkili'),
    ('Aether Çekiliş Sistemi', 'Aether Çekiliş'),
    ('Aether Log Sistemi', 'Aether Log'),
    ('Aether Panel •', 'Aether Panel •'),
    ('Aether Panel', 'Aether Panel'),
    ("f'Aether •", "f'Aether •"),
    ('"Aether •', '"Aether •'),
    ("'Aether •", "'Aether •"),
    ('Aether • ', 'Aether • '),
    ('Aether\n', 'Aether\n'),
    ('Aether"', 'Aether"'),
    ("Aether'", "Aether'"),
]

for filepath in files:
    if not os.path.exists(filepath):
        continue
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    original = content
    for old, new in replacements:
        content = content.replace(old, new)
    if content != original:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f'Updated: {filepath}')
    else:
        print(f'No change: {filepath}')

print('Done.')
