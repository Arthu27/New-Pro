﻿import os

templates_dir = os.path.join(os.path.dirname(__file__), 'web', 'templates')
os.makedirs(templates_dir, exist_ok=True)

# ============================================================
# commands.html
# ============================================================
commands_html = '''{% extends "base.html" %}
{% block title %}Komutlar - Aether{% endblock %}
{% block page_title %}KOMUT MERKEZİ{% endblock %}
{% block content %}
<style>
.cmd-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:20px; margin-top:20px; }
.cmd-card { background:linear-gradient(135deg,#1a0a0a,#2a1010); border:1px solid rgba(220,20,60,0.4); border-radius:15px; padding:25px; cursor:pointer; transition:all 0.3s; position:relative; overflow:hidden; }
.cmd-card:hover { transform:translateY(-8px); border-color:#dc143c; box-shadow:0 15px 40px rgba(220,20,60,0.4); }
.cmd-card::before { content:''; position:absolute; top:-50%; left:-50%; width:200%; height:200%; background:linear-gradient(45deg,transparent,rgba(220,20,60,0.05),transparent); transform:rotate(45deg); transition:0.5s; }
.cmd-card:hover::before { left:100%; }
.cmd-card h3 { color:#dc143c; margin-bottom:8px; font-size:18px; }
.cmd-card p { color:#aaa; font-size:13px; }
.cmd-icon { font-size:36px; margin-bottom:15px; }
.modal-overlay { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); z-index:9999; justify-content:center; align-items:center; }
.modal-box { background:linear-gradient(135deg,#1a1a1a,#2a2a2a); border:2px solid #dc143c; border-radius:20px; padding:35px; max-width:500px; width:90%; position:relative; box-shadow:0 20px 60px rgba(220,20,60,0.5); }
.modal-box h2 { color:#dc143c; margin-bottom:20px; }
.form-group { margin-bottom:15px; }
.form-group label { display:block; color:#ccc; margin-bottom:6px; font-size:13px; text-transform:uppercase; letter-spacing:1px; }
.form-group input, .form-group select, .form-group textarea { width:100%; padding:10px 14px; background:#0a0a0a; border:2px solid rgba(220,20,60,0.3); border-radius:8px; color:#eee; font-size:14px; transition:border-color 0.3s; box-sizing:border-box; }
.form-group input:focus, .form-group select:focus { outline:none; border-color:#dc143c; }
.btn-exec { background:linear-gradient(135deg,#dc143c,#ff1744); color:white; padding:12px 28px; border:none; border-radius:8px; cursor:pointer; font-size:15px; font-weight:700; margin-right:10px; transition:all 0.3s; }
.btn-exec:hover { box-shadow:0 5px 20px rgba(220,20,60,0.5); transform:translateY(-2px); }
.btn-cancel { background:#333; color:#ccc; padding:12px 28px; border:none; border-radius:8px; cursor:pointer; font-size:15px; }
#result-msg { margin-top:15px; padding:12px; border-radius:8px; display:none; }
</style>

<div class="cmd-grid">
  <div class="cmd-card" onclick="openCmd(\'ban\')">
    <div class="cmd-icon">🔨</div>
    <h3><i class="fas fa-ban"></i> Ban</h3>
    <p>Kullanıcıyı sunucudan kalıcı olarak yasakla</p>
  </div>
  <div class="cmd-card" onclick="openCmd(\'kick\')">
    <div class="cmd-icon">👢</div>
    <h3><i class="fas fa-user-slash"></i> Kick</h3>
    <p>Kullanıcıyı sunucudan at</p>
  </div>
  <div class="cmd-card" onclick="openCmd(\'timeout\')">
    <div class="cmd-icon">⏱️</div>
    <h3><i class="fas fa-clock"></i> Timeout</h3>
    <p>Kullanıcıyı geçici olarak sustur</p>
  </div>
  <div class="cmd-card" onclick="openCmd(\'warn\')">
    <div class="cmd-icon">⚠️</div>
    <h3><i class="fas fa-exclamation-triangle"></i> Warn</h3>
    <p>Kullanıcıya uyarı ver</p>
  </div>
  <div class="cmd-card" onclick="openCmd(\'temizle\')">
    <div class="cmd-icon">🗑️</div>
    <h3><i class="fas fa-trash"></i> Mesaj Temizle</h3>
    <p>Kanaldan toplu mesaj sil</p>
  </div>
  <div class="cmd-card" onclick="openCmd(\'role\')">
    <div class="cmd-icon">🏷️</div>
    <h3><i class="fas fa-user-tag"></i> Rol Ver/Al</h3>
    <p>Kullanıcıya rol ekle veya çıkar</p>
  </div>
</div>

<div id="cmdModal" class="modal-overlay">
  <div class="modal-box">
    <button onclick="closeCmd()" style="position:absolute;top:15px;right:20px;background:none;border:none;color:#dc143c;font-size:26px;cursor:pointer;">&times;</button>
    <h2 id="cmdTitle">Komut</h2>
    <div id="cmdForm"></div>
    <div id="result-msg"></div>
  </div>
</div>

<script>
var guilds = [];
var currentCmd = '';

async function loadGuilds() {
  var r = await fetch('/api/guilds');
  guilds = await r.json();
}

function guildOptions() {
  return guilds.map(function(g) { return '<option value="'+g.id+'">'+g.name+'</option>'; }).join('');
}

async function loadChannels(selId) {
  var gid = document.getElementById('guild-sel').value;
  if (!gid) return;
  var r = await fetch('/api/guild/'+gid+'/channels');
  var chs = await r.json();
  if (!Array.isArray(chs)) chs = chs.channels || [];
  var sel = document.getElementById(selId);
  sel.innerHTML = chs.filter(function(c){return c.type==='text';}).map(function(c){return '<option value="'+c.id+'">#'+c.name+'</option>';}).join('');
}

async function loadRoles(selId) {
  var gid = document.getElementById('guild-sel').value;
  if (!gid) return;
  var r = await fetch('/api/guild/'+gid+'/roles');
  var roles = await r.json();
  if (!Array.isArray(roles)) roles = [];
  var sel = document.getElementById(selId);
  sel.innerHTML = roles.map(function(ro){return '<option value="'+ro.id+'">'+ro.name+'</option>';}).join('');
}

function openCmd(cmd) {
  currentCmd = cmd;
  document.getElementById('cmdTitle').textContent = cmd.toUpperCase();
  document.getElementById('result-msg').style.display = 'none';
  var forms = {
    ban: '<div class="form-group"><label>Sunucu</label><select id="guild-sel" class="form-control">'+guildOptions()+'</select></div><div class="form-group"><label>Kullanici ID</label><input type="text" id="user_id" placeholder="123456789"></div><div class="form-group"><label>Sebep</label><input type="text" id="reason" placeholder="Ban sebebi"></div><button class="btn-exec" onclick="execCmd()">BAN</button><button class="btn-cancel" onclick="closeCmd()">Iptal</button>',
    kick: '<div class="form-group"><label>Sunucu</label><select id="guild-sel" class="form-control">'+guildOptions()+'</select></div><div class="form-group"><label>Kullanici ID</label><input type="text" id="user_id" placeholder="123456789"></div><div class="form-group"><label>Sebep</label><input type="text" id="reason" placeholder="Kick sebebi"></div><button class="btn-exec" onclick="execCmd()">KICK</button><button class="btn-cancel" onclick="closeCmd()">Iptal</button>',
    timeout: '<div class="form-group"><label>Sunucu</label><select id="guild-sel" class="form-control">'+guildOptions()+'</select></div><div class="form-group"><label>Kullanici ID</label><input type="text" id="user_id" placeholder="123456789"></div><div class="form-group"><label>Sure (dakika)</label><input type="number" id="duration" value="60"></div><div class="form-group"><label>Sebep</label><input type="text" id="reason" placeholder="Timeout sebebi"></div><button class="btn-exec" onclick="execCmd()">TIMEOUT</button><button class="btn-cancel" onclick="closeCmd()">Iptal</button>',
    warn: '<div class="form-group"><label>Sunucu</label><select id="guild-sel" class="form-control">'+guildOptions()+'</select></div><div class="form-group"><label>Kullanici ID</label><input type="text" id="user_id" placeholder="123456789"></div><div class="form-group"><label>Sebep</label><input type="text" id="reason" placeholder="Uyari sebebi"></div><button class="btn-exec" onclick="execCmd()">WARN</button><button class="btn-cancel" onclick="closeCmd()">Iptal</button>',
    temizle: '<div class="form-group"><label>Sunucu</label><select id="guild-sel" class="form-control" onchange="loadChannels(\'channel-sel\')">'+guildOptions()+'</select></div><div class="form-group"><label>Kanal</label><select id="channel-sel" class="form-control"><option>Once sunucu secin</option></select></div><div class="form-group"><label>Mesaj Sayisi</label><input type="number" id="amount" value="10"></div><button class="btn-exec" onclick="execCmd()">TEMİZLE</button><button class="btn-cancel" onclick="closeCmd()">Iptal</button>',
    role: '<div class="form-group"><label>Sunucu</label><select id="guild-sel" class="form-control" onchange="loadRoles(\'role-sel\')">'+guildOptions()+'</select></div><div class="form-group"><label>Kullanici ID</label><input type="text" id="user_id" placeholder="123456789"></div><div class="form-group"><label>Rol</label><select id="role-sel" class="form-control"><option>Once sunucu secin</option></select></div><button class="btn-exec" onclick="execCmd()">UYGULA</button><button class="btn-cancel" onclick="closeCmd()">Iptal</button>'
  };
  document.getElementById('cmdForm').innerHTML = forms[cmd];
  document.getElementById('cmdModal').style.display = 'flex';
  if (cmd === 'temizle') loadChannels('channel-sel');
  if (cmd === 'role') loadRoles('role-sel');
}

function closeCmd() { document.getElementById('cmdModal').style.display = 'none'; }

async function execCmd() {
  var data = { command: currentCmd, guild_id: document.getElementById('guild-sel').value };
  var uid = document.getElementById('user_id'); if (uid) data.user_id = uid.value;
  var rsn = document.getElementById('reason'); if (rsn) data.reason = rsn.value;
  var dur = document.getElementById('duration'); if (dur) data.duration = dur.value;
  var amt = document.getElementById('amount'); if (amt) data.amount = amt.value;
  var chs = document.getElementById('channel-sel'); if (chs) data.channel_id = chs.value;
  var rls = document.getElementById('role-sel'); if (rls) data.role_id = rls.value;

  var r = await fetch('/api/execute-command', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data) });
  var res = await r.json();
  var msg = document.getElementById('result-msg');
  msg.style.display = 'block';
  if (res.success) {
    msg.style.background = 'rgba(46,204,113,0.2)'; msg.style.border = '1px solid #2ecc71'; msg.style.color = '#2ecc71';
    msg.textContent = '✅ Komut basariyla calistirildi!';
    setTimeout(closeCmd, 2000);
  } else {
    msg.style.background = 'rgba(220,20,60,0.2)'; msg.style.border = '1px solid #dc143c'; msg.style.color = '#ff6b6b';
    msg.textContent = '❌ Hata: ' + res.error;
  }
}

document.getElementById('cmdModal').addEventListener('click', function(e) { if (e.target === this) closeCmd(); });
loadGuilds();
</script>
{% endblock %}
'''

with open(os.path.join(templates_dir, 'commands.html'), 'w', encoding='utf-8') as f:
    f.write(commands_html)
print("commands.html yazildi")

# ============================================================
# execute_command.html - base.html extend eden versiyon
# ============================================================
execute_html = '''{% extends "base.html" %}
{% block title %}Komut Calistir - Aether{% endblock %}
{% block page_title %}KOMUT ÇALIŞTIR{% endblock %}
{% block content %}
<style>
.cmd-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:20px; margin-top:20px; }
.cmd-card { background:linear-gradient(135deg,#1a0a0a,#2a1010); border:1px solid rgba(220,20,60,0.4); border-radius:15px; padding:25px; cursor:pointer; transition:all 0.3s; position:relative; overflow:hidden; }
.cmd-card:hover { transform:translateY(-8px); border-color:#dc143c; box-shadow:0 15px 40px rgba(220,20,60,0.4); }
.cmd-icon { font-size:36px; margin-bottom:15px; }
.cmd-card h3 { color:#dc143c; margin-bottom:8px; font-size:18px; }
.cmd-card p { color:#aaa; font-size:13px; }
.modal-overlay { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); z-index:9999; justify-content:center; align-items:center; }
.modal-box { background:linear-gradient(135deg,#1a1a1a,#2a2a2a); border:2px solid #dc143c; border-radius:20px; padding:35px; max-width:500px; width:90%; position:relative; box-shadow:0 20px 60px rgba(220,20,60,0.5); }
.modal-box h2 { color:#dc143c; margin-bottom:20px; }
.form-group { margin-bottom:15px; }
.form-group label { display:block; color:#ccc; margin-bottom:6px; font-size:13px; text-transform:uppercase; letter-spacing:1px; }
.form-group input, .form-group select { width:100%; padding:10px 14px; background:#0a0a0a; border:2px solid rgba(220,20,60,0.3); border-radius:8px; color:#eee; font-size:14px; box-sizing:border-box; transition:border-color 0.3s; }
.form-group input:focus, .form-group select:focus { outline:none; border-color:#dc143c; }
.btn-exec { background:linear-gradient(135deg,#dc143c,#ff1744); color:white; padding:12px 28px; border:none; border-radius:8px; cursor:pointer; font-size:15px; font-weight:700; margin-right:10px; transition:all 0.3s; }
.btn-exec:hover { box-shadow:0 5px 20px rgba(220,20,60,0.5); transform:translateY(-2px); }
.btn-cancel { background:#333; color:#ccc; padding:12px 28px; border:none; border-radius:8px; cursor:pointer; font-size:15px; }
#exec-result { margin-top:15px; padding:12px; border-radius:8px; display:none; }
</style>

<div class="cmd-grid">
  <div class="cmd-card" onclick="openCmd(\'ban\')"><div class="cmd-icon">🔨</div><h3><i class="fas fa-ban"></i> Ban</h3><p>Kullanicıyı kalıcı yasakla</p></div>
  <div class="cmd-card" onclick="openCmd(\'kick\')"><div class="cmd-icon">👢</div><h3><i class="fas fa-user-slash"></i> Kick</h3><p>Kullanicıyı sunucudan at</p></div>
  <div class="cmd-card" onclick="openCmd(\'timeout\')"><div class="cmd-icon">⏱️</div><h3><i class="fas fa-clock"></i> Timeout</h3><p>Gecici sustur</p></div>
  <div class="cmd-card" onclick="openCmd(\'warn\')"><div class="cmd-icon">⚠️</div><h3><i class="fas fa-exclamation-triangle"></i> Warn</h3><p>Uyarı ver</p></div>
  <div class="cmd-card" onclick="openCmd(\'temizle\')"><div class="cmd-icon">🗑️</div><h3><i class="fas fa-trash"></i> Temizle</h3><p>Toplu mesaj sil</p></div>
  <div class="cmd-card" onclick="openCmd(\'role\')"><div class="cmd-icon">🏷️</div><h3><i class="fas fa-user-tag"></i> Rol Ver/Al</h3><p>Rol ekle veya cıkar</p></div>
</div>

<div id="execModal" class="modal-overlay">
  <div class="modal-box">
    <button onclick="closeCmd()" style="position:absolute;top:15px;right:20px;background:none;border:none;color:#dc143c;font-size:26px;cursor:pointer;">&times;</button>
    <h2 id="execTitle">Komut</h2>
    <div id="execForm"></div>
    <div id="exec-result"></div>
  </div>
</div>

<script>
var guilds = [];
var currentCmd = '';

async function loadGuilds() {
  var r = await fetch('/api/guilds');
  guilds = await r.json();
}

function guildOptions() {
  return guilds.map(function(g){return '<option value="'+g.id+'">'+g.name+'</option>';}).join('');
}

async function loadChannels(selId) {
  var gid = document.getElementById('guild-sel').value;
  if (!gid) return;
  var r = await fetch('/api/guild/'+gid+'/channels');
  var data = await r.json();
  var chs = Array.isArray(data) ? data : (data.channels || []);
  var sel = document.getElementById(selId);
  sel.innerHTML = chs.filter(function(c){return c.type==='text';}).map(function(c){return '<option value="'+c.id+'">#'+c.name+'</option>';}).join('');
}

async function loadRoles(selId) {
  var gid = document.getElementById('guild-sel').value;
  if (!gid) return;
  var r = await fetch('/api/guild/'+gid+'/roles');
  var roles = await r.json();
  if (!Array.isArray(roles)) roles = [];
  var sel = document.getElementById(selId);
  sel.innerHTML = roles.map(function(ro){return '<option value="'+ro.id+'">'+ro.name+'</option>';}).join('');
}

function openCmd(cmd) {
  currentCmd = cmd;
  document.getElementById('execTitle').textContent = cmd.toUpperCase();
  document.getElementById('exec-result').style.display = 'none';
  var forms = {
    ban: '<div class="form-group"><label>Sunucu</label><select id="guild-sel">'+guildOptions()+'</select></div><div class="form-group"><label>Kullanici ID</label><input type="text" id="user_id" placeholder="123456789"></div><div class="form-group"><label>Sebep</label><input type="text" id="reason" placeholder="Ban sebebi"></div><button class="btn-exec" onclick="execCmd()">BAN</button><button class="btn-cancel" onclick="closeCmd()">Iptal</button>',
    kick: '<div class="form-group"><label>Sunucu</label><select id="guild-sel">'+guildOptions()+'</select></div><div class="form-group"><label>Kullanici ID</label><input type="text" id="user_id" placeholder="123456789"></div><div class="form-group"><label>Sebep</label><input type="text" id="reason" placeholder="Kick sebebi"></div><button class="btn-exec" onclick="execCmd()">KICK</button><button class="btn-cancel" onclick="closeCmd()">Iptal</button>',
    timeout: '<div class="form-group"><label>Sunucu</label><select id="guild-sel">'+guildOptions()+'</select></div><div class="form-group"><label>Kullanici ID</label><input type="text" id="user_id" placeholder="123456789"></div><div class="form-group"><label>Sure (dakika)</label><input type="number" id="duration" value="60"></div><div class="form-group"><label>Sebep</label><input type="text" id="reason" placeholder="Timeout sebebi"></div><button class="btn-exec" onclick="execCmd()">TIMEOUT</button><button class="btn-cancel" onclick="closeCmd()">Iptal</button>',
    warn: '<div class="form-group"><label>Sunucu</label><select id="guild-sel">'+guildOptions()+'</select></div><div class="form-group"><label>Kullanici ID</label><input type="text" id="user_id" placeholder="123456789"></div><div class="form-group"><label>Sebep</label><input type="text" id="reason" placeholder="Uyari sebebi"></div><button class="btn-exec" onclick="execCmd()">WARN</button><button class="btn-cancel" onclick="closeCmd()">Iptal</button>',
    temizle: '<div class="form-group"><label>Sunucu</label><select id="guild-sel" onchange="loadChannels(\'channel-sel\')">'+guildOptions()+'</select></div><div class="form-group"><label>Kanal</label><select id="channel-sel"><option>Once sunucu secin</option></select></div><div class="form-group"><label>Mesaj Sayisi</label><input type="number" id="amount" value="10"></div><button class="btn-exec" onclick="execCmd()">TEMİZLE</button><button class="btn-cancel" onclick="closeCmd()">Iptal</button>',
    role: '<div class="form-group"><label>Sunucu</label><select id="guild-sel" onchange="loadRoles(\'role-sel\')">'+guildOptions()+'</select></div><div class="form-group"><label>Kullanici ID</label><input type="text" id="user_id" placeholder="123456789"></div><div class="form-group"><label>Rol</label><select id="role-sel"><option>Once sunucu secin</option></select></div><button class="btn-exec" onclick="execCmd()">UYGULA</button><button class="btn-cancel" onclick="closeCmd()">Iptal</button>'
  };
  document.getElementById('execForm').innerHTML = forms[cmd];
  document.getElementById('execModal').style.display = 'flex';
  if (cmd === 'temizle') loadChannels('channel-sel');
  if (cmd === 'role') loadRoles('role-sel');
}

function closeCmd() { document.getElementById('execModal').style.display = 'none'; }

async function execCmd() {
  var data = { command: currentCmd, guild_id: document.getElementById('guild-sel').value };
  var uid = document.getElementById('user_id'); if (uid) data.user_id = uid.value;
  var rsn = document.getElementById('reason'); if (rsn) data.reason = rsn.value;
  var dur = document.getElementById('duration'); if (dur) data.duration = dur.value;
  var amt = document.getElementById('amount'); if (amt) data.amount = amt.value;
  var chs = document.getElementById('channel-sel'); if (chs) data.channel_id = chs.value;
  var rls = document.getElementById('role-sel'); if (rls) data.role_id = rls.value;

  var r = await fetch('/api/execute-command', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data) });
  var res = await r.json();
  var msg = document.getElementById('exec-result');
  msg.style.display = 'block';
  if (res.success) {
    msg.style.cssText = 'display:block;background:rgba(46,204,113,0.2);border:1px solid #2ecc71;color:#2ecc71;padding:12px;border-radius:8px;margin-top:15px;';
    msg.textContent = '✅ Komut basariyla calistirildi!';
    setTimeout(closeCmd, 2000);
  } else {
    msg.style.cssText = 'display:block;background:rgba(220,20,60,0.2);border:1px solid #dc143c;color:#ff6b6b;padding:12px;border-radius:8px;margin-top:15px;';
    msg.textContent = '❌ Hata: ' + res.error;
  }
}

document.getElementById('execModal').addEventListener('click', function(e) { if (e.target === this) closeCmd(); });
loadGuilds();
</script>
{% endblock %}
'''

with open(os.path.join(templates_dir, 'execute_command.html'), 'w', encoding='utf-8') as f:
    f.write(execute_html)
print("execute_command.html yazildi")

# ============================================================
# logs.html
# ============================================================
logs_html = '''{% extends "base.html" %}
{% block title %}Mod Loglari - Aether{% endblock %}
{% block page_title %}MOD LOGLARI{% endblock %}
{% block content %}
<div class="section">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:10px;">
    <h2><i class="fas fa-clipboard-list" style="color:#dc143c;"></i> Tum Mod Islemleri</h2>
    <input type="text" id="log-filter" placeholder="Filtrele (kullanici ID, sebep, islem...)" style="padding:10px 15px;background:#0a0a0a;border:2px solid rgba(220,20,60,0.3);border-radius:8px;color:#eee;width:300px;" oninput="filterLogs()">
  </div>
  <div id="logs-list" style="color:#aaa;text-align:center;padding:40px;"><i class="fas fa-spinner fa-spin" style="font-size:30px;color:#dc143c;"></i><br><br>Yukleniyor...</div>
</div>
<script>
var allLogs = [];
async function loadLogs() {
  var r = await fetch('/api/logs');
  allLogs = await r.json();
  displayLogs(allLogs);
}
function displayLogs(logs) {
  if (!logs.length) {
    document.getElementById('logs-list').innerHTML = '<p style="color:#aaa;text-align:center;padding:40px;">Hic log bulunamadi</p>';
    return;
  }
  var colors = { ban:'#e74c3c', kick:'#e67e22', timeout:'#f39c12', warn:'#f1c40f', mute:'#9b59b6' };
  var html = '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;">';
  html += '<tr style="border-bottom:2px solid rgba(220,20,60,0.3);"><th style="padding:12px;text-align:left;color:#dc143c;">Case</th><th style="padding:12px;text-align:left;color:#dc143c;">Islem</th><th style="padding:12px;text-align:left;color:#dc143c;">Kullanici</th><th style="padding:12px;text-align:left;color:#dc143c;">Moderator</th><th style="padding:12px;text-align:left;color:#dc143c;">Sebep</th><th style="padding:12px;text-align:left;color:#dc143c;">Tarih</th></tr>';
  logs.slice(0,100).forEach(function(log, i) {
    var bg = i%2===0 ? 'rgba(220,20,60,0.03)' : 'transparent';
    var ac = colors[log.action] || '#667eea';
    html += '<tr style="border-bottom:1px solid rgba(255,255,255,0.05);background:'+bg+';transition:background 0.2s;" onmouseover="this.style.background=\'rgba(220,20,60,0.08)\'" onmouseout="this.style.background=\''+bg+'\'">';
    html += '<td style="padding:12px;color:#ffd700;font-weight:700;">#'+log.case_id+'</td>';
    html += '<td style="padding:12px;"><span style="background:'+ac+';padding:4px 10px;border-radius:4px;font-size:11px;font-weight:700;color:white;">'+log.action.toUpperCase()+'</span></td>';
    html += '<td style="padding:12px;"><code style="color:#dc143c;font-size:12px;">'+log.user_id+'</code></td>';
    html += '<td style="padding:12px;"><code style="color:#aaa;font-size:12px;">'+log.mod_id+'</code></td>';
    html += '<td style="padding:12px;color:#ccc;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'+log.reason+'</td>';
    html += '<td style="padding:12px;color:#888;font-size:12px;">'+new Date(log.timestamp).toLocaleString("tr-TR")+'</td>';
    html += '</tr>';
  });
  html += '</table></div><p style="margin-top:15px;color:#666;font-size:13px;">Toplam '+logs.length+' islem</p>';
  document.getElementById('logs-list').innerHTML = html;
}
function filterLogs() {
  var q = document.getElementById('log-filter').value.toLowerCase();
  displayLogs(allLogs.filter(function(l) {
    return String(l.user_id).includes(q) || String(l.mod_id).includes(q) || (l.reason||'').toLowerCase().includes(q) || (l.action||'').toLowerCase().includes(q);
  }));
}
loadLogs();
setInterval(loadLogs, 15000);
</script>
{% endblock %}
'''

with open(os.path.join(templates_dir, 'logs.html'), 'w', encoding='utf-8') as f:
    f.write(logs_html)
print("logs.html yazildi")

# ============================================================
# warnings.html
# ============================================================
warnings_html = '''{% extends "base.html" %}
{% block title %}Uyarilar - Aether{% endblock %}
{% block page_title %}UYARI SİSTEMİ{% endblock %}
{% block content %}
<div class="section">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:10px;">
    <h2><i class="fas fa-exclamation-triangle" style="color:#dc143c;"></i> Tum Uyarilar</h2>
    <input type="text" id="warn-filter" placeholder="Filtrele (kullanici ID, moderator, sebep...)" style="padding:10px 15px;background:#0a0a0a;border:2px solid rgba(220,20,60,0.3);border-radius:8px;color:#eee;width:300px;" oninput="filterWarnings()">
  </div>
  <div id="warnings-list" style="color:#aaa;text-align:center;padding:40px;"><i class="fas fa-spinner fa-spin" style="font-size:30px;color:#dc143c;"></i><br><br>Yukleniyor...</div>
</div>
<script>
var allWarnings = [];
async function loadWarnings() {
  var r = await fetch('/api/warnings');
  allWarnings = await r.json();
  displayWarnings(allWarnings);
}
function displayWarnings(warns) {
  if (!warns.length) {
    document.getElementById('warnings-list').innerHTML = '<p style="color:#aaa;text-align:center;padding:40px;">Hic uyari bulunamadi</p>';
    return;
  }
  var html = '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;">';
  html += '<tr style="border-bottom:2px solid rgba(220,20,60,0.3);"><th style="padding:12px;text-align:left;color:#dc143c;">Kullanici ID</th><th style="padding:12px;text-align:left;color:#dc143c;">Moderator</th><th style="padding:12px;text-align:left;color:#dc143c;">Sebep</th><th style="padding:12px;text-align:left;color:#dc143c;">Tarih</th><th style="padding:12px;text-align:left;color:#dc143c;">Sunucu</th></tr>';
  warns.slice(0,100).forEach(function(w, i) {
    var bg = i%2===0 ? 'rgba(220,20,60,0.03)' : 'transparent';
    html += '<tr style="border-bottom:1px solid rgba(255,255,255,0.05);background:'+bg+';transition:background 0.2s;" onmouseover="this.style.background=\'rgba(220,20,60,0.08)\'" onmouseout="this.style.background=\''+bg+'\'">';
    html += '<td style="padding:12px;"><code style="color:#dc143c;font-size:12px;">'+w.user_id+'</code></td>';
    html += '<td style="padding:12px;color:#ffd700;">'+w.moderator+'</td>';
    html += '<td style="padding:12px;color:#ccc;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'+w.reason+'</td>';
    html += '<td style="padding:12px;color:#888;font-size:12px;">'+new Date(w.timestamp).toLocaleString("tr-TR")+'</td>';
    html += '<td style="padding:12px;"><code style="color:#aaa;font-size:11px;">'+w.guild_id+'</code></td>';
    html += '</tr>';
  });
  html += '</table></div><p style="margin-top:15px;color:#666;font-size:13px;">Toplam '+warns.length+' uyari</p>';
  document.getElementById('warnings-list').innerHTML = html;
}
function filterWarnings() {
  var q = document.getElementById('warn-filter').value.toLowerCase();
  displayWarnings(allWarnings.filter(function(w) {
    return String(w.user_id).includes(q) || (w.moderator||'').toLowerCase().includes(q) || (w.reason||'').toLowerCase().includes(q);
  }));
}
loadWarnings();
setInterval(loadWarnings, 15000);
</script>
{% endblock %}
'''

with open(os.path.join(templates_dir, 'warnings.html'), 'w', encoding='utf-8') as f:
    f.write(warnings_html)
print("warnings.html yazildi")

# ============================================================
# settings.html
# ============================================================
settings_html = '''{% extends "base.html" %}
{% block title %}Ayarlar - Aether{% endblock %}
{% block page_title %}PANEL AYARLARI{% endblock %}
{% block content %}
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(400px,1fr));gap:20px;">
  <div class="section">
    <h2><i class="fas fa-shield-alt" style="color:#dc143c;"></i> Rol Yetkileri</h2>
    <table style="width:100%;border-collapse:collapse;">
      <tr style="border-bottom:2px solid rgba(220,20,60,0.3);"><th style="padding:10px;text-align:left;color:#dc143c;">Rol</th><th style="padding:10px;text-align:left;color:#dc143c;">Seviye</th><th style="padding:10px;text-align:left;color:#dc143c;">Yetkiler</th></tr>
      <tr style="border-bottom:1px solid rgba(255,255,255,0.05);"><td style="padding:10px;color:#ffd700;font-weight:700;">Owner</td><td style="padding:10px;color:#dc143c;">3</td><td style="padding:10px;color:#ccc;">Tum yetkiler</td></tr>
      <tr style="border-bottom:1px solid rgba(255,255,255,0.05);"><td style="padding:10px;color:#e67e22;font-weight:700;">Admin</td><td style="padding:10px;color:#dc143c;">2</td><td style="padding:10px;color:#ccc;">Komutlar, kullanicilar, loglar</td></tr>
      <tr><td style="padding:10px;color:#3498db;font-weight:700;">Mod</td><td style="padding:10px;color:#dc143c;">1</td><td style="padding:10px;color:#ccc;">Sunucular, loglar, uyarilar</td></tr>
    </table>
  </div>
  <div class="section">
    <h2><i class="fas fa-users-cog" style="color:#dc143c;"></i> Panel Kullanicilari</h2>
    <div style="background:rgba(220,20,60,0.1);border:1px solid rgba(220,20,60,0.3);border-radius:10px;padding:15px;margin-bottom:10px;">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <span style="color:#ffd700;font-weight:700;">owner</span>
        <span style="background:#dc143c;padding:3px 10px;border-radius:10px;font-size:12px;color:white;">OWNER</span>
      </div>
      <div style="color:#888;font-size:12px;margin-top:5px;">Sifre: owner123</div>
    </div>
    <div style="background:rgba(220,20,60,0.1);border:1px solid rgba(220,20,60,0.3);border-radius:10px;padding:15px;margin-bottom:10px;">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <span style="color:#e67e22;font-weight:700;">admin</span>
        <span style="background:#e67e22;padding:3px 10px;border-radius:10px;font-size:12px;color:white;">ADMIN</span>
      </div>
      <div style="color:#888;font-size:12px;margin-top:5px;">Sifre: admin123</div>
    </div>
    <div style="background:rgba(220,20,60,0.1);border:1px solid rgba(220,20,60,0.3);border-radius:10px;padding:15px;">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <span style="color:#3498db;font-weight:700;">mod</span>
        <span style="background:#3498db;padding:3px 10px;border-radius:10px;font-size:12px;color:white;">MOD</span>
      </div>
      <div style="color:#888;font-size:12px;margin-top:5px;">Sifre: mod123</div>
    </div>
    <div style="margin-top:15px;padding:12px;background:rgba(243,156,18,0.1);border:1px solid rgba(243,156,18,0.3);border-radius:8px;color:#f39c12;font-size:13px;">
      <i class="fas fa-exclamation-triangle"></i> Production ortaminda bu bilgileri degistirin!
    </div>
  </div>
  <div class="section">
    <h2><i class="fas fa-robot" style="color:#dc143c;"></i> Bot Istatistikleri</h2>
    <div id="bot-stats" style="color:#aaa;text-align:center;padding:20px;"><i class="fas fa-spinner fa-spin" style="color:#dc143c;"></i> Yukleniyor...</div>
  </div>
  <div class="section">
    <h2><i class="fas fa-info-circle" style="color:#dc143c;"></i> Sistem Bilgisi</h2>
    <div style="display:grid;gap:10px;">
      <div style="background:rgba(220,20,60,0.1);border:1px solid rgba(220,20,60,0.2);border-radius:8px;padding:12px;display:flex;justify-content:space-between;">
        <span style="color:#888;">Panel Versiyonu</span><span style="color:#ffd700;font-weight:700;">v2.0 Aether</span>
      </div>
      <div style="background:rgba(220,20,60,0.1);border:1px solid rgba(220,20,60,0.2);border-radius:8px;padding:12px;display:flex;justify-content:space-between;">
        <span style="color:#888;">Framework</span><span style="color:#ccc;">Flask + Discord.py</span>
      </div>
      <div style="background:rgba(220,20,60,0.1);border:1px solid rgba(220,20,60,0.2);border-radius:8px;padding:12px;display:flex;justify-content:space-between;">
        <span style="color:#888;">Port</span><span style="color:#ccc;">5001</span>
      </div>
    </div>
  </div>
</div>
<script>
async function loadStats() {
  var r = await fetch('/api/stats');
  var d = await r.json();
  if (d.error) { document.getElementById('bot-stats').innerHTML = '<p style="color:#e74c3c;">'+d.error+'</p>'; return; }
  document.getElementById('bot-stats').innerHTML =
    '<div style="display:grid;gap:10px;">' +
    '<div style="background:rgba(220,20,60,0.1);border:1px solid rgba(220,20,60,0.2);border-radius:8px;padding:12px;display:flex;justify-content:space-between;"><span style="color:#888;">Sunucu Sayisi</span><span style="color:#ffd700;font-weight:700;">'+d.guilds+'</span></div>' +
    '<div style="background:rgba(220,20,60,0.1);border:1px solid rgba(220,20,60,0.2);border-radius:8px;padding:12px;display:flex;justify-content:space-between;"><span style="color:#888;">Kullanici Sayisi</span><span style="color:#ffd700;font-weight:700;">'+d.users+'</span></div>' +
    '<div style="background:rgba(220,20,60,0.1);border:1px solid rgba(220,20,60,0.2);border-radius:8px;padding:12px;display:flex;justify-content:space-between;"><span style="color:#888;">Ping</span><span style="color:#2ecc71;font-weight:700;">'+d.latency+'ms</span></div>' +
    '<div style="background:rgba(220,20,60,0.1);border:1px solid rgba(220,20,60,0.2);border-radius:8px;padding:12px;display:flex;justify-content:space-between;"><span style="color:#888;">Durum</span><span style="color:#2ecc71;font-weight:700;">● ONLINE</span></div>' +
    '</div>';
}
loadStats();
</script>
{% endblock %}
'''

with open(os.path.join(templates_dir, 'settings.html'), 'w', encoding='utf-8') as f:
    f.write(settings_html)
print("settings.html yazildi")

print("\nTum template'ler basariyla yazildi!")
