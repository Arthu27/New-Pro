# Password Cracker Pro
# Sadece kendi şifrelerini test etmek için!