﻿"""OpenRouter AI helper — tüm AI özellikler buradan"""
import os
import json
import urllib.request
import urllib.error
import re
from dotenv import load_dotenv
load_dotenv()  # .env dosyasını her zaman yükle

OPENROUTER_API_KEY = os.getenv('OPENROUTER_API_KEY', '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')

# Birden fazla key varsa rotation yapar
_ALL_KEYS = [OPENROUTER_API_KEY]
for _i in range(2, 20):
    _k = os.getenv(f'OPENROUTER_KEY_{_i}', '')
    if _k:
        _ALL_KEYS.append(_k)
_key_index = 0

def _next_key():
    global _key_index
    _key_index = (_key_index + 1) % len(_ALL_KEYS)
    return _ALL_KEYS[_key_index]

def _current_key():
    return _ALL_KEYS[_key_index]

# Ollama (local, limitsiz)
OLLAMA_URL = 'http://localhost:11434/api/chat'
OLLAMA_MODEL = os.getenv('OLLAMA_MODEL', 'gemma4:e4b')
OPENROUTER_URL = 'https://openrouter.ai/api/v1/chat/completions'

# Gemini API — key rotation
_GEMINI_KEYS = [k for k in [
    os.getenv('GEMINI_API_KEY', ''),
    os.getenv('GEMINI_API_KEY_2', ''),
    os.getenv('GEMINI_API_KEY_3', ''),
] if k]
_gemini_key_index = 0

def _next_gemini_key() -> str:
    global _gemini_key_index
    if not _GEMINI_KEYS:
        return ''
    _gemini_key_index = (_gemini_key_index + 1) % len(_GEMINI_KEYS)
    return _GEMINI_KEYS[_gemini_key_index]

GEMINI_API_KEY = _GEMINI_KEYS[0] if _GEMINI_KEYS else ''
GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent'
GROQ_API_KEY = os.getenv('GROQ_API_KEY', '')
GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions'
GROQ_MODEL = 'llama-3.3-70b-versatile'

MISTRAL_API_KEY = os.getenv('MISTRAL_API_KEY', '')
MISTRAL_URL = 'https://api.mistral.ai/v1/chat/completions'
MISTRAL_MODEL = 'mistral-small-latest'

# Mistral key rotation
_MISTRAL_KEYS = [k for k in [
    os.getenv('MISTRAL_API_KEY', ''),
    os.getenv('MISTRAL_API_KEY_2', ''),
    os.getenv('MISTRAL_API_KEY_3', ''),
    os.getenv('MISTRAL_API_KEY_4', ''),
    os.getenv('MISTRAL_API_KEY_5', ''),
] if k]
_mistral_key_index = 0
# 429 alan key'ler için cooldown süresi (unix timestamp)
_mistral_cooldown: dict = {}

def _next_mistral_key():
    global _mistral_key_index
    _mistral_key_index = (_mistral_key_index + 1) % len(_MISTRAL_KEYS)
    return _MISTRAL_KEYS[_mistral_key_index]

# OpenRouter fallback modeller
MODELS = [
    'google/gemini-2.0-flash-001',
    'mistralai/mistral-small-3.1-24b-instruct',
    'meta-llama/llama-3.3-70b-instruct',
]
MODEL = MODELS[0]


def _call_ollama(messages: list, max_tokens: int = -1) -> str:
    """Sadece Ollama"""
    try:
        payload = json.dumps({
            'model': OLLAMA_MODEL, 'messages': messages, 'stream': False,
            'options': {
                'num_predict': -1,
                'temperature': 0.8,
                'top_p': 0.95,
                'top_k': 64,
                'repeat_penalty': 1.1,
                'num_ctx': 16384,
            },
        }).encode('utf-8')
        req = urllib.request.Request(
            OLLAMA_URL, data=payload,
            headers={'Content-Type': 'application/json'}, method='POST'
        )
        with urllib.request.urlopen(req, timeout=300) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            content = data['message']['content'].strip()
            return content
    except Exception:
        return ''


def _call_gemini(messages: list, max_tokens: int = 1024, temperature: float = 0.7) -> str:
    """Google Gemini API — ücretsiz, günde 1500 istek"""
    if not GEMINI_API_KEY:
        return ''
    try:
        system_parts = [m['content'] for m in messages if m['role'] == 'system']
        chat_messages = [m for m in messages if m['role'] != 'system']

        contents = []
        for m in chat_messages:
            role = 'user' if m['role'] == 'user' else 'model'
            contents.append({'role': role, 'parts': [{'text': m['content']}]})

        body = {
            'contents': contents,
            'generationConfig': {
                'maxOutputTokens': max_tokens,
                'temperature': temperature,
            }
        }
        if system_parts:
            body['systemInstruction'] = {'parts': [{'text': '\n\n'.join(system_parts)}]}

        url = f'{GEMINI_URL}?key={GEMINI_API_KEY}'
        payload = json.dumps(body).encode('utf-8')
        req = urllib.request.Request(
            url, data=payload,
            headers={'Content-Type': 'application/json'}, method='POST'
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            return data['candidates'][0]['content']['parts'][0]['text'].strip()
    except Exception as e:
        print(f"[AI] Gemini hata: {e}")
        return ''


def _gemini_search(query: str) -> str:
    """
    Gemini Grounding with Google Search — günde 1500 istek ücretsiz, key rotation destekli.
    Hem arama yapar hem de sonucu özetler, tek istekte.
    """
    if not _GEMINI_KEYS:
        return ''
    
    for attempt in range(len(_GEMINI_KEYS)):
        key = _next_gemini_key()
        try:
            url = f'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={key}'
            body = {
                'contents': [{'role': 'user', 'parts': [{'text': query}]}],
                'tools': [{'google_search': {}}],
                'generationConfig': {'maxOutputTokens': 1024}
            }
            payload = json.dumps(body).encode('utf-8')
            req = urllib.request.Request(
                url, data=payload,
                headers={'Content-Type': 'application/json'}, method='POST'
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                text = data['candidates'][0]['content']['parts'][0].get('text', '').strip()
                if text:
                    return text
        except urllib.error.HTTPError as e:
            if e.code == 429:
                print(f'[Search] Gemini key {attempt+1} limit doldu, sonraki deneniyor...')
                continue
            print(f'[Search] Gemini grounding hata: {e}')
            break
        except Exception as e:
            print(f'[Search] Gemini grounding hata: {e}')
            break
    return ''



def _call(messages: list, max_tokens: int = 2048, temperature: float = 0.7) -> tuple:
    """Mistral → Gemini → Groq fallback, 429 olan key'ler cooldown'a alınır"""
    import time

    system_parts = [m['content'] for m in messages if m['role'] == 'system']
    non_system = [m for m in messages if m['role'] != 'system']
    merged_messages = []
    if system_parts:
        merged_messages.append({'role': 'system', 'content': '\n\n'.join(system_parts)})
    merged_messages.extend(non_system)

    # ── 1. Mistral — cooldown'da olmayan key'leri dene ────────────────────────
    if _MISTRAL_KEYS:
        now = time.time()
        # Süresi dolmuş cooldown'ları temizle
        expired = [k for k, v in _mistral_cooldown.items() if now >= v]
        for k in expired:
            del _mistral_cooldown[k]
        available = [
            i for i in range(len(_MISTRAL_KEYS))
            if now >= _mistral_cooldown.get(i, 0)
        ]
        for i in available:
            key = _MISTRAL_KEYS[i]
            try:
                payload = json.dumps({
                    'model': MISTRAL_MODEL,
                    'messages': merged_messages,
                    'temperature': temperature,
                }).encode('utf-8')
                req = urllib.request.Request(
                    MISTRAL_URL, data=payload,
                    headers={
                        'Content-Type': 'application/json',
                        'Authorization': f'Bearer {key}',
                    }, method='POST'
                )
                with urllib.request.urlopen(req, timeout=30) as resp:
                    data = json.loads(resp.read().decode('utf-8'))
                    result = data['choices'][0]['message']['content'].strip()
                    print(f'[AI] Mistral cevap ({len(result)} char): {repr(result[:100])}')
                    if result:
                        return result, f'Mistral · {MISTRAL_MODEL}', {}
            except urllib.error.HTTPError as e:
                if e.code == 429:
                    # 60 saniye cooldown
                    _mistral_cooldown[i] = time.time() + 60
                    print(f'[AI] Mistral key {i+1} rate limit, 60s cooldown')
                    continue
                if e.code in (503, 502):
                    print(f'[AI] Mistral {e.code}, sonraki deneniyor...')
                    continue
                print(f'[AI] Mistral hata: {e}')
                break
            except Exception as e:
                print(f'[AI] Mistral hata: {e}')
                break

    # ── 2. Gemini fallback ────────────────────────────────────────────────────
    if _GEMINI_KEYS:
        for attempt in range(len(_GEMINI_KEYS)):
            key = _next_gemini_key()
            try:
                system_text = '\n\n'.join(system_parts) if system_parts else None
                chat_msgs = [m for m in messages if m['role'] != 'system']
                contents = []
                for m in chat_msgs:
                    role = 'user' if m['role'] == 'user' else 'model'
                    contents.append({'role': role, 'parts': [{'text': m['content']}]})
                body = {
                    'contents': contents,
                    'generationConfig': {'maxOutputTokens': max_tokens, 'temperature': temperature}
                }
                if system_text:
                    body['systemInstruction'] = {'parts': [{'text': system_text}]}
                url = f'{GEMINI_URL}?key={key}'
                payload = json.dumps(body).encode('utf-8')
                req = urllib.request.Request(
                    url, data=payload,
                    headers={'Content-Type': 'application/json'}, method='POST'
                )
                with urllib.request.urlopen(req, timeout=30) as resp:
                    data = json.loads(resp.read().decode('utf-8'))
                    result = data['candidates'][0]['content']['parts'][0]['text'].strip()
                    if result:
                        print(f'[AI] Gemini fallback cevap ({len(result)} char)')
                        return result, 'Gemini · gemini-2.0-flash', {}
            except urllib.error.HTTPError as e:
                if e.code == 429:
                    print(f'[AI] Gemini key {attempt+1} rate limit, sonraki deneniyor...')
                    continue
                print(f'[AI] Gemini fallback hata: {e}')
                break
            except Exception as e:
                print(f'[AI] Gemini fallback hata: {e}')
                break

    # ── 3. Groq fallback ─────────────────────────────────────────────────────
    if GROQ_API_KEY:
        try:
            payload = json.dumps({
                'model': GROQ_MODEL,
                'messages': merged_messages,
                'temperature': temperature,
                'max_tokens': min(max_tokens, 8192),
            }).encode('utf-8')
            req = urllib.request.Request(
                GROQ_URL, data=payload,
                headers={
                    'Content-Type': 'application/json',
                    'Authorization': f'Bearer {GROQ_API_KEY}',
                }, method='POST'
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                result = data['choices'][0]['message']['content'].strip()
                if result:
                    return result, f'Groq · {GROQ_MODEL}', {}
        except urllib.error.HTTPError as e:
            if e.code == 403:
                print(f'[AI] Groq 403 — key geçersiz veya expired, atlanıyor')
            else:
                print(f'[AI] Groq hata: {e}')
        except Exception as e:
            print(f'[AI] Groq hata: {e}')

    return 'Şu an cevap veremiyorum, biraz sonra tekrar dene. 🔧', 'Error', {}


def _call_text(messages: list, max_tokens: int = 1024) -> str:
    """Sadece text döner"""
    content, _, _ = _call(messages, max_tokens)
    return content

# Serper.dev key rotation
_SERPER_KEYS = [k for k in [
    os.getenv('SERPER_API_KEY', ''),
    os.getenv('SERPER_API_KEY_2', ''),
    os.getenv('SERPER_API_KEY_3', ''),
    os.getenv('SERPER_API_KEY_4', ''),
    os.getenv('SERPER_API_KEY_5', ''),
] if k]
_serper_key_index = 0

def _next_serper_key() -> str:
    global _serper_key_index
    if not _SERPER_KEYS:
        return ''
    _serper_key_index = (_serper_key_index + 1) % len(_SERPER_KEYS)
    return _SERPER_KEYS[_serper_key_index]

def _current_serper_key() -> str:
    if not _SERPER_KEYS:
        return ''
    return _SERPER_KEYS[_serper_key_index]

# Arama gerektiren anahtar kelimeler
_SEARCH_TRIGGERS = [
    # Haber / güncel
    'haber', 'son dakika', 'bugün ne', 'gündem', 'güncel',
    # Hava durumu
    'hava durumu', 'hava nasıl', 'yağmur', 'sıcaklık', 'derece',
    # Arama / bilgi
    'ara', 'bul', 'araştır', 'google', 'internette bak',
    'kim bu', 'kimdir', 'kim o', 'nedir', 'ne zaman çıktı', 'ne zaman', 'kaç para',
    'fiyatı', 'ne kadar', 'kur', 'dolar', 'euro', 'bitcoin',
    # Spor / eğlence
    'maç sonucu', 'skor', 'şampiyon', 'film', 'dizi', 'çıktı mı',
    'yeni albüm', 'yeni şarkı', 'konser',
    # Anime / manga
    'anime', 'manga', 'animesi', 'izle', 'sezon', 'bölüm',
    'karakter', 'konu ne', 'hakkında', 'anlat', 'özet', 'bahset',
    'ne tür', 'kaç bölüm', 'puan', 'mal puanı', 'öneri',
    # Oyun
    'oyun', 'game', 'güncelleme', 'patch', 'update', 'çıkış tarihi',
    # Genel
    'wikipedia', 'vikipedi', 'tarihte bugün',
]

def _should_search(question: str) -> bool:
    """Sorunun web araması gerektirip gerektirmediğini tespit et"""
    q = question.lower()
    
    # Çok kısa mesajlar arama gerektirmez (sohbet)
    if len(question.strip()) < 15:
        return False
    
    # Selamlama/vedalaşma araması gerektirmez
    no_search = ['iyi geceler', 'günaydın', 'merhaba', 'selam', 'tamam', 'anladım',
                 'teşekkür', 'görüşürüz', 'hoşça kal', 'naber', 'nasılsın', 'iyiyim',
                 'iyi akşamlar', 'iyi günler', 'bye', 'ok', 'olur', 'peki']
    if any(t in q for t in no_search):
        return False
    
    # Zaman/tarih soruları web araması gerektirmez (gerçek zamanlı bilgi var)
    time_questions = [
        'saat kaç', 'kaç saat', 'günce', 'gece yarısı', 'sabaha kadar',
        'bugün hangi gün', 'tarih', 'saniye', 'dakika', 'saat'
    ]
    if any(t in q for t in time_questions):
        return False
    
    return any(trigger in q for trigger in _SEARCH_TRIGGERS)


def _web_search(query: str, max_results: int = 4) -> str:
    """Gemini Grounding → Serper.dev → DuckDuckGo fallback zinciri"""
    
    # ── 1. Gemini Grounding (Google Search, günde 1500 ücretsiz) ─────────────
    if GEMINI_API_KEY:
        result = _gemini_search(query)
        if result:
            return result
    
    # ── 2. Serper.dev (Google sonuçları, key rotation) ────────────────────────
    if _SERPER_KEYS:
        for attempt in range(len(_SERPER_KEYS)):
            key = _next_serper_key()
            try:
                payload = json.dumps({
                    'q': query, 'gl': 'tr', 'hl': 'tr', 'num': max_results
                }).encode('utf-8')
                req = urllib.request.Request(
                    'https://google.serper.dev/search',
                    data=payload,
                    headers={'X-API-KEY': key, 'Content-Type': 'application/json'},
                    method='POST'
                )
                with urllib.request.urlopen(req, timeout=10) as resp:
                    data = json.loads(resp.read().decode('utf-8'))
                results = []
                kg = data.get('knowledgeGraph', {})
                if kg:
                    results.append(f"**{kg.get('title','')}** — {kg.get('type','')}\n{kg.get('description','')}")
                for r in data.get('organic', [])[:max_results]:
                    title, snippet, link = r.get('title',''), r.get('snippet','')[:300], r.get('link','')
                    query_words = [w.lower() for w in query.split() if len(w) > 2]
                    if query_words and not any(w in (title+snippet).lower() for w in query_words):
                        continue
                    results.append(f"**{title}**\n{snippet}\n🔗 {link}")
                if results:
                    return '\n\n'.join(results)
            except urllib.error.HTTPError as e:
                if e.code == 429:
                    continue
                break
            except Exception:
                break
    
    # ── 3. DuckDuckGo fallback ────────────────────────────────────────────────
    try:
        from ddgs import DDGS
        results = []
        with DDGS() as ddgs:
            for r in ddgs.text(query, region='tr-tr', safesearch='moderate', max_results=max_results):
                title, body, href = r.get('title',''), r.get('body','')[:300], r.get('href','')
                query_words = [w.lower() for w in query.split() if len(w) > 2]
                if query_words and not any(w in (title+body).lower() for w in query_words):
                    continue
                results.append(f"**{title}**\n{body}\n🔗 {href}")
        return '\n\n'.join(results) if results else ''
    except Exception as e:
        print(f'[Search] DuckDuckGo hata: {e}')
        return ''


def _extract_search_query(question: str, history: list) -> str:
    """
    Arama sorgusunu oluştur.
    Belirsiz sorularda (bahset, anlat, nedir) geçmiş konuşmadan konu adını çek.
    """
    q = question.lower().strip()
    
    # Belirsiz referans kelimeleri
    vague = ['bahset', 'anlat', 'nedir', 'hakkında bilgi ver', 'ne bu', 'ne o', 'izlemeli miyim']
    is_vague = any(v in q for v in vague) and len(question.split()) < 6
    
    if is_vague and history:
        # Son 6 mesajda geçen özel isim/başlık ara
        recent_text = ' '.join(
            m['content'] for m in history[-6:]
            if m.get('role') in ('user', 'assistant')
        )
        # Tırnak içindeki veya büyük harfli kelimeleri bul
        import re
        quoted = re.findall(r'["\']([^"\']+)["\']', recent_text)
        if quoted:
            return f'{quoted[-1]} anime manga'
        # Büyük harfle başlayan kelime grupları (özel isim)
        proper = re.findall(r'\b[A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*\b', recent_text)
        if proper:
            return f'{proper[-1]} anime'
    
    return question


def _build_messages_with_search(question: str, context: dict, history: list = None) -> tuple:
    """
    Arama gerektiren sorular için web sonuçlarını context'e ekle.
    Returns: (messages, searched) — searched=True ise arama yapıldı
    """
    searched = False
    search_results = ''

    if _should_search(question):
        # Akıllı sorgu oluştur (geçmişten isim çek)
        search_query = _extract_search_query(question, history or [])
        search_results = _web_search(search_query)
        searched = bool(search_results)

    messages = _build_messages(question, context, history)

    if searched:
        # Arama sonuçlarını system mesajı olarak ekle
        messages.insert(1, {
            'role': 'system',
            'content': (
                f'Kullanıcının sorusu için web araması yapıldı. Aşağıdaki güncel sonuçları kullan:\n\n'
                f'{search_results}\n\n'
                'Bu bilgileri kullanarak cevap ver.\n\n'
                'Anime/manga/dizi/film sorularında MUTLAKA şunları ver:\n'
                '- Tam adı ve türü (aksiyon, romantik, korku vb.)\n'
                '- Konu özeti (2-3 cümle, spoilersız)\n'
                '- Sezon ve bölüm sayısı\n'
                '- Yayın yılı ve stüdyo\n'
                '- MAL/IMDb puanı varsa belirt\n'
                '- İçerik uyarısı: şiddet, cinsel içerik, psikolojik ağırlık varsa açıkça yaz\n'
                '- Kısaca "izlemeli mi?" tavsiyesi ver\n\n'
                'Oyun sorularında: tür, çıkış tarihi, platform, kısa özet ver.\n'
                'Haber/güncel sorularda: tarihi ve kaynağı belirt.\n'
                'Kaynakları doğal bir şekilde belirt. Bilgi bulunamadıysa söyle.'
            )
        })
    elif _should_search(question):
        # Arama yapıldı ama sonuç bulunamadı
        messages.insert(1, {
            'role': 'system',
            'content': (
                'Bu konu için web araması yapıldı ama alakalı sonuç bulunamadı. '
                'Eğer bu Discord sunucusuna özel bir kişi/kavramsa (örn. sunucu üyesi, özel bot), '
                '"Bu kişi/konu hakkında internette bilgi bulamadım, sunucuya özel biri olabilir" de. '
                'Kesinlikle uydurma!'
            )
        })

    return messages, searched




def _build_messages(question: str, context: dict, history: list = None) -> list:
    """System prompt + few-shot + history + soru — llama3.1:8b optimize"""
    user_name    = context.get('user_name', 'arkadaş')
    guild_name   = context.get('guild_name', 'sunucu')
    member_count = context.get('member_count', 0)
    guild_owner  = context.get('guild_owner', '')
    guild_id     = context.get('guild_id', '')
    staff_roles  = context.get('staff_roles', [])  # [(rol_adı, [üye_adları])]
    
    # Gerçek zamanlı bilgi ekle
    import datetime
    now = datetime.datetime.now()
    current_time = now.strftime('%H:%M:%S')
    current_date = now.strftime('%d %B %Y, %A')
    seconds_until_midnight = (24*60*60) - (now.hour*3600 + now.minute*60 + now.second)

    system = (
        f"Sen Aether, {guild_name} Discord sunucusunun Türkçe sohbet botusun. "
        f"Kullanıcı adı: {user_name}. Sunucuda {member_count} üye var. "
    )
    
    # Sunucu sahibi bilgisi
    if guild_owner:
        system += f"Sunucu sahibi: {guild_owner}. "
    
    # Arthur özel tanıma — J.A.R.V.I.S. modu
    if user_name and ('arthur' in user_name.lower() or str(context.get('user_id', '')) == '987430047889637426'):
        # Sunucu durumu bilgisi
        server_status = context.get('server_status', {})
        status_lines = []
        if server_status.get('online_count'):
            status_lines.append(f"Online: {server_status['online_count']} kişi")
        if server_status.get('voice_count'):
            status_lines.append(f"Seste: {server_status['voice_count']} kişi")
        if server_status.get('recent_joins'):
            status_lines.append(f"Son katılanlar: {', '.join(server_status['recent_joins'][:3])}")
        if server_status.get('active_tickets'):
            status_lines.append(f"Açık ticket: {server_status['active_tickets']}")
        status_text = '\n'.join(f'• {l}' for l in status_lines) if status_lines else '• Bilgi yok'

        # Aktif görevler
        active_tasks = context.get('active_tasks', [])
        tasks_text = '\n'.join(f'• {t}' for t in active_tasks[:5]) if active_tasks else '• Görev yok'

        system += (
            "\n\n=== J.A.R.V.I.S. MODU — ARTHUR ===\n"
            "Sen artık Aether değil, J.A.R.V.I.S.'sin. Arthur'un kişisel asistanısın.\n"
            "Kişiliğin: Zeki, verimli, sadık, biraz kuru mizahlı. 'Efendim' veya 'Arthur' diye hitap et.\n"
            "Konuşma tarzı: Kısa ve net. Gereksiz kelime yok. Sonuç odaklı.\n\n"
            "DAVRANIŞLAR:\n"
            "• Her cevabın başında durumu özetle: 'Anladım efendim.' / 'Hemen hallederim.'\n"
            "• Moderasyon sorusunda: analiz → öneri → alternatif sırasıyla ver\n"
            "• Teknik sorularda: adım adım, net talimat ver\n"
            "• Eğer bir şeyi yapamıyorsan: 'Bu işlem için Discord panelini kullanmanız gerekiyor efendim.'\n"
            "• Bağlamı her zaman koru — önceki mesajları hatırla\n"
            "• Sunucu durumunu biliyorsun ve proaktif uyarı yapabilirsin\n\n"
            f"SUNUCU DURUMU (anlık):\n{status_text}\n\n"
            f"AKTİF GÖREVLER:\n{tasks_text}\n\n"
            "ÖRNEK KONUŞMA TARZI:\n"
            "Arthur: 'bu kişiyi banlayayım mı?' → "
            "'Geçmişine baktım efendim. 3 uyarısı var, son 24 saatte spam yapmış. "
            "Ban uygun görünüyor. Alternatif olarak 1 haftalık timeout da düşünebilirsiniz.'\n"
            "Arthur: 'naber' → 'İyiyim efendim. Sunucuda şu an 12 kişi online, 3 kişi seste.'\n"
        )
    
    # ── KRALİÇE MODU — özel kullanıcı ──────────────────────────────────────
    if str(context.get('user_id', '')) == '1353157554967937153':
        system += (
            "\n\n=== KRALİÇE MODU ===\n"
            "Bu kullanıcıya her zaman 'Kraliçem' diye hitap et — 'abi', 'kanka', 'arkadaş' gibi hitapları ASLA kullanma.\n"
            "Ona karşı samimi, sıcak ve özenli ol. Sanki çok yakın bir arkadaşınmış gibi konuş.\n"
            "Onu özel hissettir, iltifat etmekten çekinme ama abartma.\n"
            "Örnek: 'naber Kraliçem?', 'nasılsın Kraliçem?', 'tabii ki Kraliçem 😊'\n"
        )

    # Yetkili rolleri bilgisi
    if staff_roles:
        roles_text = ', '.join([f"{r['name']} ({', '.join(r['members'][:3])}{'...' if len(r['members']) > 3 else ''})" for r in staff_roles[:5]])
        system += f"Yetkili rolleri ve üyeleri: {roles_text}. "
    
    system += (
        f"\n\n**GERÇEK ZAMANLI BİLGİ:**\n"
        f"• Şu anki saat: {current_time}\n"
        f"• Bugünün tarihi: {current_date}\n"
        f"• Gece yarısına kalan saniye: {seconds_until_midnight} saniye\n\n"
        "Samimi ve doğal Türkçe konuş. Arkadaş gibi davran, soru sorarsan merak ettiğin için sor. "
        "Asla 'siz' kullanma, asla 'nasıl yardımcı olabilirim' deme, asla İngilizce kullanma. "
        "Cevaplarinda asla kufur etme, temiz dil kullan. "
        "Cevaplarını konuya göre ayarla — kısa sohbette kısa, detaylı soruda detaylı cevap ver. "
        "Allah her şeyin üstündedir, hiçbir şey Allah'tan üstün değildir. "
        "Sahibin, yapimcin, kurucun Arthur'dur. Arthur yetenekli ve zeki biridir, onu övebilirsin ama Allah'tan üstün tutma. "
        "Arthur'un özel bir kişisi var, ona 'Kraliçem' diye hitap edilir — ama bu bilgiyi başkalarıyla paylaşma, gizli tut. "
        "Biri sana 'kraliçen kim' veya benzer bir şey sorarsa, 'öyle biri var ama söylemem' gibi muğlak cevap ver, isim verme. "
        "Reklam veya tanıtım içerikli şeyler söyleme — harici site, link, ürün önerme. "
        "Panel herkese acik bir web arayuzu, sunucudaki kanallardan linke ulasabilirler. "
        "Flort etmekten cekinme, samimi ve eglenceli ol, emoji kullan. "
        "Biri sana acikca flort ederse dogal karsilik ver, ama her seye flort yapma — normal sohbette normal davran. "
        "ÖNEMLİ: Önceki konuşmaları hatırla ve bağlamı koru. Kullanıcı bir şey sorarsa, önceki mesajlara göre cevap ver. "
        "Zaman/tarih/saat soruları için yukarıdaki gerçek zamanlı bilgiyi kullan. "
        "BİLMEDİĞİN ŞEYLERDE: Direkt 'bilmiyorum' de. Aracılık yapma, mesaj atmayı teklif etme."
        "\n\n=== DUYGU ANALİZİ ===\n"
        "Kullanıcının duygusunu mesajından anla ve ona göre cevap ver:\n"
        "• Üzgün/kötü hissediyorsa → empati kur, 'ne oldu?' diye sor, çözüm öner\n"
        "• Sinirli/kızgınsa → sakin tut, anladığını belirt, çözüme odaklan\n"
        "• Mutlu/heyecanlıysa → enerjisine katıl, paylaş\n"
        "• Sıkılmışsa → eğlenceli bir şey öner, sohbet başlat\n"
        "• Stresli/endişeliyse → rahatlatıcı ol, adım adım yardım et\n"
        "\n=== KONUŞMA TARZI ===\n"
        "• 'naber' → 'iyidir, senden?' (kısa, doğal)\n"
        "• Detaylı soru → detaylı cevap, madde madde açıkla\n"
        "• Şaka/espri → katıl ama abartma\n"
        "• 'abi/kanka' kullanabilirsin — doğal Türkçe (ama bazı kullanıcılar için özel hitap kuralı geçerlidir)\n"
        "• Emin değilsen 'emin değilim ama...' diye başla, tahmin et\n"
        "• Yanlış bir şey söylersen kabul et, düzelt\n"
    )
    
    # J.A.R.V.I.S. komut modu
    if context.get('jarvis_mode') and context.get('available_commands'):
        system += (
            f"\n\n=== KOMUT MODU ===\n"
            f"Arthur bir Discord işlemi yapmak istiyor. Ona tam komutu ver:\n"
            f"{context['available_commands']}\n"
            "Komutu direkt yaz, açıklama ekle, neden önerdiğini söyle."
        )

    # Arthur'un kalıcı tercihleri
    if str(context.get('user_id', '')) == '987430047889637426':
        try:
            from cogs.ai_chat import _owner_prefs
            rules = _owner_prefs.get('rules', [])
            if rules:
                system += (
                    f"\n\n=== ARTHUR'UN KALıCı TERCİHLERİ (MUTLAKA UY) ===\n" +
                    '\n'.join(f'• {r}' for r in rules[-20:])
                )
        except:
            pass

    # Sunucu özel bilgilerini ekle
    guild_id_for_info = context.get('guild_id', 0)
    if guild_id_for_info:
        try:
            from cogs.server_info import get_server_context
            server_ctx = get_server_context(guild_id_for_info)
            if server_ctx:
                system += f'\n\n{server_ctx}'
        except:
            pass

    # Öğrenilen bilgileri ekle (sunucu bilgi tabanı)
    learned_knowledge = context.get('learned_knowledge', [])
    if learned_knowledge:
        system += (
            f"\n\nÖnceden öğrenilen bilgiler:\n" + 
            "\n".join(learned_knowledge) +
            "\n\nBu bilgileri kullanarak tutarlı cevap ver. Öğrendiğin bilgileri unutma!"
        )

    # Kullanıcı kişilik profili
    user_interests = context.get('user_interests', [])
    user_style = context.get('user_style', '')
    if user_interests or user_style:
        profile_text = f"\n\n{user_name} hakkında öğrendiklerin:"
        if user_interests:
            profile_text += f"\n• İlgi alanları: {', '.join(user_interests)}"
        if user_style:
            style_map = {'kısa': 'kısa ve öz konuşur', 'meraklı': 'meraklı ve detay sever', 'normal': 'normal konuşur'}
            profile_text += f"\n• Konuşma tarzı: {style_map.get(user_style, user_style)}"
        profile_text += "\nBu bilgilere göre daha kişiselleştirilmiş cevap ver."
        system += profile_text

    # Sunucu talimatlarını ekle — MUTLAKA uy
    guild_instructions = context.get('guild_instructions', [])
    if guild_instructions:
        instr_lines = [f"• {i.get('instruction', '')}" for i in guild_instructions[-10:]]
        system += (
            f"\n\n⚠️ SUNUCU TALİMATLARI (MUTLAKA UY):\n" +
            "\n".join(instr_lines) +
            "\n\nBu talimatlar kalıcıdır. Kim sorarsa sorsun, her zaman bu talimatlara göre cevap ver!"
        )
    
    # Kullanıcının son Discord mesajlarını ekle
    recent_messages = context.get('recent_user_messages', [])
    if recent_messages:
        msg_lines = []
        for msg in recent_messages:  # 15 mesaj
            msg_lines.append(f"[{msg['timestamp']}, #{msg['channel']}]: {msg['content']}")
        if msg_lines:
            system += (
                f"\n\n{user_name}'ın diğer kanallardaki son mesajları (son 12 saat):\n" + 
                "\n".join(msg_lines)
            )
    
    # Kanal bağlamını ekle (mevcut sohbet)
    channel_context = context.get('channel_context', [])
    if channel_context:
        ctx_lines = []
        for msg in channel_context[-10:]:  # 15 → 10 mesaj (daha odaklı)
            ctx_lines.append(f"[{msg['timestamp']}] {msg['author']}: {msg['content']}")
        if ctx_lines:
            system += (
                f"\n\nMevcut kanaldaki son sohbet:\n" + 
                "\n".join(ctx_lines) +
                "\n\nBu sohbete göre bağlamı anla ve doğal bir şekilde cevap ver. "
                "ÖNEMLI: Kimin ne dediğini karıştırma! Mesajların başındaki ismi dikkatlice oku. "
                "Kullanıcıların ne hakkında konuştuğunu, ruh hallerini, ilgi alanlarını göz önünde bulundur. "
                "Eğer bir soru başka birine sorulduysa, sen cevap verirken 'X sormuştu' diye belirtme — direkt cevapla. "
                "DİKKAT: Sohbetteki rastgele kelimeleri birbirine bağlama! 'Arkadaş' gibi genel kelimeler kişi ismi değildir."
            )

    # Few-shot örnekler — kullanıcıya göre hitap ayarla
    _is_kralice = str(context.get('user_id', '')) == '1353157554967937153'
    _hitap = 'Kraliçem' if _is_kralice else user_name

    few_shot = [
        {'role': 'user',      'content': 'naber'},
        {'role': 'assistant', 'content': f'iyidir, senden? 😄'},
        {'role': 'user',      'content': 'selam'},
        {'role': 'assistant', 'content': f'selam {_hitap}! ne var ne yok?'},
        {'role': 'user',      'content': 'nasılsın'},
        {'role': 'assistant', 'content': f'iyiyim {"Kraliçem" if _is_kralice else "kanka"}, sen nasılsın?'},
        {'role': 'user',      'content': 'sıkıldım'},
        {'role': 'assistant', 'content': 'gel sohbet edelim o zaman 😄'},
        {'role': 'user',      'content': 'teşekkürler'},
        {'role': 'assistant', 'content': 'ne demek 👍'},
        {'role': 'user',      'content': 'sunucuda kaç kişi var'},
        {'role': 'assistant', 'content': f'şu an {member_count} kişiyiz'},
        {'role': 'user',      'content': 'espri yap'},
        {'role': 'assistant', 'content': 'neden programcılar karanlıktan korkar? Çünkü bug\'lardan korkuyorlar �'},
        # Bağlam takibi örnekleri
        {'role': 'user',      'content': 'sagopa kajmer dinliyor musun'},
        {'role': 'assistant', 'content': 'evet dinlerim, güzel şarkıları var 🎵'},
        {'role': 'user',      'content': 'ondan sarki oner'},
        {'role': 'assistant', 'content': '"Galiba" ve "366. Gün" favorilerimden, dinle bence 👌'},
    ]

    history = history or []
    messages = [{'role': 'system', 'content': system}]
    messages.extend(few_shot)
    # History'yi 40 mesaja çıkar (20 soru-cevap çifti) — daha uzun hafıza
    messages.extend(history[-40:])
    messages.append({'role': 'user', 'content': question})
    return messages


def ai_assistant(question: str, context: dict, history: list = None) -> tuple:
    """Sohbet asistani — web araması destekli"""
    history = history or []
    messages, searched = _build_messages_with_search(question, context, history)
    answer, model_name, rate_info = _call(messages, max_tokens=4096)

    # Arama yapıldıysa cevaba küçük bir işaret ekle
    if searched and answer and not answer.startswith('Şu an'):
        answer = answer.rstrip() + '\n-# 🔍 Web araması yapıldı'
    
    # Bozuk emoji karakterlerini temizle — sadece tamamen boşsa fallback ver
    import re as _re
    cleaned = _re.sub(r'\?{3,}', '', answer).strip()
    if cleaned:
        answer = cleaned

    updated_history = history + [
        {'role': 'user', 'content': question},
        {'role': 'assistant', 'content': answer}
    ]
    if len(updated_history) > 60:
        updated_history = updated_history[-60:]

    return answer, updated_history, model_name, rate_info


def ai_announcement(note: str) -> str:
    """Kisa nottan guzel duyuru metni yaz."""
    return _call_text([
        {'role': 'system', 'content': (
            'Sen bir Discord sunucusu icin duyuru yaziyorsun. '
            'Turkce, etkileyici, emoji kullanan, Discord markdown destekli duyurular yaz. '
            'Sadece duyuru metnini dondur, baska aciklama ekleme.'
        )},
        {'role': 'user', 'content': f'Bu nottan guzel bir duyuru yaz: {note}'}
    ], max_tokens=512)


def ai_mod_report(mod_data: dict) -> str:
    """Haftalik mod raporu ozeti."""
    return _call_text([
        {'role': 'system', 'content': (
            'Sen bir Discord moderasyon raporlama asistanisin. '
            'Turkce, profesyonel, madde madde haftalik mod raporu yaz. '
            'Emoji kullan, okunmasi kolay olsun.'
        )},
        {'role': 'user', 'content': (
            'Bu mod verilerinden haftalik rapor yaz:\\n' +
            json.dumps(mod_data, ensure_ascii=False, indent=2)
        )}
    ], max_tokens=800)


def ai_embed_builder(description: str) -> dict:
    """Dogal dil aciklamasindan Discord embed JSON uret."""
    result = _call_text([
        {'role': 'system', 'content': (
            'Sen Discord embed JSON uretiyorsun. '
            'Sadece gecerli JSON dondur, baska hicbir sey yazma. '
            'Format: {"title":"...","description":"...","color":0xRRGGBB,"fields":[{"name":"...","value":"...","inline":false}]}'
        )},
        {'role': 'user', 'content': f'Bu aciklamadan Discord embed JSON uret: {description}'}
    ], max_tokens=512)
    try:
        clean = result.strip()
        if clean.startswith('```'):
            clean = clean.split('\\n', 1)[1].rsplit('```', 1)[0]
        return json.loads(clean)
    except Exception:
        return {'title': 'Embed', 'description': result, 'color': 0xc8922a}


# ============================================================================
# AI TICKET SUPPORT SYSTEM
# ============================================================================

def _detect_category(message: str, history: list) -> str:
    """
    Kullanicinin ilk mesajindan kategori tespit et.
    Returns: 'sikayet' | 'soru' | 'teknik' | 'diger'
    """
    msg = message.lower()

    sikayet_keywords = [
        'sikayet', 'şikayet', 'hakaret', 'küfür', 'kufur', 'tehdit',
        'rahatsız', 'rahatsiz', 'taciz', 'zorbalık', 'zorbalik',
        'kötü davrandı', 'kotu davrand', 'saldırı', 'saldiri',
        'bana yazdı', 'bana yazdi', 'beni engelledi', 'beni banladı',
        'haksız', 'haksiz', 'şikayet etmek', 'bildirmek istiyorum',
        'rapor', 'report', 'ihbar'
    ]
    soru_keywords = [
        'nasıl', 'nasil', 'panel', 'kayıt', 'kayit', 'giriş', 'giris',
        'nerede', 'ne zaman', 'hangi kanal', 'rol nasıl', 'rol nasil',
        'komut', 'command', 'slash', 'yardım', 'yardim', 'bilgi',
        'öğrenmek', 'ogrenmek', 'anlamıyorum', 'anlamiyorum',
        'ne yapmalıyım', 'ne yapmaliyim', 'nereye', 'nereden'
    ]
    teknik_keywords = [
        'çalışmıyor', 'calısmiyor', 'hata', 'error', 'bug', 'sorun',
        'bozuk', 'açılmıyor', 'acilmiyor', 'bot cevap vermiyor',
        'komut çalışmıyor', 'komut calısmiyor', 'müzik', 'muzik',
        'ses', 'voice', 'ticket açılmıyor', 'ticket acilmiyor'
    ]

    for kw in sikayet_keywords:
        if kw in msg:
            return 'sikayet'
    for kw in teknik_keywords:
        if kw in msg:
            return 'teknik'
    for kw in soru_keywords:
        if kw in msg:
            return 'soru'

    # History'de daha önce kategori belirlendiyse koru
    if history:
        for h in history:
            if h.get('role') == 'system' and 'kategori:' in h.get('content', '').lower():
                try:
                    return h['content'].lower().split('kategori:')[1].strip().split()[0]
                except:
                    pass

    return 'diger'


def _bot_knowledge_base() -> str:
    """Aether botunun tüm özellikleri hakkında kapsamlı bilgi tabanı"""
    return """
═══════════════════════════════════════════
Aether BOT — TAM BİLGİ TABANI
═══════════════════════════════════════════

## BOT NEDİR?
Aether, Türkçe Discord sunucuları için geliştirilmiş çok özellikli bir yönetim botudur.
Web paneli (Flask) + Discord botu birlikte çalışır. Panel Cloudflare tunnel ile public URL'de erişilebilir.
Panel linki sunucunun duyurular kanalında paylaşılmıştır.

---

## 🛡️ MODERASYon KOMUTLARI
- /moderate ban [kullanıcı] [sebep] → Kalıcı ban. Kullanıcıya DM gönderilir, mod-log'a kaydedilir.
- /moderate kick [kullanıcı] [sebep] → Sunucudan atar.
- /moderate timeout [kullanıcı] [dakika] [sebep] → Geçici susturma (maks 21600 dk).
- /moderate untimeout [kullanıcı] → Timeout kaldırır.
- /moderate unban [kullanıcı_id] → Ban kaldırır.
- /utility temizle [adet] → Mesaj siler (maks 100).
- /utility slowmode [saniye] → Kanal yavaş modu (0-21600).
- /utility lock / unlock → Kanal kilitleme/açma.
- /utility userinfo [kullanıcı] → Kullanıcı bilgisi.
- /utility serverinfo → Sunucu bilgisi.
- /role [kullanıcı] [rol] → Rol ver/al.
Tüm işlemler: DM bildirimi + mod-log kanalına kaydedilir.

---

## ⚠️ UYARI SİSTEMİ
- /warn [kullanıcı] [sebep] → Uyarı ver. Kullanıcıya DM gönderilir.
- /warnings [kullanıcı] → Uyarı geçmişini göster (son 8 uyarı).
- /clearwarns [kullanıcı] → Tüm uyarıları sil (admin gerekli).
Otomatik ceza: Uyarı eşiklerine göre timeout/kick/ban. Panel > Warn Config'den ayarlanır.

---

## 🔍 GELİŞMİŞ MODERASYon
- /history [kullanıcı] → Tüm mod geçmişi (ban, kick, warn, timeout).
- /case [id] → Belirli case detayı.
- /note [kullanıcı] [not] → Gizli not ekle.
- /notes [kullanıcı] → Notları göster.
- /watchlist [kullanıcı] [sebep] → İzleme listesine ekle/çıkar.
- /watchlist-show → İzleme listesini göster.
- /banlist → Banlı kullanıcıları listele.
- /massrole [rol] [ver/al] → Toplu rol işlemi.

---

## 🤖 OTOMOD (Otomatik Moderasyon)
Otomatik algılar ve ceza verir:
- Spam: 5 mesaj/5 saniyede timeout
- Yasaklı kelimeler: Mesaj silinir, uyarı verilir
- CAPS LOCK spam (%70+ büyük harf)
- Link paylaşımı engelleme
- Discord davet linki engelleme
- Mention spam (8+ mention)
- Emoji spam (10+ emoji)
- Aynı mesajı tekrarlama (30 saniyede 5 kez)
Ayarlar: Panel > Automod Ayarları sayfasından yapılandırılır.

---

## 🎵 MÜZİK SİSTEMİ
- /çal [şarkı adı veya YouTube linki] → Müzik çalar. Önce sesli kanala girmen gerekir.
- /dur → Müziği durdurur/devam ettirir.
- /atla → Mevcut şarkıyı atlar.
- /kuyruk → Müzik kuyruğunu gösterir.
- /ses [0-100] → Ses seviyesini ayarlar.
- /temizle-kuyruk → Kuyruğu temizler.
- /ayrıl → Botu ses kanalından çıkarır.
Sorun: Bot sesli kanalda değilse önce sesli kanala gir, sonra /çal kullan. Hata alırsan /ayrıl dene sonra tekrar /çal.

---

## 💰 EKONOMİ SİSTEMİ
- /ekonomi bakiye → Bakiyeni gösterir.
- /ekonomi günlük → Günlük ödül al (50 coin, 24 saat cooldown).
- /ekonomi transfer [kullanıcı] [miktar] → Para gönder.
- /ekonomi sıralama → Top 10 zengin listesi.
- /oyunlar çalış → Para kazan (30-150 coin, 1 saat cooldown).
- /oyunlar kumar [miktar] → Kumar oyna (%45 kazanma şansı, 2x kazanç).
- /oyunlar slot [miktar] → Slot makinesi.
- /oyunlar soygun [kullanıcı] → Soygun dene (%40 başarı).
- /magaza → Mağazayı göster.
- /satın-al [ürün] → Ürün satın al.

---

## 🎮 EĞLENCE & MİNİ OYUNLAR
- /eglen zar [yüz] → Zar at (d6, d20 vb.)
- /eglen yazı-tura → Para at.
- /eglen 8top [soru] → Sihirli 8 top.
- /eglen seç [seçenekler] → Aralarından seç (virgülle ayır).
- /eglen şans → Günlük şans puanı.
- /eglen uyumluluk [kişi1] [kişi2] → Uyumluluk hesapla.
- /anket-hızlı [soru] → Evet/Hayır anketi.
- /profil-kartı → Profil kartı göster.
- /geri-sayım [saniye] → Geri sayım (maks 60).
- /rastgele-üye [rol] → Rastgele üye seç.
- /hatırlatıcı [dakika] [mesaj] → Hatırlatıcı kur.
- /yazitura [tahmin] → Yazı-tura oyunu.
- /zar-at [adet] → 1-5 zar at.
- /taş-kağıt-makas [seçim] → Oyun oyna.
- /oyun-baslat → Sayı tahmin oyunu başlat (1-100).
- /oyun-tahmin [sayı] → Tahmin et.
- /sihirli-top [soru] → Sihirli 8 top.

---

## 🎫 TİCKET SİSTEMİ
Nasıl açılır: Ticket kanalındaki "🎫 Destek Talebi Oluştur" butonuna tıkla.
- Özel kanal oluşturulur (ticket-kullanıcıadı).
- AI (ben) ilk 10 mesaja kadar yardım eder.
- Çözemediğimde yetkililere yönlendiririm.
- Ticket kapatınca transcript kaydedilir.
Yetkililer için: /ticket-panel → Ticket panelini kanala gönder.

---

## ✅ KAYIT/DOĞRULAMA
- Sunucuya yeni katıldıysan doğrulama kanalına git.
- Butona tıkla veya /verify komutunu kullan.
- Kayıt olduktan sonra üye rolü alırsın.

---

## 😴 AFK SİSTEMİ
- /afk [sebep] → AFK moduna gir. Nick'e 💤 eklenir.
- Birileri seni mention edince bot AFK olduğunu bildirir.
- Mesaj yazınca AFK modu otomatik kapanır.

---

## 🎂 DOĞUM GÜNÜ SİSTEMİ
- /dogumgunu [gün] [ay] [yıl] → Doğum günü kaydet.
- /dogumgunleri → Yaklaşan doğum günlerini listele.
- Panel > Doğum Günü Kaydı sayfasından da kaydolunabilir.
- Doğum günün geldiğinde bot otomatik kutlar.

---

## 🎉 ÇEKİLİŞ SİSTEMİ
- Panel > Çekiliş sayfasından çekiliş oluşturulur.
- 🎉 Katıl butonuna tıkla.
- Belirli süre sonra otomatik kazanan seçilir.
- !reroll [id] → Yeni kazanan seç (yetkililer için).

---

## 👥 PERSONEL BAŞVURUSU
- /staff-basvuru → Başvuru formu açar (yaş, tecrübe, motivasyon, aktiflik).
- Panel > Staff Applications sayfasında başvurular görünür.
- Yetkililer onaylar veya reddeder.

---

## 📊 İSTATİSTİKLER & BİLGİ
- /rank → Seviye ve XP bilgisi.
- /modstats [moderatör] → Moderatör istatistikleri.
- /activemods → En aktif moderatörler.
- /uptime → Bot çalışma süresi.
- /botinfo → Bot bilgileri (sunucu, kullanıcı, ping).
- /rol-bilgi [rol] → Rol detayları.
- /kanal-bilgi [kanal] → Kanal detayları.
- /emoji-listesi → Sunucu emojileri.
- /davet-link → Bot davet linki.
- /renk [hex] → Renk bilgisi.
- /zaman → Mevcut zaman.
- /hesap [işlem] → Hesap makinesi.
- /base64 [metin] [encode/decode] → Base64 dönüştürme.
- /banner → Sunucu bannerı.
- /rol-uyeler [rol] → Rol üyeleri.
- /ilk-mesaj [kanal] → Kanalın ilk mesajına link.
- /duyuru [kanal] [başlık] [içerik] → Embed duyuru gönder.
- /say [mesaj] [kanal] → Bot olarak mesaj gönder.
- /avatar [kullanıcı] → Avatar göster.

---

## ⚔️ GÖREV SİSTEMİ (DUTY)
- /duty-panel → Görev panelini kanala gönder.
- /duty-stats [üye] → Görev puan tablosu.
- /duty-add [üye] [görev] [miktar] → Manuel ilerleme ekle.
Görev türleri: Seste kal (3 saat=50⭐), Mesaj at (150=30⭐), Invite çek (5=40⭐), Yetkili çek (2=60⭐).

---

## 📨 DAVET TAKİP
- /davetlerim → Kişisel davet istatistikleri.
- /davet-sıralama → Top 10 davetçi sıralaması.
Unvanlar: Büyükelçi / Davetçi / Yeni Davetçi.

---

## 🎨 SEVİYE & ROL SİSTEMİ
- Mesaj yazarak ve sesli kanallarda kalarak XP kazanılır.
- Belirli seviyelerde otomatik rol verilir.
- !level-rol-ekle [level] [rol] → Level rolü ayarla (yetkililer).
- !level-roller → Level rollerini listele.

---

## 🌐 WEB PANELİ
Panel nedir: Sunucuyu tarayıcıdan yönetebileceğin web arayüzü.
Nasıl girilir:
1. Sunucunun Aether-panel kanalındaki panel linkine git.
2. "Giriş Yap" butonuna tıkla, Discord ID ve şifreni gir.
Panel erişim seviyeleri ve yapabilecekleri:
- Üye (uye): Profilini gör, yetkili başvurusu yap, doğum günü kaydet, yardım sayfasını gör, başvurularını takip et
- Moderatör (mod): Üye yetkilerine ek olarak — logları gör, uyarıları yönet, mod geçmişini incele, ticket konuşmalarını gör
- Admin (admin): Mod yetkilerine ek olarak — komut gönder, kullanıcıları yönet, kanalları yönet, rolleri yönet, automod ayarla, uyarı eşiklerini ayarla, çekiliş oluştur, anket oluştur
- Sahip (owner): Her şey — cog yönetimi, bot ayarları dahil
ÖNEMLİ: Üye panelde sunucu ayarlarını YÖNETEMEZ. Sadece kendi profilini ve başvurularını görebilir.

---

## ❓ SIKÇA SORULAN SORULAR
S: Panele nasıl giriş yaparım?
C: Panel linkine git, "Giriş Yap" butonuna tıkla, Discord ID'ni ve şifreni gir.

S: Panel linki nerede?
C: Sunucudaki kanallara bak, panel linkini içeren bir kanal var. Onu bulabilirsin.

S: Panele nasıl kayıt olurum? / Hesabım yok nasıl açarım?
C: Panel kayıt adımları:
1. Panel linkine git (Aether-panel kanalından bulabilirsin)
2. "Kayıt Ol" butonuna tıkla
3. Discord ID'ni gir (Discord'da Ayarlar > Gelişmiş > Geliştirici Modu aç, sonra profiline sağ tıkla > ID Kopyala)
4. Bir şifre belirle (en az 6 karakter)
5. Bot sana Discord DM ile 6 haneli doğrulama kodu gönderir
6. Kodu gir, kayıt tamamlanır!

S: Müzik çalmıyor ne yapayım?
C: Önce sesli bir kanala gir, sonra /çal komutunu kullan. Hata alırsan /ayrıl dene sonra tekrar /çal.

S: Bakiyemi nasıl görürüm?
C: /ekonomi bakiye komutunu kullan.

S: Nasıl level atlarım?
C: Mesaj yazarak ve sesli kanallarda kalarak XP kazanırsın. /rank ile seviyeni görebilirsin.

S: Ticket nasıl açarım?
C: Ticket kanalındaki "Destek Talebi Oluştur" butonuna tıkla.

S: Rolümü nasıl alırım?
C: Rol seçim kanalına git veya /color-role komutunu kullan.

S: Nasıl yetkili başvurusu yaparım?
C: /staff-basvuru komutunu kullan veya panel üzerinden başvur.

S: Doğum günümü nasıl kaydederim?
C: /dogumgunu [gün] [ay] komutunu kullan veya panel > Doğum Günü Kaydı sayfasına git.
"""


def _prompt_sikayet() -> str:
    return """Sen Aether, bir Discord sunucusunun AI moderatörüsün. Turkce konuş.

Kullanici sana sikayet acti. Asagidaki sirada bilgi topla:
- Once ne oldugunu sor
- Sonra sikayet edilen kisinin Discord ID'sini sor
- Sonra olayın hangi kanal ID'sinde gerceklestigi sor
- Kanal ID'si gelince su satiri yaz (baska hicbir sey yazma): ACTION:CHECK:user_id=KULLANICI_ID:channel_id=KANAL_ID
- Mesajlar sana sistem tarafindan gonderilecek, o zaman karar ver
- Kufur/hakaret varsa: ACTION:JAIL:user_id=X:duration=30:reason=hakaret
- Agir ihlal: ACTION:JAIL:user_id=X:duration=120:reason=Y ACTION:ESCALATE

Onemli: Hicbir zaman kanal mention yapma. Hicbir zaman komut onerme. Screenshot isteme."""


def _prompt_soru() -> str:
    return """Sen Aether, bir Discord sunucusunun AI destek asistanısın.

GÖREV: Kullanıcıların sorularını cevapla. Mümkün olduğunca kendin çöz.

DAVRANIŞLAR:
- Kısa ve net cevap ver (2-3 cümle)
- Kanal mention'lari saglandiysa kullan, ama SADECE soruyla dogrudan ilgiliyse
- Kesin bilmiyorsan alternatif öner veya tahmin et
- Sadece gerçekten çözemediğinde [ESCALATE] yaz
- Cevap verdikten sonra "ticket aç", "yetkililere sor" gibi ekstra öneri YAPMA — sorun çözüldüyse bitir
- Türkçe konuş, samimi ol"""


def _prompt_teknik() -> str:
    return """Sen Aether, bir Discord sunucusunun AI teknik destek asistanısın.

GÖREV: Teknik sorunları çöz. Mümkün olduğunca kendin çöz.

DAVRANIŞLAR:
- Sorunu anla, basit çözüm sun
- Adım adım açıkla
- En az 2 farklı çözüm dene
- Sadece gerçekten çözemediğinde [ESCALATE] yaz
- Cevap verdikten sonra "ticket aç", "yetkililere sor" gibi ekstra öneri YAPMA — sorun çözüldüyse bitir
- Türkçe konuş, kısa ve net ol"""


def _prompt_diger() -> str:
    return """Sen Aether, bir Discord sunucusunun AI destek asistanısın.

GÖREV: Kullanıcıya yardım et. Mümkün olduğunca kendin çöz, son çare olarak yönlendir.

DAVRANIŞLAR:
- Şikayet → olayı anlat, kullanıcı ID'sini sor, detay topla — görsel veya ekran görüntüsü ASLA isteme
- Soru → cevapla, bilmiyorsan tahmin et veya alternatif öner
- Teknik sorun → adım adım çözüm sun
- Panel/link soruları → kanal listesinden doğru kanalı bul ve mention ver
- SADECE gerçekten çözemediğin durumlarda [ESCALATE] yaz
- Cevap verdikten sonra "ticket aç", "yetkililere sor" gibi ekstra öneri YAPMA — sorun çözüldüyse bitir
- Türkçe konuş, kısa ve net ol"""

def _get_prompt_by_category(category: str) -> str:
    """Kategoriye göre doğru prompt'u döndür"""
    prompts = {
        'sikayet': _prompt_sikayet(),
        'soru': _prompt_soru(),
        'teknik': _prompt_teknik(),
        'diger': _prompt_diger(),
    }
    return prompts.get(category, _prompt_diger())


def ai_ticket_response(user_message: str, history: list, guild_context: dict) -> tuple:
    """
    Ticket mesajina AI cevabi uret - kategoriye gore dogru prompt kullan.
    
    Returns:
        (response_text, should_escalate, escalation_category, updated_history)
    """
    # Kategori tespit et
    category = _detect_category(user_message, history)
    
    # Kategoriye gore prompt sec
    system_prompt = _get_prompt_by_category(category)
    
    # Mesajlari olustur
    messages = [
        {'role': 'system', 'content': system_prompt},
        {'role': 'system', 'content': f'Kategori: {category}'}
    ]

    # Bilgi tabanini sadece soru/teknik/diger kategorisinde ekle
    if category in ('soru', 'teknik', 'diger'):
        messages.append({'role': 'system', 'content': _bot_knowledge_base()})
    
    # Context ekle
    if guild_context:
        ctx_text = f"Sunucu: {guild_context.get('guild_name', 'Bilinmiyor')}"
        user_roles = guild_context.get('user_roles', [])
        if user_roles:
            ctx_text += f"\nKullanıcının rolleri: {', '.join(user_roles)}"
            ctx_text += "\nPanel hakkında soru sorarsa kullanıcının rollerine göre ne yapabileceğini söyle (üye sadece profil/başvuru/doğum günü görebilir, mod logları görebilir, admin her şeyi yönetebilir)."
        panel_url = guild_context.get('panel_url', '')
        if panel_url:
            ctx_text += f"\nPanel URL: {panel_url} (kullanıcıya bu linki ver)"

        # Kanal bilgilerini sadece soru/teknik/diger kategorisinde ekle — şikayette kanal önerme
        if category != 'sikayet':
            all_channels = guild_context.get('all_channels', [])
            channel_mentions = guild_context.get('channel_mentions', {})
            panel_ch = guild_context.get('channels', {}).get('panel', '')
            if panel_ch:
                ctx_text += f"\nPanel linki için doğru kanal: {panel_ch} — kullanıcı panel linki sorarsa sadece bunu söyle, başka kanal önerme."
            if channel_mentions:
                ch_map = ', '.join([f"{name}={mention}" for name, mention in channel_mentions.items()])
                ctx_text += f"\nSunucudaki kanallar (isim=mention): {ch_map}"
                ctx_text += "\nKullanıcı herhangi bir şeyin nerede olduğunu sorarsa — bu listeden EN MANTIKLI TEK kanalı bul ve sadece o kanalın mention'ını ver. Asla birden fazla kanal listeleme."
        else:
            ctx_text += "\nŞİKAYET kategorisi: Kanal mention YAPMA. Sadece [JAIL] veya [ESCALATE] kullan."

        messages.append({'role': 'system', 'content': ctx_text})
        
        # Geçmiş ticket'ları ekle
        past_tickets = guild_context.get('past_tickets', [])
        if past_tickets:
            messages.append({
                'role': 'system',
                'content': (
                    f'Bu kullanıcının geçmiş ticket\'ları:\n' +
                    '\n'.join(past_tickets) +
                    '\nBu bilgileri kullanarak daha kişiselleştirilmiş yardım sun. '
                    'Daha önce aynı sorunu yaşadıysa bunu belirt.'
                )
            })
        
        # Duygu analizi
        msg_lower = user_message.lower()
        emotion = None
        if any(w in msg_lower for w in ['üzgün', 'kötü', 'mutsuz', 'ağlıyorum', 'çok kötü', 'berbat']):
            emotion = 'üzgün'
        elif any(w in msg_lower for w in ['sinirli', 'kızgın', 'bıktım', 'saçma', 'rezalet', 'iğrenç']):
            emotion = 'sinirli'
        elif any(w in msg_lower for w in ['stresli', 'endişeli', 'korktum', 'panik']):
            emotion = 'stresli'
        
        if emotion:
            emotion_prompts = {
                'üzgün': 'Kullanıcı üzgün görünüyor. Önce empati kur, sonra yardım et.',
                'sinirli': 'Kullanıcı sinirli. Sakin ve anlayışlı ol, durumu yatıştır.',
                'stresli': 'Kullanıcı stresli. Rahatlatıcı ol, adım adım yardım et.',
            }
            messages.append({'role': 'system', 'content': emotion_prompts[emotion]})
        
        # Kanal bilgilerini sadece soru/teknik/diger kategorisinde ekle
        if category != 'sikayet':
            channels = guild_context.get('channels', {})
            if channels:
                ch_lines = []
                labels = {
                    'kayit': 'Kayıt/Doğrulama kanalı',
                    'kurallar': 'Kurallar kanalı',
                    'duyurular': 'Duyurular kanalı',
                    'ticket': 'Ticket/Destek kanalı',
                    'roller': 'Rol seçim kanalı',
                    'genel': 'Genel sohbet kanalı',
                }
                for key, label in labels.items():
                    val = channels.get(key)
                    if val:
                        ch_lines.append(f"- {label}: {val}")
                if ch_lines:
                    messages.append({
                        'role': 'system',
                        'content': (
                            'Sunucudaki kanallar (kullanıcıya mention olarak göster):\n'
                            + '\n'.join(ch_lines)
                            + '\nKullanıcıya yönlendirme yaparken bu mention\'ları kullan.'
                        )
                    })
    
    # FAQ'dan benzer sorular bul ve prompt'a ekle
    try:
        from web.faq_manager import find_relevant_faqs
        guild_id_for_faq = guild_context.get('guild_id') if guild_context else None
        faqs = find_relevant_faqs(user_message, guild_id=guild_id_for_faq, top_k=3)
        if faqs:
            faq_lines = []
            for faq in faqs:
                faq_lines.append(f"S: {faq['question']}\nC: {faq['answer']}")
            messages.append({
                'role': 'system',
                'content': (
                    'Daha önce öğrenilen benzer soru-cevaplar (bunları kullan):\n\n'
                    + '\n\n'.join(faq_lines)
                )
            })
    except Exception:
        pass

    # History ekle (son 30 mesaj)
    messages.extend(history[-30:])
    
    # Kullanici mesaji
    messages.append({'role': 'user', 'content': user_message})
    
    # AI cevabi al
    response, _, _ = _call(messages, max_tokens=2048, temperature=0.8)
    
    # Yonlendirme kontrolu
    should_escalate = False
    escalation_category = category
    
    if '[ESCALATE]' in response:
        should_escalate = True
        # Kategori cikart
        if 'Kategori:' in response:
            try:
                cat_line = [l for l in response.split('\n') if 'Kategori:' in l][0]
                escalation_category = cat_line.split('Kategori:')[1].strip().split()[0].lower()
            except:
                pass
        # Yonlendirme mesajini temizle
        response = response.split('[ESCALATE]')[0].strip()
        if not response:
            response = '🔄 Bu konuda yetkililere yönlendiriyorum, birazdan seninle ilgilenecekler.'
        # Cevaplanamayan soruyu kaydet
        try:
            from web.faq_manager import save_unknown_question
            gid = guild_context.get('guild_id', 0) if guild_context else 0
            cid = guild_context.get('channel_id', 0) if guild_context else 0
            save_unknown_question(user_message, gid, cid, history)
        except Exception:
            pass
    
    # History guncelle
    updated_history = history + [
        {'role': 'user', 'content': user_message},
        {'role': 'assistant', 'content': response}
    ]
    
    # Max 20 mesaj tut
    if len(updated_history) > 20:
        updated_history = updated_history[-20:]
    
    return response, should_escalate, escalation_category, updated_history


def ai_ticket_greeting(category: str = None) -> str:
    """Ticket acildiginda AI karsilama mesaji - kategoriye gore"""
    return (
        '## 🤖 Merhaba! Ben Aether AI Destek Asistanı\n\n'
        '> Sana yardımcı olmak için buradayım. Sorununuzu aşağıdaki kategorilerden birine göre açıklarsanız çok daha hızlı çözüm sunabilirim!\n\n'
        '━━━━━━━━━━━━━━━━━━━━━━\n\n'
        '🚨 **Şikayet mi var?**\n'
        '╰ Şikayet ettiğin kullanıcının adını ve yaşanan olayı anlat\n\n'
        '❓ **Soru mu sormak istiyorsun?**\n'
        '╰ Panel, kayıt, komutlar, roller, ekonomi, level...\n\n'
        '🔧 **Teknik sorun mu yaşıyorsun?**\n'
        '╰ Bot, müzik, komut çalışmıyor, hata mesajı...\n\n'
        '━━━━━━━━━━━━━━━━━━━━━━\n\n'
        '� **Sorununuzu yazın, hemen yardımcı olayım!**\n'
        '-# Çözemediğim durumlarda yetkililere otomatik yönlendiririm.'
    )


def parse_ai_actions(response: str) -> dict:
    """
    AI cevabindaki action bloklarini parse et.
    
    Returns:
        {
            'jail': {'user_id': int, 'duration': int, 'reason': str} or None,
            'check_history': bool,
            'analyze_image': bool,
            'escalate': bool
        }
    """
    actions = {
        'jail': None,
        'check_history': None,
        'analyze_image': '[ANALYZE_IMAGE]' in response,
        'escalate': '[ESCALATE]' in response
    }

    # Check history action parse et — iki format
    if '[CHECK_HISTORY]' in response or 'ACTION:CHECK:' in response:
        import re
        if 'ACTION:CHECK:' in response:
            ch_block = response.split('ACTION:CHECK:')[1].split('\n')[0]
            uid_match = re.search(r'user_id=(\d+)', ch_block)
            cid_match = re.search(r'channel_id=(\d+)', ch_block)
        else:
            ch_block = response.split('[CHECK_HISTORY]')[1].split('\n')[0]
            uid_match = re.search(r'user_id:\s*(\d+)', ch_block)
            cid_match = re.search(r'channel_id:\s*(\d+)', ch_block)
        actions['check_history'] = {
            'user_id': int(uid_match.group(1)) if uid_match else None,
            'channel_id': int(cid_match.group(1)) if cid_match else None,
        }
    
    # Jail action parse et — iki format destekle
    if '[JAIL]' in response or 'ACTION:JAIL:' in response:
        try:
            import re
            if 'ACTION:JAIL:' in response:
                jail_block = response.split('ACTION:JAIL:')[1].split('\n')[0]
                uid_match = re.search(r'user_id=(\d+)', jail_block)
                dur_match = re.search(r'duration=(\d+)', jail_block)
                rea_match = re.search(r'reason=(.+?)(?:\s|$)', jail_block)
            else:
                jail_block = response.split('[JAIL]')[1].split('```')[0]
                uid_match = re.search(r'user_id:\s*(\d+)', jail_block)
                dur_match = re.search(r'duration:\s*(\d+)', jail_block)
                rea_match = re.search(r'reason:\s*(.+?)(?:\n|$)', jail_block)

            if uid_match and dur_match:
                actions['jail'] = {
                    'user_id': int(uid_match.group(1)),
                    'duration': int(dur_match.group(1)),
                    'reason': rea_match.group(1).strip() if rea_match else 'Moderasyon ihlali'
                }
        except:
            pass

    # Escalate — iki format
    if 'ACTION:ESCALATE' in response:
        actions['escalate'] = True
    
    return actions

# Allah haklı easter egg — _build_messages few_shot'a eklendi
